
public class Testablauf{

    private Graph graph;
    
    public Testablauf(){
        graph = new Graph(20);
        //Orte erzeugen und einfuegen
        graph.knotenEinfuegen(new Knoten(new Ortschaft("Burgstall", "BS ")));
        graph.knotenEinfuegen(new Knoten(new Ortschaft("Eschelbach", "EB ")));
        graph.knotenEinfuegen(new Knoten(new Ortschaft("F�rnbach", "FB ")));
        graph.knotenEinfuegen(new Knoten(new Ortschaft("Geisenhausen", "GEI")));
        graph.knotenEinfuegen(new Knoten(new Ortschaft("Geroldshausen", "GER")));
        graph.knotenEinfuegen(new Knoten(new Ortschaft("K�nigsfeld", "KF ")));
        graph.knotenEinfuegen(new Knoten(new Ortschaft("Pfaffenhofen", "PAF")));
        graph.knotenEinfuegen(new Knoten(new Ortschaft("Rohrbach", "RB ")));
        graph.knotenEinfuegen(new Knoten(new Ortschaft("Streitdorf", "SD ")));
        graph.knotenEinfuegen(new Knoten(new Ortschaft("Wolnzach", "W")));
        graph.knotenEinfuegen(new Knoten(new Ortschaft("Walkersbach", "WB")));
        graph.knotenEinfuegen(new Knoten(new Ortschaft("Kreuzung1", "X1")));
        graph.knotenEinfuegen(new Knoten(new Ortschaft("Kreuzung2", "X2")));
        
        //Kanten einfuegen
        graph.kanteEinfuegen(0,7);
        graph.kanteEinfuegen(0,9);
        graph.kanteEinfuegen(1,9);
        graph.kanteEinfuegen(1,11);
        graph.kanteEinfuegen(2,6);
        graph.kanteEinfuegen(2,8);
        graph.kanteEinfuegen(2,12);
        graph.kanteEinfuegen(3,4);
        graph.kanteEinfuegen(3,8);
        graph.kanteEinfuegen(3,10);
        graph.kanteEinfuegen(4,9);
        graph.kanteEinfuegen(5,7);
        graph.kanteEinfuegen(5,9);
        graph.kanteEinfuegen(7,9);
        graph.kanteEinfuegen(7,11);
        graph.kanteEinfuegen(10,12);
        graph.kanteEinfuegen(11,12);
        
    }
    
    public void orteAusgeben(){
        graph.knotenlisteAusgeben();
    }
    
    public void orteDurchlaufen(int startNr){
        graph.tiefensuche(startNr);
    }
    
    
   
}

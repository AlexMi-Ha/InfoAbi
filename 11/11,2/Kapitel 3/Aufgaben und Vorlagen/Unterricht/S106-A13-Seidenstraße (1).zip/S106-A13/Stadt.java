
public class Stadt extends Datenelement {
    
    private String name;
    private String kuerzel;
    
    public Stadt(String n, String k){
        name = n;
        kuerzel = k;
    }
    
     public void datenAusgeben(){
         System.out.println(name +", " + kuerzel);
     }
     
     public String kuerzelGeben(){
         return kuerzel;
     }
}

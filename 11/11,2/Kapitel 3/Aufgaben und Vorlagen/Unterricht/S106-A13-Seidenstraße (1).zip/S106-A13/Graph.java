
public class Graph{

   private Knoten[] knoten;
   private int[][] adjazenzmatrix;
   private int maxAnzahl;
   private int anzahl;
   
   public Graph(int m){
       knoten = new Knoten[m];
       adjazenzmatrix = new int[m][m];
       maxAnzahl = m;
       anzahl = 0;
    }
       
    public void knotenEinfuegen(Knoten k){
        if(anzahl < maxAnzahl){
            knoten[anzahl]=k;
            anzahl++;
        }
        else {
            System.out.println("Graph voll belegt!");
        }
    }
    
    public void kanteEinfuegen(int i, int j, int wert){
        if (i<anzahl && j<anzahl) {
            adjazenzmatrix[i][j] = wert;
            adjazenzmatrix[j][i] = wert;
        }
        else {
            System.out.println("Kante kann nicht eingefuegt werden!");
        }
    }
    
    public void knotenEntfernen(Knoten k){
            
    
    
    }
    
    public void kanteEntfernen(int i, int j){
        if (i<anzahl && j<anzahl && adjazenzmatrix[i][j]!=0) {
            adjazenzmatrix[i][j] = 0;
            adjazenzmatrix[j][i] = 0;
        }
        else {
            System.out.println("Hier ist keine Kante vorhanden!");
        }
    }
    
    public int knotenindexSuchen(String kuerz){
        int index = -1;
        int zaehler = 0;       
        while (index < 0 && zaehler < anzahl){
            if (knoten[zaehler].inhaltGeben().kuerzelGeben().equals(kuerz)){
                index = zaehler;
            }
            zaehler++;
        }
        if (index<0) {System.out.println("Knoten nicht vorhanden!");}
        return index;
    }
    
    public void adjazenzmatrixAusgeben(){
        System.out.println("Adjazenzmatrix:");
        System.out.print("  ");
        for(int i=0; i<anzahl; i++){
            System.out. print(i + "    ");
        }
        System.out.println();
        for (int i=0; i<anzahl; i++){
            System.out. print(i + " ");
            for (int j=0; j<anzahl; j++){
                System.out.print(adjazenzmatrix[i][j] +" | ");
            }
            System.out.println(); 
        }
    }
        
    public void knotenlisteAusgeben(){
        for(int i=0; i<anzahl; i++){
            System.out.print("Knoten "+ i + " enthaelt: " );
            knoten[i].inhaltGeben().datenAusgeben();
        }
    }
            
        
    
        
}

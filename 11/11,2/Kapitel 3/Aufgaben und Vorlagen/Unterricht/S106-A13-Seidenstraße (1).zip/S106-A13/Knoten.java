
public class Knoten{

    private Datenelement inhalt;
    
    public Knoten(Datenelement inh){
        inhalt = inh;
    }
    
    public Datenelement inhaltGeben(){
        return inhalt;
    }
    
}

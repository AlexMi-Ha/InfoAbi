public class Seidenstra�e{

    private Graph graph = new Graph(20);    

    public void ablaufen(){
        //Knoten erzeugen
        graph.knotenEinfuegen(new Knoten(new Stadt("Konstantinopel", "KON")));
        graph.knotenEinfuegen(new Knoten(new Stadt("Palmyra", "PAL")));
        graph.knotenEinfuegen(new Knoten(new Stadt("Kairo", "KAI")));
        graph.knotenEinfuegen(new Knoten(new Stadt("Kaschgar", "KAS")));
        graph.knotenEinfuegen(new Knoten(new Stadt("Kucha", "KUC")));
        graph.knotenEinfuegen(new Knoten(new Stadt("Dunhuang", "DUN")));
        graph.knotenEinfuegen(new Knoten(new Stadt("Anxi", "ANX")));
        graph.knotenEinfuegen(new Knoten(new Stadt("Chang'an", "CHA")));
        graph.knotenEinfuegen(new Knoten(new Stadt("Peking", "PEK")));
        graph.knotenEinfuegen(new Knoten(new Stadt("Hangzhou", "HAN")));
        
        
        //Kanten einfuegen
        graph.kanteEinfuegen(graph.knotenindexSuchen("KON"), graph.knotenindexSuchen("PAL"), 100);
        graph.kanteEinfuegen(graph.knotenindexSuchen("KAI"), graph.knotenindexSuchen("PAL"), 100);
        graph.kanteEinfuegen(graph.knotenindexSuchen("PAL"), graph.knotenindexSuchen("KAS"), 100);
        graph.kanteEinfuegen(graph.knotenindexSuchen("KAS"), graph.knotenindexSuchen("KUC"), 100);
        graph.kanteEinfuegen(graph.knotenindexSuchen("KUC"), graph.knotenindexSuchen("ANX"), 100);
        graph.kanteEinfuegen(graph.knotenindexSuchen("KUC"), graph.knotenindexSuchen("DUN"), 100);
        graph.kanteEinfuegen(graph.knotenindexSuchen("DUN"), graph.knotenindexSuchen("ANX"), 100);
        graph.kanteEinfuegen(graph.knotenindexSuchen("KAS"), graph.knotenindexSuchen("DUN"), 100);
        graph.kanteEinfuegen(graph.knotenindexSuchen("ANX"), graph.knotenindexSuchen("CHA"), 100);
        graph.kanteEinfuegen(graph.knotenindexSuchen("CHA"), graph.knotenindexSuchen("PEK"), 100);
        graph.kanteEinfuegen(graph.knotenindexSuchen("CHA"), graph.knotenindexSuchen("HAN"), 100);
        
        graph.knotenlisteAusgeben();
        graph.adjazenzmatrixAusgeben();
        
    }
    
    public void seewegEroeffnen(){
        graph.knotenEinfuegen(new Knoten(new Stadt("Ekbatana", "EKB")));
        graph.knotenEinfuegen(new Knoten(new Stadt("Hafenstadt", "HAF")));
        graph.kanteEntfernen(graph.knotenindexSuchen("PAL"), graph.knotenindexSuchen("KAS"));
        graph.kanteEinfuegen(graph.knotenindexSuchen("PAL"), graph.knotenindexSuchen("EKB"), 100);
        graph.kanteEinfuegen(graph.knotenindexSuchen("EKB"), graph.knotenindexSuchen("KAS"), 100);
        graph.kanteEinfuegen(graph.knotenindexSuchen("EKB"), graph.knotenindexSuchen("HAF"), 100);
        graph.kanteEinfuegen(graph.knotenindexSuchen("HAF"), graph.knotenindexSuchen("HAN"), 100);
        
        System.out.println("Seeweg eroeffnet!");
        graph.knotenlisteAusgeben();
        graph.adjazenzmatrixAusgeben();
    }
    
    public void streckeStreichen(String kuerz1, String kuerz2){
        int i = graph.knotenindexSuchen(kuerz1);
        int j = graph.knotenindexSuchen(kuerz2);
        if (i>-1 && j>-1) {graph.kanteEntfernen(i,j);}
        graph.adjazenzmatrixAusgeben();
    }

    
}

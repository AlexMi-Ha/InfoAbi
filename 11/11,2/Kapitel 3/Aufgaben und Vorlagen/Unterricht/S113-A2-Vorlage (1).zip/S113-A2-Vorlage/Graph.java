
public class Graph{
    private Knoten[] knotenliste;
    private int[][] entfernungsmatrix ;
    private boolean[][]adjmatrix;  
    private int maxAnzahl;
    private int anzahl;
                       
    
    public Graph(int m){
       knotenliste = new Knoten[m]; 
       maxAnzahl = m;
       anzahl = 0;      
    }
  
    public void entfernungsmatrixSetzen(int[][] mat){
        entfernungsmatrix = mat;
    }
    
    public void adjmatrixSetzen(boolean[][] mat){
        adjmatrix = mat;
    }
    
    public void knotenEinfuegen(Knoten k){
        if(anzahl < maxAnzahl){
            knotenliste[anzahl]=k;
            anzahl++;
        }
        else {
            System.out.println("Graph voll belegt!");
        }
    }
   
    public int knotenindexSuchen(String kuerz){
        int index = -1;
        int zaehler = 0;       
        while (index < 0 && zaehler < anzahl){
            if (knotenliste[zaehler].inhaltGeben().kuerzelGeben().equals(kuerz)){
                index = zaehler;
            }
            zaehler++;
        }
        if (index<0) {System.out.println("Knoten nicht vorhanden!");}
        return index;
    }
    
    public int knotenindexSuchen(Knoten k){
        int index = -1;
        int zaehler = 0;       
        while (index < 0 && zaehler < anzahl){
            if (knotenliste[zaehler].equals(k)){
                index = zaehler;
            }
            zaehler++;
        }
        if (index<0) {System.out.println("Knoten nicht vorhanden!");}
        return index;
    }
    
    public Knoten[] routeSuchen(int startNr, int zielNr){ 
      //TODO
    }
  
   
    
    private Knoten nachbarKnotenWaehlen(Knoten aktuell, Knoten ziel){
       //TODO
   }
   
    
   
    
}

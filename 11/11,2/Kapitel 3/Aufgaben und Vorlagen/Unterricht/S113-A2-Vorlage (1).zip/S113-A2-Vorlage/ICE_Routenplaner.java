public class ICE_Routenplaner{

    private Graph graph;;
    
    public ICE_Routenplaner(){
        graph = new Graph(15);
        int[][] e_mat = {{0,210,290,560,260,380,280,550,370,180,600,430,630,490}, 
                       {210,0,220,490,390,460,490,580,400,140,500,330,530,390},
                       {290,220,0,270,290,350,380,370,140,170,430,260,440,300},
                       {560,490,270,0,360,450,510,190,190,410,410,240,200,130},
                       {260,390,290,360,0,120,150,300,240,250,650,480,530,370},
                       {380,480,350,450,120,0,110,320,290,370,770,590,650,490},
                       {280,490,380,510,150,110,0,380,310,390,770,620,670,510},
                       {550,580,370,190,300,320,380,0,240,490,580,420,370,300},
                       {370,400,140,190,240,290,310,240,0,280,480,310,360,210},
                       {180,140,170,410,250,370,390,490,280,0,440,270,470,410},
                       {600,500,430,410,650,770,770,580,480,440,0,160,210,300},
                       {430,300,260,240,480,590,620,420,310,270,160,0,210,110},
                       {630,530,440,200,530,650,670,370,360,470,210,210,0,160},
                       {490,390,300,130,370,490,510,300,210,410,300,110,160,0}  };
      graph.entfernungsmatrixSetzen(e_mat); 
      
      boolean[][] b_mat = {{false,false,false,false,true,false,true,false,false,true,false,false,false,false},
                           {false,false,false,false,false,false,false,false,false,true,false,false,false,false},
                           {false,false,false,true,false,false,false,false,true,true,false,true,false,true},
                           {false,false,true,false,false,false,false,true,true,false,false,false,true,true},
                           {true,false,false,false,false,true,true,false,true,false,false,false,false,false},
                           {false,false,false,false,true,false,true,false,false,false,false,false,false,false},
                           {true,false,false,false,true,true,false,false,false,false,false,false,false,false},
                           {false,false,false,true,false,false,false,false,false,false,false,false,false,false},
                           {false,false,true,true,true,false,false,false,false,false,false,false,false,false},
                           {true,true,true,false,false,false,false,false,false,false,false,false,false,false},
                           {false,false,false,false,false,false,false,false,false,false,false,true,true,false},
                           {false,false,true,false,false,false,false,false,false,false,true,false,false,true},
                           {false,false,false,true,false,false,false,false,false,false,true,false,false,false},
                           {false,false,true,true,false,false,false,false,false,false,false,true,false,false} }; 
      graph.adjmatrixSetzen(b_mat);
      
      graph.knotenEinfuegen(new Knoten(new Bahnhof("Berlin", "B"))); 
      graph.knotenEinfuegen(new Knoten(new Bahnhof("Dresden", "D"))); 
      graph.knotenEinfuegen(new Knoten(new Bahnhof("Erfurt", "EF"))); 
      graph.knotenEinfuegen(new Knoten(new Bahnhof("Frankfurt", "F"))); 
      graph.knotenEinfuegen(new Knoten(new Bahnhof("Hannover", "H"))); 
      graph.knotenEinfuegen(new Knoten(new Bahnhof("Bremen", "HB"))); 
      graph.knotenEinfuegen(new Knoten(new Bahnhof("Hamburg", "HH"))); 
      graph.knotenEinfuegen(new Knoten(new Bahnhof("K�ln", "K"))); 
      graph.knotenEinfuegen(new Knoten(new Bahnhof("Kassel", "KS"))); 
      graph.knotenEinfuegen(new Knoten(new Bahnhof("Leipzig", "L"))); 
      graph.knotenEinfuegen(new Knoten(new Bahnhof("M�nchen", "M"))); 
      graph.knotenEinfuegen(new Knoten(new Bahnhof("N�rnberg", "N"))); 
      graph.knotenEinfuegen(new Knoten(new Bahnhof("Stuttgart", "S"))); 
      graph.knotenEinfuegen(new Knoten(new Bahnhof("W�rzburg", "W�"))); 
       
    }
    
    public void routeSuchen(String start, String ziel){
        //TODO
    }
}

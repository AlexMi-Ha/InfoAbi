

public class Patient {
    private String name;
    private String anlass;
    
    public Patient(String n, String a) {
        name = n;
        anlass = a;
    }
    
    public String nameGeben(){
        return name;
    }
    
    public String anlassGeben(){
        return anlass;
    }
    
}

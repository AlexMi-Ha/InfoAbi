
public class Testablauf
{
    private Taxi taxiA, taxiB, taxiC, taxiD, taxiE, taxiF, taxiG, taxiH, taxiI, taxiJ;    
    private Taxiwarteschlange taxiwarteschlange1;
    
    public Testablauf(){
        taxiwarteschlange1= new Taxiwarteschlange();
    }
    
    
    private void taxisErzeugen(){
        taxiA = new Taxi("PAF-1", "Britta");        
        taxiB = new Taxi("PAF-2", "Hans");
        taxiC = new Taxi("PAF-3", "Peter");
        taxiD = new Taxi("PAF-4", "Willi");
        taxiE = new Taxi("PAF-5", "Hubert"); 
        taxiF = new Taxi("PAF-6", "Paula");
        taxiG = new Taxi("PAF-7", "Eva");
        taxiH = new Taxi("PAF-8", "Otto");
        taxiI = new Taxi("PAF-9", "Iris"); 
        taxiJ = new Taxi("PAF-10", "Norbert");
    }
    
    public void ablaufen() {
        taxisErzeugen();
        taxiwarteschlange1.hintenAnstellen(taxiA);
        taxiwarteschlange1.hintenAnstellen(taxiB);
        taxiwarteschlange1.fahrerlisteAusgeben();
        for (int i=0; i<5; i++) {
            taxiwarteschlange1.vorneAbfahren();
        }
        taxiwarteschlange1.hintenAnstellen(taxiC);
        taxiwarteschlange1.hintenAnstellen(taxiD);
        taxiwarteschlange1.hintenAnstellen(taxiE);
        taxiwarteschlange1.hintenAnstellen(taxiF);
        taxiwarteschlange1.fahrerlisteAusgeben();
        taxiwarteschlange1.vorneAbfahren();
        taxiwarteschlange1.fahrerlisteAusgeben();
        taxiwarteschlange1.hintenAnstellen(taxiG);
        taxiwarteschlange1.hintenAnstellen(taxiH);
        taxiwarteschlange1.hintenAnstellen(taxiI);
        taxiwarteschlange1.hintenAnstellen(taxiJ);
        taxiwarteschlange1.fahrerlisteAusgeben();   
    }
        
}

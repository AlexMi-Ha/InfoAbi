
public class Taxiwarteschlange
{
    private int anzahlTaxis;
    private Taxi[] taxistand;


    public Taxiwarteschlange()
    {
        anzahlTaxis = 0;
        taxistand = new Taxi[6];
    }

    public void hintenAnstellen(Taxi t){
        if (anzahlTaxis==6){
            System.out.println("Fehler: Kein Platz mehr frei!");
        }
        else { 
            taxistand[anzahlTaxis]=t;
            anzahlTaxis = anzahlTaxis+1;
        }
    }
    
    public Taxi vorneAbfahren(){
        Taxi erstesTaxi= null;
        if (anzahlTaxis == 0) {
            System.out.println("Fehler: Kein Taxi in der Schlange!");
        }
        else {
            erstesTaxi = taxistand[0];
            for (int i=0; i<anzahlTaxis-1; i++) {
                taxistand[i]=taxistand[i+1];
            }
            taxistand[anzahlTaxis-1]=null;
            anzahlTaxis=anzahlTaxis-1;
        }
        return erstesTaxi;
    }
        
    public int anzahlGeben() {
        return anzahlTaxis;
    }
    
    public void fahrerlisteAusgeben(){
        System.out.println("Fahrerliste:");
        for (int i=0; i<anzahlTaxis; i++) {
            System.out.println(taxistand[i].fahrernameGeben());
        }
    }
    
    public boolean istLeer() {
        if (anzahlTaxis==0) return true;
        else return false;
    }
}

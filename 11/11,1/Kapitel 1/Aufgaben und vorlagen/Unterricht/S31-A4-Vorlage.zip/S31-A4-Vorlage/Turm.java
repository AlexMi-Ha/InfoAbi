
public class Turm {     //entspricht der bisherigen Liste
    private Listenelement erster;
    
    public Turm(){
        erster = new Abschluss();
    }
    
     public void vorneEinfuegen(Datenelement knoteninhalt){      //vorne in der Liste ist beim Turmbauen unten, k�nnte in untenEinfuegen umbenannt werden.
        Datenknoten neuerKnoten = new Datenknoten(erster, knoteninhalt);
        erster = neuerKnoten;
            
    }
    
    public Datenelement vorneEntnehmen(){       //entspricht im Turm untenEntnehmen   
        Datenelement aktuellerInhalt = erster.inhaltGeben();   
        erster = erster.naechsterGeben();          
        return aktuellerInhalt;
    }
    
    public void hintenEinfuegen(Datenelement knoteninhalt){     //im Turm obendrauf setzen
        erster = erster.hintenEinfuegen(knoteninhalt);
    }
    
    
    public Datenelement inhaltLetzterGeben(){
        return erster.inhaltLetzterGeben(null);
    }
    
    
    //hier gibt es nun mehrere Inhaltswerte nach denen gesucht werden k�nnte. Sinnvoll ist z.B. Entfernen einer bestimmten Farbe
    //TODO (falls noch Zeit ist)
    public void entfernen(String datenwert){  
        erster = erster.entfernen(datenwert);
    }
    
    
    //hier gibt es ebenfalls mehrere Inhaltswerte nach denen gesucht werden k�nnte. Sinnvoll ist z.B. Suche nach einer bestimmten Farbe
    //TODO (falls noch Zeit ist)
    public Datenknoten datenknotenGeben(String datenwert){
        return erster.datenknotenGeben(datenwert);    
    }
    
    //benutzt entfernen und muss daher ebenfalls angepasst werden
    //TODO (falls noch Zeit ist)
    public Datenelement entnehmen(String datenwert){
        Datenknoten gesuchterDk = datenknotenGeben(datenwert);
        if (gesuchterDk != null) {
            Datenelement gesuchtesDe = gesuchterDk.inhaltGeben();
            entfernen(datenwert);
            return gesuchtesDe;
        }
        else return null;
   }
 
      //benutzt entnehmnen und muss daher ebenfalls angepasst werden; funktioniert nur, wenn die Farbe nur einmal vorkommt.
    //TODO (falls noch Zeit ist)
    public Datenelement hintenEntnehmen(){
        Datenelement gesuchtesDe = inhaltLetzterGeben();
        if (gesuchtesDe != null) {
            return entnehmen(gesuchtesDe.datenGeben());
        }
        else return null;
    }
    
    //TODO (k�nnte einen besseren Namen vertragen)
    public int anzahlElementeGeben(){
        return erster.anzahlDatenknotenGeben();
    }
   
    //TODO (erfordert eine Anpassung an die Aufgabenstellung (=> Datenelement))
    public void alleDatenAusgeben(){
        System.out.println(erster.listendatenAusgeben());
    }
    
    public boolean istLeer(){
        return (anzahlElementeGeben()==0);
    }
    
    //TODO: Methode turmhoeheGeben()
    
    //TODO: Methode turmZeichnen(int xpos, int ypos) (Koordinaten der linken unteren Ecke des Turms) 
    
   
}


public class Abschluss extends Listenelement{

    public Listenelement naechsterGeben(){
        return this;
    }
    
    public Datenelement inhaltGeben(){
        return null;
    }
    
    public Datenknoten hintenEinfuegen(Datenelement knoteninhalt){
        Datenknoten neuerKnoten = new Datenknoten(this, knoteninhalt);
        return neuerKnoten;
    }
    
    public Datenelement inhaltLetzterGeben(Datenelement aktuellerInhalt){
        return aktuellerInhalt;
    }
    
    //sollte entsprechend Liste aktualisiert werden
    public Listenelement entfernen(String datenwert){
        return this;
    }
    
   
    //sollte entsprechend Liste aktualisiert werden
    public Datenknoten datenknotenGeben(String datenwert){
        return null;
    }
        
        
    public int anzahlDatenknotenGeben(){
        return 0;
    }
    
    public String listendatenAusgeben(){
        return "";
    }
    
    //TODO: turmhoeheGeben(){
        
       
    //TODO: turmZeichnen(int xpos, int ypos){
        
}

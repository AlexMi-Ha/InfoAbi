
public class Datenelement {
   
   //  TODO:  braucht als Attribute farbe, breite und hoehe (beides int);  
   // Im Konstruktor kann breite fest mit z.B. 50 belegt werden
   
    
    public String datenGeben(){
        //TODO: soll Farbe und H�he als String zur�ckgeben.
    }
    
    public void rechteckZeichnen(int xpos, int ypos){  //xpos, ypos sind die Koordinaten der linken oberen Ecke des Rechtecks
        Rechteck r = new Rechteck(xpos, ypos, breite, hoehe);
        r.setzeFarbe(farbe);
        r.sichtbarMachen();      
    }
    
    //TODO: Methoden die die Farbe bzw. H�he zur�ckgeben
  
}



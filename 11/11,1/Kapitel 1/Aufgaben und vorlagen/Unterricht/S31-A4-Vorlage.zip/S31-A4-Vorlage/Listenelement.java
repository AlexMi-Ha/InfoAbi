
public abstract class Listenelement{
   
    public abstract Listenelement naechsterGeben();
    
    public abstract Datenelement inhaltGeben();
    
    public abstract Datenelement inhaltLetzterGeben(Datenelement aktuellerInhalt);
    
    //sch�ner: aktualisieren
    public abstract Listenelement entfernen(String datenwert);
    
    //sch�ner: aktualisieren
    public abstract Datenknoten datenknotenGeben(String datenwert);

    public abstract Datenknoten hintenEinfuegen(Datenelement knoteninhalt);
    
    public abstract int anzahlDatenknotenGeben();
    
    public abstract String listendatenAusgeben();
    
    //TODO turmhoeheGeben();
    
    //TODO turmZeichnen(int xpos, int ypos);
}

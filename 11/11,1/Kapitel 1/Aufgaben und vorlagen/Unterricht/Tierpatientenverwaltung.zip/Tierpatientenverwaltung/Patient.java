

public abstract class Patient {
    protected String name;
    protected String anlass;
    
    public Patient(String n, String a) {
        name = n;
        anlass = a;
    }
    
    public String nameGeben(){
        return name;
    }
    
    public String anlassGeben(){
        return anlass;
    }
    
    public abstract String datenGeben();
}

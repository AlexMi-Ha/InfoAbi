
public class Pferd extends Patient{

    private String hufkrankheit;
    private boolean zuchtpferd;
    private String bluetigkeit;

    public Pferd(String n, String a, boolean zpf, String bl)
    {
        super(n, a);
        hufkrankheit = "keine";
        zuchtpferd = zpf;
        bluetigkeit = bl;
    }
    
    public String datenGeben() {
        return "Pferd: " + name + ", Anlass: " + anlass  + ", Hufkrankheit: " + hufkrankheit + ", Zuchtpferd: " + zuchtpferd + ", " +bluetigkeit;
    }
}

public class Hund extends Patient{

    private boolean reinrassig;
    private boolean bissig;
 
    public Hund(String n, String a, boolean rr, boolean b)
    {
        super(n, a);
        reinrassig = rr;
        bissig = b;
    }
    
        public String datenGeben() {
        return "Hund: " + name + ", Anlass: " + anlass  + ", reinrassig: " + reinrassig + ", bissig: " + bissig;
    }

}

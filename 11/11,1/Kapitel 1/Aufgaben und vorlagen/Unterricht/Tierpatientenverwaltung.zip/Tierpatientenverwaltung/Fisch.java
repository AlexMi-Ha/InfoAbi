public class Fisch extends Patient{

    private boolean pflanzenfresser;
    private boolean suesswasser;
 
    public Fisch(String n, String a, boolean pfr, boolean sw)
    {
        super(n, a);
        pflanzenfresser = pfr;
        suesswasser = sw;
    }
    
        public String datenGeben() {
        return "Fisch: " + name + ", Anlass: " + anlass  + ", Pflanzenfresser: " + pflanzenfresser + ", Suesswasser: " + suesswasser;
    }

}


public class Sprechstunde {

    private Patient p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15;
    private Patientenwarteschlange patientenws = new Patientenwarteschlange();
    
    
    private void patientenErzeugen(){
        p1 = new Pferd("Maxima", "Kolik", false, "Kaltblut");
        p2 = new Hund("Struppi", "Zahnweh", false, true);
        p3 = new Fisch("Carl", "Flosse verletzt", true, true);
        p4 = new Hund("Rex", "Impfung", true, false);
        p5 = new Pferd("H�gar", "hinkt", false, "Vollblut");
        p6 = new Hund("Tommi", "sieht schlecht", false, false);
        p7 = new Pferd("Don Juan", "Bisswunde", false, "Warmblut");
        p8 = new Hund("Foxi", "Fl�he", false, true);
        p9 = new Hund("Jim", "Aufbauspritze", false, true);
        p10 = new Pferd("Spitzbub", "Hufkontrolle", true, "Kaltblut");
        p11 = new Fisch("Flossi", "Fieber", false, false);
        p12 = new Hund("Areus", "H�ftleiden", false, true);
        p13 = new Fisch("Nemo", "Husten", true, false);
        p14 = new Pferd("Caesar", "Zuchtgutachten", false, "Kaltblut");
        p15 = new Hund("Magnus", "Ball verschluckt", false, false);
       
       
    }
    
    public void ablaufen(){
        patientenErzeugen();
        System.out.println("Das Wartezimmer ist leer: " + patientenws.istLeer());
        System.out.println("Die ersten 4 Patienten werden eingef�gt!");
        patientenws.hintenEinfuegen(p1);
        patientenws.hintenEinfuegen(p2);
 
             
        patientenws.hintenEinfuegen(p3);
        patientenws.hintenEinfuegen(p4);
       
        patientenws.alleAusgeben();
        
        System.out.println("Das Wartezimmer ist leer: " + patientenws.istLeer());
        
        System.out.println("Nun kommt der erste Patient dran:");
        Patient aktuellerP=patientenws.vorneEntnehmen();
        System.out.println(aktuellerP.nameGeben() + " ist in der Sprechstunde wegen "+ aktuellerP.anlassGeben());
        
        patientenws.alleAusgeben();
        System.out.println("Es sind " + patientenws.anzahlGeben() + " Patienten im Wartezimmer.");
        
       
               
        System.out.println("Weitere 11 Patienten wollen angemeldet werden:");
        patientenws.hintenEinfuegen(p5);
        patientenws.hintenEinfuegen(p6);
        patientenws.hintenEinfuegen(p7);
        patientenws.hintenEinfuegen(p8);
        patientenws.hintenEinfuegen(p9);
        patientenws.hintenEinfuegen(p10);
        patientenws.hintenEinfuegen(p11);
        patientenws.hintenEinfuegen(p12);
        patientenws.hintenEinfuegen(p13);
        patientenws.hintenEinfuegen(p14);
        patientenws.hintenEinfuegen(p15);
        
        patientenws.alleAusgeben();
   
        
        for( int i=0; i<14; i++) {
            System.out.println("Es sind " + patientenws.anzahlGeben() + " Patienten im Wartezimmer.");
            System.out.println("Nun kommt der naechste Patient dran:");
            aktuellerP=patientenws.vorneEntnehmen();
            if (aktuellerP!=null) {System.out.println(aktuellerP.nameGeben() + " ist in der Sprechstunde wegen "+ aktuellerP.anlassGeben());}
        }

       
        
    }
}
        
        
        
        

    
    


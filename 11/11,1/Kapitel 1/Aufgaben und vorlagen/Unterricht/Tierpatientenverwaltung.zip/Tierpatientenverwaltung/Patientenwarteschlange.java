
public class Patientenwarteschlange{
    private int anzahlPatienten;
    private Patient[] warteliste;
    
    public Patientenwarteschlange()
    {
        anzahlPatienten = 0;
        warteliste = new Patient[12];
    }

    public void hintenEinfuegen(Patient p){
        if (anzahlPatienten ==  warteliste.length) {System.out.println("Bitte nach Hause gehen! Kein Platz mehr!");}  //Das Feld ist voll!
        else {
            warteliste[anzahlPatienten] = p;    //Wenn das Feld nicht voll ist, kann der neue Patient p eingef�gt werden. Sind z.B. 5 Patienten im Wartezimmer wird der Patient in warteliste[5], also in das 6. Feldelement eingef�gt.
            anzahlPatienten = anzahlPatienten + 1;  //Die Patientenzahl erh�ht sich damit um 1.
        }
    }
    
    public Patient vorneEntnehmen(){
        Patient erster = null;  //lokale Variable erster wird auf null gesetzt, damit man zumindest das zur�ck geben kann, wenn sonst kein Patient ermittelt werden kann.
        if (anzahlPatienten == 0) {
            System.out.println("Fehler: Das Wartezimmer ist leer!"); //Wenn die Warteschlange leer ist, kann auch kein Patient zur�ckgegeben werden.
        }
        else {
            erster = warteliste[0];         //Wenn die Warteschlange nicht leer iat, wird der erste Patient der gesuchte. R�ckgabe am Ende der Methode. 
            for (int i=0; i<anzahlPatienten-1; i++) { //Nun m�ssen aber alle anderen Patienten nachrutschen. Das sind aber nun schon einer weniger als vorher, daher (anzahlPatienten-1).
                warteliste[i]=warteliste[i+1];
            }
            warteliste[anzahlPatienten-1] = null;   //Das vormals letzte Feldelement muss extra auf null gesetzt werden, sonst steht der letzte Patient noch drin.
            anzahlPatienten = anzahlPatienten - 1;  //Die Anzahl der Patienten wird um 1 verringert.
        }
        return erster;  //falls die Warteschlange leer war, wird also null zur�ck gegeben,ansonsten eben der erste Patient auf der Warteliste.
    }
    
    public boolean istLeer(){
        return (anzahlPatienten == 0); //gibt true zur�ck, falls die Anzahl der Patienten null ist
    }
    
    public void alleAusgeben(){         //Gibt am Bildschirm "Warteliste: " aus und dann zeilenweise die Namen der Patienten auf der Warteliste.
        System.out.println("Warteliste:");
        for(int i=0; i<anzahlPatienten; i++){
            System.out.println(warteliste[i].datenGeben());
        }
    }
    
    public int anzahlGeben(){       //gibt zur�ck, wie viele Patienten aktuell eingetragen sind.
        return anzahlPatienten;
    }
        
}

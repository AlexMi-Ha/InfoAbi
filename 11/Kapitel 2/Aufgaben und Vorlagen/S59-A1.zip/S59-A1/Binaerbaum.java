
public class Binaerbaum{
    
    private Baumelement wurzel;
    
    public Binaerbaum(){
        wurzel = new Abschluss();
    }
    
    public void wurzelSetzen(Baumelement w){
        wurzel = w;
    }
    
    public void datenAusgeben(){
        System.out.println(wurzel.alleDatenGeben());
    }
    
    public int anzahlElementeGeben(){
        return wurzel.anzahlDatenknotenGeben();
    }
}

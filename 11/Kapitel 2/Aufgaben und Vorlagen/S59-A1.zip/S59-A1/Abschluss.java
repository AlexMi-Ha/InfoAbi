
public class Abschluss extends Baumelement{
    
    public Baumelement naechsterLinksGeben(){
        return this;
    }
    
    public Baumelement naechsterRechtsGeben(){
        return this;
    }
    
    public Datenelement inhaltGeben(){
        return null;
    }

    public String alleDatenGeben(){
        return "";
    }
    
    public int anzahlDatenknotenGeben(){
        return 0;
    }
}

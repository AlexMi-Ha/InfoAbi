
public abstract class Baumelement {

    public abstract Baumelement naechsterLinksGeben();
    
    public abstract Baumelement naechsterRechtsGeben();
    
    public abstract Datenelement inhaltGeben();
    
    public abstract String alleDatenGeben();
    
    public abstract int anzahlDatenknotenGeben();
    
}

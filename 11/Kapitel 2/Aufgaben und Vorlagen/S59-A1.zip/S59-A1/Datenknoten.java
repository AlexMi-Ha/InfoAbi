
public class Datenknoten extends Baumelement{
    
    private Baumelement naechsterLinks, naechsterRechts;
    private Datenelement inhalt;
    
    public Datenknoten(Baumelement nL, Baumelement nR, Datenelement inh){
        naechsterLinks = nL;
        naechsterRechts = nR;
        inhalt = inh;
    }
    
    public Baumelement naechsterLinksGeben(){
        return naechsterLinks;
    }
    
    public Baumelement naechsterRechtsGeben(){
        return naechsterRechts;
    }
    
    public Datenelement inhaltGeben(){
        return inhalt;
    }
    
    public String alleDatenGeben(){   //Preorder
        return inhalt.datenGeben() + "\n" 
                +naechsterLinks.alleDatenGeben() + naechsterRechts.alleDatenGeben();
    }
    
    public int anzahlDatenknotenGeben(){
        return  1+naechsterLinks.anzahlDatenknotenGeben()+naechsterRechts.anzahlDatenknotenGeben();
    }
}

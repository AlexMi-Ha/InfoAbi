public class Datenelement{

    private String vorname;
    private String nachname;
    private int alter;

    public Datenelement(String vn, String nn, int a)
    {
       vorname = vn;
       nachname = nn;
       alter = a;
    }

    public String datenGeben() {
        return vorname+ " "+ nachname + ", "+alter;
    }
    
}

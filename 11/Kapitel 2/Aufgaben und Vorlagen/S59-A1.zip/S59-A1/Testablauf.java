
public class Testablauf {

    private Datenelement p1, p2, p3, p4, p5, p6, p7, p8;
    private Datenknoten dk1, dk2, dk3, dk4, dk5, dk6, dk7, dk8;
    private Binaerbaum ahnentafel;
 
    public void personenErzeugen(){
        p1 = new Datenelement("Susi", "Bauer", 4);
        p2 = new Datenelement ("Stefanie", "Bauer", 40);
        p3 = new Datenelement("Markus", "Bauer", 41);
        p4 = new Datenelement ("Brigitte", "Gr�nbauer", 63);
        p5 = new Datenelement("Heinz", "Gr�nbauer", 71);
        p6 = new Datenelement ("Erna", "Bauer", 69);
        p7 = new Datenelement("Josef", "Bauer", 69);
        p8 = new Datenelement ("Elisabeth", "Me�ner", 86);
    }
    
    public void StammbaumSetzen(){
        //Datenknoten erzeugen, dabei in der �ltesten Generation anfangen, oder Setzen-Methoden verwenden
        dk8 = new Datenknoten(new Abschluss(), new Abschluss(), p8);
        dk7 = new Datenknoten(new Abschluss(), new Abschluss(), p7);        
        dk6 = new Datenknoten(new Abschluss(), new Abschluss(), p6);                
        dk5 = new Datenknoten(new Abschluss(), new Abschluss(), p5);                
        dk4 = new Datenknoten(dk8, new Abschluss(), p4);        
        dk3 = new Datenknoten(dk6, dk7, p3);        
        dk2 = new Datenknoten(dk4, dk5, p2);                
        dk1 = new Datenknoten(dk2, dk3, p1); 
        
        ahnentafel = new Binaerbaum();
        ahnentafel.wurzelSetzen(dk1);
    }
    
    public void StammbaumAusgeben(){
        ahnentafel.datenAusgeben();
    }
    
    public void personenZaehlen(){
        System.out.println("Der Stammbaum besteht aus " + ahnentafel.anzahlElementeGeben() +" Personen.");
    }
}
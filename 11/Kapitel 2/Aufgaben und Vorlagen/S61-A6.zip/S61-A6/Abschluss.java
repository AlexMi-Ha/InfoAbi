
public class Abschluss extends Baumelement{

    public int knotenZaehlen(){
        return 0;
    }
    
    public double flaecheBerechnen(){
        return 0.0;
    }
    
}


public abstract class Baumelement{

    public abstract int knotenZaehlen();
    
    public abstract double flaecheBerechnen();
    
}


public class Baum{
    private Baumelement wurzel;
    
    public Baum(){
        wurzel = new Datenknoten(350, 100, 70, 0);
    }
    
    public int knotenZaehlen(){
        return wurzel.knotenZaehlen();
    }
    
    public double flaecheBerechnen(){
        return wurzel.flaecheBerechnen();
    }
}


public class Quadratrahmen{

   private int x_links_oben, y_links_oben;
   private double seitenlaenge, winkel;
   
   public Quadratrahmen(int xlo, int ylo, double s, double w){
       x_links_oben = xlo;
       y_links_oben = ylo;
       seitenlaenge = s;
       winkel = w;
       zeichnen();
    }
    
    public void zeichnen(){
        //Eckpunkte berechnen:
        int[] x = new int[4];
        int[] y = new int[4];
        double winkel_b = winkel/180.0 * Math.PI;
        x[0] = x_links_oben;
        y[0] = y_links_oben;
        double sin_w_b = Math.sin(winkel_b);
        double cos_w_b = Math.cos(winkel_b);
        x[1] = (int) (x[0] + seitenlaenge * cos_w_b);
        y[1] = (int) (y[0] - seitenlaenge * sin_w_b);
        x[2] = (int) (x[1] + seitenlaenge * sin_w_b);
        y[2] = (int) (y[1] + seitenlaenge * cos_w_b);
        x[3] = (int) (x[2] - seitenlaenge * cos_w_b);
        y[3] = (int) (y[2] + seitenlaenge * sin_w_b);
        //4 Linien zeichnen
        Linie[] quadrat = new Linie[4];
        for (int i=0; i<4;i++){
            quadrat[i] = new Linie(x[i], y[i], x[(i+1)%4], y[(i+1)%4]);
            quadrat[i].setzeFarbe("magenta");
            quadrat[i].setzeLinienDicke(1);
        }
    }
            
    public double seitenlaengeGeben(){
        return seitenlaenge;
    }
   
}

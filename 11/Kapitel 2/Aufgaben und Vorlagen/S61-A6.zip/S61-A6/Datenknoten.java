

public class Datenknoten extends Baumelement{

    Baumelement naechsterLinks, naechsterRechts;
    Quadratrahmen inhalt;
    
     public Datenknoten(int x_o_l, int y_o_l, double sl, double w){
        if (sl>3){
            inhalt = new Quadratrahmen(x_o_l, y_o_l, sl, w);
            double alpha =30.0;
            double alpha_b = alpha/180.0*Math.PI;
            double w_b = w/180.0*Math.PI;
            double laenge_g = sl*Math.cos(alpha_b);
            double laenge_k = sl*Math.sin(alpha_b);
            double x_links = x_o_l+sl*Math.sin(w_b);
            double y_links = y_o_l+sl*Math.cos(w_b); 
            naechsterLinks = new Datenknoten((int) (x_links),(int) (y_links),laenge_g, w-alpha);
            naechsterRechts = new Datenknoten((int) (x_links+laenge_g*Math.cos(alpha_b-w_b)),
                                              (int) (y_links+laenge_g*Math.sin(alpha_b-w_b)), 
                                              laenge_k, w+90-alpha);
                                                          
       }
       else {
           naechsterLinks = new Abschluss();
           naechsterRechts = new Abschluss();
           inhalt = new Quadratrahmen(x_o_l, y_o_l, sl, w);
        }
    }
 
    public int knotenZaehlen(){
        return 1+ naechsterLinks.knotenZaehlen()+naechsterRechts.knotenZaehlen();
    }
    
    public double flaecheBerechnen(){
        return inhalt.seitenlaengeGeben()*inhalt.seitenlaengeGeben() +naechsterLinks.flaecheBerechnen()+naechsterRechts.flaecheBerechnen();
    }



    
}

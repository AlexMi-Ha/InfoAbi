
public class Knoten
{
    private Element inhalt;
    private Knoten naechster;
    
    public Knoten(Element inh)
    {
        inhalt = inh;
        naechster = null;
    }
    
    public Knoten naechsterGeben(){
        return naechster;
    }
    
    public void naechsterSetzen(Knoten k){
        naechster = k; 
    }
    
    public Element inhaltGeben(){
        return inhalt;
    }
}

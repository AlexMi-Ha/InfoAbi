
public class Element {
    private String bezeichner;    

    public Element(String bez)
    {
        bezeichner = bez;
    }

    public String datenGeben()
    {
        return bezeichner;
    }
}

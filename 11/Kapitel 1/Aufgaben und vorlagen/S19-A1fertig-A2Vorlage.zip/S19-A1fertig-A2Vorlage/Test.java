
public class Test
{
    private Stativ stat=new Stativ();
    
   
    public void erzeugen(){
       Element e1 = new Element("Apfel-rot");
       stat.obenEinfuegen(e1);
       Element e2 = new Element("Banane");
       stat.obenEinfuegen(e2);
       Element e3 = new Element("Trauben");
       stat.obenEinfuegen(e3);
       Element e4 = new Element("Apfel-gr�n");
       stat.obenEinfuegen(e4);
    }
    
    public void inhaltAusgeben(){
        System.out.println("Gesamter Inhalt: " + stat.listeninhaltGeben());
    }
    
    
    public void ablaufen_a(){
        System.out.println("Korbkette wird erzeugt!");
        erzeugen();
        System.out.println("Inhalt erster Korb: " + stat.knotenGeben(1).inhaltGeben().datenGeben());
        System.out.println("Inhalt letzter Korb: " + stat.knotenGeben(stat.anzahlGeben()).inhaltGeben().datenGeben());
        System.out.println("Inhalt dritter Korb: " + stat.knotenGeben(3).inhaltGeben().datenGeben());
        System.out.println("Methode obenEntnehmen wird sechsmal ausgef�hrt!");
        for (int i=0; i<6; i++){
            Knoten k =stat.obenEntnehmen();
            if (k != null) {
               System.out.println(k.inhaltGeben().datenGeben() + " wurde entnommen!");
            }
        }
    }
    
    public void ablaufen_b(){
        stat.obenEinfuegen(new Element("Ananas"));
        stat.obenEinfuegen(new Element("Birne"));
        stat.obenEinfuegen(new Element("Grapefruit"));
        stat.obenEinfuegen(new Element("Zitrone"));
        stat.obenEinfuegen(new Element("Orange"));
        inhaltAusgeben();
    }
    
    public void ablaufen_2(){
        System.out.println("Korbkette wird erzeugt!");
        erzeugen();
        System.out.println("Test: dazwischenEntnehmen");
        inhaltAusgeben();
        
        System.out.println("Entnimm Nr. 2");
        Knoten k =stat.dazwischenEntnehmen(2);
        if (k != null) {
            System.out.println(k.inhaltGeben().datenGeben() + " wurde entnommen!");
        }
        inhaltAusgeben();
        
        System.out.println("Entnimm Letzten");
        k =stat.dazwischenEntnehmen(stat.anzahlGeben());
        if (k != null) {
            System.out.println(k.inhaltGeben().datenGeben() + " wurde entnommen!");
        }
        inhaltAusgeben();
        
        System.out.println("Entnimm Nr. 1");
        k =stat.dazwischenEntnehmen(1);
        if (k != null) {
            System.out.println(k.inhaltGeben().datenGeben() + " wurde entnommen!");
        }
        inhaltAusgeben();
        
    }
    
}

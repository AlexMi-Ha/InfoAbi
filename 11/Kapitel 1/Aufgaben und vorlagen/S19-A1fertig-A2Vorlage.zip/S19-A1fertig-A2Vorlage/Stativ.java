

public class Stativ
{

    private Knoten erster;
    private int anzahlKnoten;
    
    public Stativ()
    {
        erster = null;
        anzahlKnoten = 0;
    }

    public int anzahlGeben(){
        return anzahlKnoten;
    }
    
    public Knoten erstenGeben(){
        return erster;
    }
    
    public Knoten knotenGeben(int position){
        Knoten aktuellerKnoten = null;
        if (position < 1 ||position > anzahlKnoten) {System.out.println("Kein Knoten in dieser Position!");}
        else {
            aktuellerKnoten = erster;
            for (int i=1; i< position;i++){aktuellerKnoten=aktuellerKnoten.naechsterGeben();}
        }
        return aktuellerKnoten;     
    }
    
    public int positionSuchen(Element e){
        int pos = 0;
        Knoten aktuellerKnoten=erster;
        for (int i=0; i<anzahlKnoten; i++) {
            if (aktuellerKnoten.inhaltGeben()==e) pos=i+1;
            aktuellerKnoten = aktuellerKnoten.naechsterGeben();
        }
        return pos;
    }
    
    public void obenEinfuegen(Element e) {
        Knoten neuerKnoten = new Knoten(e);
        neuerKnoten.naechsterSetzen(erster);
        erster=neuerKnoten;
        anzahlKnoten=anzahlKnoten+1;
    }
    
    public Knoten obenEntnehmen(){
        Knoten aktuellerKnoten=erster;
        if (anzahlKnoten == 0) {
            System.out.println("Fehler! Kette ist leer!");
        }
        else {
            erster=erster.naechsterGeben();
            anzahlKnoten = anzahlKnoten - 1;
        }
        return aktuellerKnoten;
    }
   
    
    public String listeninhaltGeben(){
        String ausgabe="";
        Knoten k = erster;
        if (anzahlKnoten==0){System.out.println("Die Kette ist leer!");}
        else {
            for(int i=0; i<anzahlKnoten;i++) {
                ausgabe = ausgabe + "\n" +k.inhaltGeben().datenGeben();
                k=k.naechsterGeben();
            }
        }
        return ausgabe;
    }
    
    public Knoten dazwischenEntnehmen(int position){
        Knoten knotenAlt = knotenGeben(position);
        //TODO
            knotenGeben(position-1).naechsterSetzen(knotenGeben(position+1));
        
        anzahlKnoten=anzahlKnoten-1;
        return knotenAlt;
    }
    
    
}

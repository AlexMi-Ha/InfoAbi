
public abstract class Datenelement{
    public abstract void datenAusgeben();
    public abstract String datenGeben();
}

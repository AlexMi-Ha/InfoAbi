
public class Graph{

   private Knoten[] knoten;
   private boolean[][] adjazenzmatrix;
   int maxAnzahl;
   int anzahl;
   
   public Graph(int m){
       knoten = new Knoten[m];
       adjazenzmatrix = new boolean[m][m];
       maxAnzahl = m;
       anzahl = 0;
    }
       
    public void knotenEinfuegen(Knoten k){
        if(anzahl < maxAnzahl){
            knoten[anzahl]=k;
            anzahl++;
        }
        else {
            System.out.println("Graph voll belegt!");
        }
    }
    
    public void kanteEinfuegen(int i, int j){
        if (i<anzahl && j<anzahl) {
            adjazenzmatrix[i][j] = true;
            adjazenzmatrix[j][i] = true;
        }
        else {
            System.out.println("Kante kann nicht eingefuegt werden!");
        }
    }
    
    public void knotenEntfernen(Knoten k){
            
    
    
    }
    
    public void kanteEntfernen(int i, int j){
        if (i<anzahl && j<anzahl && adjazenzmatrix[i][j]) {
            adjazenzmatrix[i][j] = false;
        }
        else {
            System.out.println("Hier ist keine Kante vorhanden!");
        }
    }
    
    public int knotenindexSuchen(Knoten k){
        int index = -1;
        int zaehler = 0;       
        while (index < 0 && zaehler < anzahl){
            if (knoten[zaehler].equals(k)){
                index = zaehler;
            }
            zaehler++;
        }
        if (index<0) {System.out.println("Knoten nicht vorhanden!");}
        return index;
    }
    
    public void adjazenzmatrixAusgeben(){
        System.out.println("Adjazenzmatrix:");
        System.out.print("  ");
        for(int i=0; i<anzahl; i++){
            System.out. print(i + " ");
        }
        System.out.println();
        for (int i=0; i<anzahl; i++){
            System.out. print(i + " ");
            for (int j=0; j<anzahl; j++){
                if (adjazenzmatrix[i][j]) System.out.print("X ");
                else System.out.print("- ");
            }
            System.out.println(); 
        }
    }
        
    public void knotenlisteAusgeben(){
        for(int i=0; i<anzahl; i++){
            System.out.print("Knoten "+ i + " enthaelt: " );
            knoten[i].inhaltGeben().datenAusgeben();
            System.out.println();
        }
    }
            
   
    
    
    
        
}

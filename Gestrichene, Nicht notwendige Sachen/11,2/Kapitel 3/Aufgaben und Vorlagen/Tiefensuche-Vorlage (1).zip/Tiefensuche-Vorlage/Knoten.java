
public class Knoten{

    
}


public class Ortschaft extends Datenelement {
    
    private String name;
    private String abkuerzung;
    
    public Ortschaft(String n, String a){
        name = n;
        abkuerzung = a;
    }
    
     public void datenAusgeben(){
         System.out.println(name +", " + abkuerzung);
     }
     
     public String datenGeben(){
         return name +", " + abkuerzung;
     }
}

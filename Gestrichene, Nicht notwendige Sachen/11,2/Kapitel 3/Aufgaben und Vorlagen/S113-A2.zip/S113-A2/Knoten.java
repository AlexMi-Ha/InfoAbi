public class Knoten
{
    private Bahnhof inhalt;

    public Knoten(Bahnhof d)
    {
        inhalt = d;
    }
    
    public Bahnhof inhaltGeben(){
        return inhalt;
    }

}

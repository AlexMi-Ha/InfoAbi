
public class Graph{
    private Knoten[] knotenliste;
    private int[][] entfernungsmatrix ;
    private boolean[][]adjmatrix;  
    private int maxAnzahl;
    private int anzahl;

    public Graph(int m){
        knotenliste = new Knoten[m]; 
        maxAnzahl = m;
        anzahl = 0;      
    }

    public void entfernungsmatrixSetzen(int[][] mat){
        entfernungsmatrix = mat;
    }

    public void adjmatrixSetzen(boolean[][] mat){
        adjmatrix = mat;
    }

    public void knotenEinfuegen(Knoten k){
        if(anzahl < maxAnzahl){
            knotenliste[anzahl]=k;
            anzahl++;
        }
        else {
            System.out.println("Graph voll belegt!");
        }
    }

    public int knotenindexSuchen(String kuerz){
        int index = -1;
        int zaehler = 0;       
        while (index < 0 && zaehler < anzahl){
            if (knotenliste[zaehler].inhaltGeben().kuerzelGeben().equals(kuerz)){
                index = zaehler;
            }
            zaehler++;
        }
        if (index<0) {System.out.println("Knoten nicht vorhanden!");}
        return index;
    }

    public int knotenindexSuchen(Knoten k){
        int index = -1;
        int zaehler = 0;       
        while (index < 0 && zaehler < anzahl){
            if (knotenliste[zaehler].equals(k)){
                index = zaehler;
            }
            zaehler++;
        }
        if (index<0) {System.out.println("Knoten nicht vorhanden!");}
        return index;
    }

    public Knoten[] routeSuchen(int startNr, int zielNr){ 
        Knoten startKnoten = knotenliste[startNr];
        Knoten zielKnoten = knotenliste[zielNr];
        Knoten[] pfad = new Knoten[20];
        int index = 0;
        pfad[index]=startKnoten; 
        index++;
        Knoten aktuellerKnoten = startKnoten;
        while (!aktuellerKnoten.equals(zielKnoten) && index<20){
            aktuellerKnoten = nachbarKnotenWaehlen(aktuellerKnoten, zielKnoten);
            pfad[index] = aktuellerKnoten;
            index++;
        }
        return pfad;
    }

    //hier kommt man aber aus K�ln nicht mehr heraus, wenn man nach Berlin will, da K�ln n�her an Berlin ist als Frankfurt.
    private Knoten nachbarKnotenWaehlen1(Knoten aktuell, Knoten ziel){
        int aktIndex = knotenindexSuchen(aktuell);
        int zielIndex = knotenindexSuchen(ziel);
        int entfernung = entfernungsmatrix[aktIndex][zielIndex]; //sonst entfernt man sich vom Ziel, k�nnte aber auch sinnvoll sein (z.B. K-B)
        Knoten nachfolger = aktuell;
        for (int i = 0; i < anzahl; i++){
            if (adjmatrix[aktIndex][i] && (entfernungsmatrix[zielIndex][i]) < entfernung){
                entfernung = entfernungsmatrix[zielIndex][i];
                nachfolger = knotenliste[i];
            }
        }
        return nachfolger;
    }

    private Knoten nachbarKnotenWaehlen(Knoten aktuell, Knoten ziel){
        int aktIndex = knotenindexSuchen(aktuell);
        int zielIndex = knotenindexSuchen(ziel);
        int min =99999;
        Knoten nachfolger = aktuell;
        for (int i = 0; i < anzahl; i++){
            if (adjmatrix[aktIndex][i] && (entfernungsmatrix[zielIndex][i]) < min){
                min = entfernungsmatrix[zielIndex][i];
                nachfolger = knotenliste[i];
            }
        }
        return nachfolger;
    }
   
}

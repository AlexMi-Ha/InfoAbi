public class Bahnhof
{
    private String name;
    private String kuerzel;

    public Bahnhof(String n, String k)
    {
        name = n;
        kuerzel = k;
    }

    public String nameGeben(){
        return name;
    }
    
    public String kuerzelGeben(){
        return kuerzel;
    }
}

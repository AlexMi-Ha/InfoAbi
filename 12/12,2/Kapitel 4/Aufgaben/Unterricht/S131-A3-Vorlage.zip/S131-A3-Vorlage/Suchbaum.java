class Suchbaum{
    private Baumelement wurzel;
    public Suchbaum() {
        wurzel = new Abschluss();
    }
    public void wurzelSetzen(Baumelement w){
        wurzel=w;
    }
    public Baumelement wurzelGeben() {
        return wurzel;
    }
    public void inhaltEinfuegen(Datenelement inhaltNeu) {
        wurzel=wurzel.sortiertEinfuegen(inhaltNeu);
    }
    public Datenelement inhaltSuchen(Datenelement vergleichsinhalt) { 
        return wurzel.inhaltSuchen(vergleichsinhalt);
    }
    public int inhaltSuchenZaehlen(Datenelement vergleichsinhalt) { 
        return wurzel.inhaltSuchenZaehlen(vergleichsinhalt);
    }
    public boolean inhaltIstVorhanden(Datenelement inhalt) { 
        return wurzel.inhaltSuchen(inhalt) != null; 
    }
    public Datenelement minimumGeben() { 
        return wurzel.minimumGeben(wurzel.inhaltGeben());
    }
    public int hoeheGeben(){
        return wurzel.hoeheGeben();
    }
    public int anzahlElementeGeben(){
       return wurzel.anzahlDatenknotenGeben();
    }

}
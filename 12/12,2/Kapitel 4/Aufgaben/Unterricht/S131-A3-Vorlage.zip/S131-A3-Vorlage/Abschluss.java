class Abschluss extends Baumelement {
      
    public Datenknoten sortiertEinfuegen (Datenelement inhaltNeu) {
        return new Datenknoten(this, new Abschluss(),inhaltNeu);
    }
    public Datenelement inhaltSuchen(Datenelement vergleichsinhalt){
        return null;
    }

    public int inhaltSuchenZaehlen(Datenelement vergleichsinhalt){
        return 0;
    }
      
    public Baumelement naechsterLinksGeben() {
        return this;
    }
    public Baumelement naechsterRechtsGeben() {
       return this;
    }
    public Datenelement minimumGeben(Datenelement vaterelement) { 
        return vaterelement;
    }
    public Datenelement inhaltGeben(){
      return null;
    }
    public int hoeheGeben(){
        return 0;
    }
    public int anzahlDatenknotenGeben(){
      return 0;
    }

}

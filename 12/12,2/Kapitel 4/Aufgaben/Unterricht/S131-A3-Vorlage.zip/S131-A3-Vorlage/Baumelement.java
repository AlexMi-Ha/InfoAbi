abstract class Baumelement {
    public abstract Datenknoten sortiertEinfuegen(Datenelement inhaltNeu); 
    public abstract Datenelement inhaltSuchen(Datenelement vergleichsinhalt);
    public abstract int inhaltSuchenZaehlen(Datenelement vergleichsinhalt);
    public abstract Baumelement naechsterLinksGeben();
    public abstract Baumelement naechsterRechtsGeben();
    public abstract Datenelement minimumGeben(Datenelement vaterelement);
    public abstract Datenelement inhaltGeben();
    public abstract int anzahlDatenknotenGeben();
    public abstract int hoeheGeben();
}

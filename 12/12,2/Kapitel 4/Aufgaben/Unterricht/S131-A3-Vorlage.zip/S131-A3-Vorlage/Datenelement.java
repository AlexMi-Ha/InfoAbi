abstract class Datenelement {
    public abstract boolean istGleich(Datenelement de);
    public abstract boolean istKleiner(Datenelement de);
    public abstract int schluesselGeben();
}

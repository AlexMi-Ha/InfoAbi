class Eintrag extends Datenelement {
   private String name; // Schluessel
   private int telefon;
   
   public Eintrag(String e, int t){
       name=e;
       telefon = t;
   }
   public boolean istGleich(Datenelement de){
       return (telefon ==((Eintrag)de).telefon);
   }
   public boolean istKleiner(Datenelement de){
       return (telefon < ((Eintrag)de).telefon);
   }
   public int schluesselGeben()  {
        return telefon;
   }
}

class Test {
    private Suchbaum sbaum;
    private int[] suchliste;

    public int ablaufen(int n, int s) { //n: Anzahl Nummern, s: Anzahl Suchnummern
        sbaum = new Suchbaum();
        suchliste = new int[s];
        fuellenAuswaehlen(n, s);
        //System.out.println(sbaum.hoeheGeben());
        return suchdauer();   
    }
        
    public void eintragEinfuegen(String name, int telefon) {
        sbaum.inhaltEinfuegen(new Eintrag(name, telefon));
    }

    public boolean eintragIstVorhanden(int vergleichsschluessel) { 
        return sbaum.inhaltIstVorhanden(new Eintrag("", vergleichsschluessel)); 
    }
    
    public void fuellenAuswaehlen(int n, int s){ 
        int telnr;
        int z = 0;
        for (int i = 0; i < n; i++){
         telnr = (int) (Math.random()*1000000);
         sbaum.inhaltEinfuegen(new Eintrag("Landau"+i, telnr));
         if (i % (n/s) == 0) { 
             suchliste[z] = telnr; 
             z++;             
            }
        } 
     }

     public int suchdauer(){
       //TODO
     }
           
        
    public void schleife(int n){
        for (int i =50; i<=n; i=i+50){
            System.out.println(i + ": " + ablaufen(i, 50));
        }
    } 

 }

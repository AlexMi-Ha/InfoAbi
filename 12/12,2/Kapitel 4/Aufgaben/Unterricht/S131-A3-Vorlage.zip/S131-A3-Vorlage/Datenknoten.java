class Datenknoten extends Baumelement {
    private Baumelement naechsterLinks, naechsterRechts;
    private Datenelement inhalt;
    
    public Datenknoten (Baumelement nl, Baumelement nr, Datenelement i){
        naechsterLinks = nl;
        naechsterRechts = nr;
        inhalt = i;
    }
    public Baumelement naechsterLinksGeben() {
        return naechsterLinks;
    }
    public Baumelement naechsterRechtsGeben() {
        return naechsterRechts;
    }
    public Datenelement minimumGeben(Datenelement vaterelement) { 
        return naechsterLinks.minimumGeben(this.inhalt);
    }
    public Datenelement inhaltGeben(){
      return inhalt;
    }
    public int anzahlDatenknotenGeben(){ 
       return 1+naechsterLinks.anzahlDatenknotenGeben()+naechsterRechts.anzahlDatenknotenGeben();
    }
    public Datenknoten sortiertEinfuegen(Datenelement inhaltNeu) { 
        if (inhalt.istKleiner(inhaltNeu)) {
            naechsterRechts=naechsterRechts.sortiertEinfuegen(inhaltNeu);
        }
        else  {
            naechsterLinks=naechsterLinks.sortiertEinfuegen(inhaltNeu);
        }
        return this;
    }
    public Datenelement inhaltSuchen(Datenelement vergleichsinhalt) {
        if (inhalt.istGleich(vergleichsinhalt)) {
            return inhalt;
        }
        else if (inhalt.istKleiner(vergleichsinhalt))  {
            return naechsterRechts.inhaltSuchen(vergleichsinhalt);
        }
        else   {
            return naechsterLinks.inhaltSuchen(vergleichsinhalt);
        }
    }  

    public int inhaltSuchenZaehlen(Datenelement vergleichsinhalt) {
        if (inhalt.istGleich(vergleichsinhalt)) {
            return 1;
        }
        else if (inhalt.istKleiner(vergleichsinhalt))  {
            return 1 + naechsterRechts.inhaltSuchenZaehlen(vergleichsinhalt);
        }
        else   {
            return 1 + naechsterLinks.inhaltSuchenZaehlen(vergleichsinhalt);
        }
    }  
    
    
    public int hoeheGeben(){
        return 1 + Math.max(naechsterLinks.hoeheGeben(),naechsterRechts.hoeheGeben());
    }

}

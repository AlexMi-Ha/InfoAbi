
public class Ackermann
{
    public long ack(long n, long m){
        if(n==0) {
            return m+1;
        }
        else if (m==0){
            return ack(n-1,1);
        }
        else {
            return ack(n-1, ack(n, m-1));
        }
    }
    
    public long anzahlAck(long n, long m){
       if(n==0) {
            return 1;
        }
        else if (m==0){
            return 1+ anzahlAck(n-1,1);
        }
        else {
            return 1 + anzahlAck(n-1, ack(n, m-1))+ anzahlAck(n, m-1);
        }
    } 
    
    public void schleife (int n, int m){
        for (int i=0; i<m; i++){
            System.out.println( i + "; " +anzahlAck(n, i));
        }
    }
    public void schleife2 (int n, int m){
        for (int i=0; i<n; i++){
            System.out.println( i + "; " +anzahlAck(i, m));
        }
    }
}

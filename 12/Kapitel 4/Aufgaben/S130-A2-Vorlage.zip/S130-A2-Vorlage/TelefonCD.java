
public class TelefonCD{
   
    private SortierteListe telefonCD;
    
    public TelefonCD(){
        telefonCD = new SortierteListe();
    }
    
    public void ausgeben(){
        System.out.println("TelefonCD: ");
        telefonCD.alleDatenAusgeben();
    }
    
    public void eintragen(String nn, String adr, int nr){
        CDEintrag neuerEintrag = new CDEintrag(nn, adr, nr);
        telefonCD.einfuegen(neuerEintrag);
    }
    
    
    //sucht nach einer Nummer und entfernt den entsprechenden Eintrag
    public void eintragEntfernen(int nr){
        CDEintrag sucheintrag = new CDEintrag("", "", nr);
        telefonCD.entfernen(sucheintrag);
    }
    
    public Eintrag eintragEntnehmen(int nr){
        CDEintrag sucheintrag = new CDEintrag("", "", nr);
        return (Eintrag) telefonCD.entnehmen(sucheintrag);
    }
    
    public Eintrag eintragGeben(int nr){
         CDEintrag sucheintrag = new CDEintrag("", "", nr);
         return (Eintrag) telefonCD.datenknotenGeben(sucheintrag).inhaltGeben();
    }
    
    public int zaehlen(int nr){
       //TODO
    }
        
}

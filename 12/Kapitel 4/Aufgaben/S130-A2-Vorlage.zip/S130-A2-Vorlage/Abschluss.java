

public class Abschluss extends Listenelement{

    public Listenelement naechsterGeben(){
        return this;
    }
    
    public Datenelement inhaltGeben(){
        return null;
    }
    
    public Datenknoten sortiertEinfuegen(Datenelement de){
        Datenknoten neuerKnoten = new Datenknoten(this, de);
        return neuerKnoten;
    }
    
    public Listenelement sortiertEntfernen(Datenelement suchinhalt){
        return this;
    }
    
    public Datenknoten datenknotenGeben(Datenelement suchinhalt){
        return null;
    }
        
        
    public int anzahlDatenknotenGeben(){
        return 0;
    }
    
    public String listendatenAusgeben(){
        return "";
    }
    
    //TODO
    
}

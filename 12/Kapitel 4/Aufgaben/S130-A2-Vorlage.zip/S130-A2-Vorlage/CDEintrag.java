
public class CDEintrag extends Eintrag{
    
    public CDEintrag(String n, String a, int tn) {
       name = n;
       adresse = a;
       telnr = tn;
    }
    
    public  boolean istKleiner(Datenelement de){
      return telnr < ((Eintrag) de).telnr  ;
    }
    
    public  boolean istGleich (Datenelement de){
      return telnr == ((Eintrag) de).telnr  ;
    }
      
    
}

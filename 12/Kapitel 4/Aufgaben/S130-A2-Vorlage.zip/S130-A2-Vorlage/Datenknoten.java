
public class Datenknoten extends Listenelement{

    private Datenelement inhalt;
    private Listenelement naechster;
    
    public Datenknoten(Listenelement n, Datenelement i){
        naechster = n;
        inhalt = i;
    }
    
    public Listenelement naechsterGeben(){
        return naechster;
    }
    
    public Datenelement inhaltGeben(){
        return inhalt;   
    }
    
    public Datenknoten sortiertEinfuegen(Datenelement de){
        if (inhalt.istKleiner(de)) {
            naechster = naechster.sortiertEinfuegen(de);
            return this;
        }
        else {
            Datenknoten neuerKnoten = new Datenknoten(this, de);
            return neuerKnoten;
        }
    }
    
    public Listenelement sortiertEntfernen(Datenelement suchinhalt){
        if (inhalt.istGleich(suchinhalt)) {
            return naechster;
        }
        else {
            if (inhalt.istKleiner(suchinhalt)){
                naechster = naechster.sortiertEntfernen(suchinhalt);
            }
            return this;
        }
    }
    
    public Datenknoten datenknotenGeben(Datenelement suchinhalt){
        if (inhalt.istGleich(suchinhalt)){
            return this;
        }
        else {
            return naechster.datenknotenGeben(suchinhalt);
        }
    }
    
    public int anzahlDatenknotenGeben(){
        return naechster.anzahlDatenknotenGeben() + 1;
    }
        
    public String listendatenAusgeben(){
        return inhalt.datenGeben() + "\n" + naechster.listendatenAusgeben();
    }
    
    //TODO
    
}

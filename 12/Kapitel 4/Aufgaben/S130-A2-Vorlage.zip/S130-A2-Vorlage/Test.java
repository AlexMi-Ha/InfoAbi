public class Test {

    private TelefonCD cd;
    private int[] suchliste;
    
    public int ablaufen(int n, int s){ //n: Anzahl Nummern, s: Anzahl Suchnummern
        cd = new TelefonCD();
        suchliste = new int[s];
        fuellenAuswaehlen(n, s);
        return suchdauer();
        
    }
    
    //Es kann hier zu Nummern wie 123 UND 1234 kommen. Das ist aber f�r die Fragestellung irrelevant
    public void fuellenAuswaehlen(int n, int s){  //fuellt die cd mit n Eintr�gen und w�hlt die s zuerst eingetragenen (zuf�llig verteilt!) als Sucheintr�ge aus.
        int telnr;
        for (int i=0; i<n; i++){
            telnr = (int) (Math.random()* 1000000);
            cd.eintragen("Huber", "Sportweg", telnr);
            if (i<s) { suchliste[i] = telnr;}
        }
    }
    public void ausgeben(){
       cd.ausgeben();
    }
    
    public int suchdauer(){
        //TODO
    }
    
        
    
}
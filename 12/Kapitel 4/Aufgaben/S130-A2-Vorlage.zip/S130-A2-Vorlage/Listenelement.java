
public abstract class Listenelement{
    
    public abstract Listenelement naechsterGeben();
    
    public abstract Datenelement inhaltGeben();
    
    public abstract Datenknoten sortiertEinfuegen(Datenelement de);
        
    public abstract Listenelement sortiertEntfernen(Datenelement suchinhalt);
    
    public abstract Datenknoten datenknotenGeben(Datenelement suchinhalt);

    public abstract int anzahlDatenknotenGeben();
    
    public abstract String listendatenAusgeben();
    
    //TODO 
    
}

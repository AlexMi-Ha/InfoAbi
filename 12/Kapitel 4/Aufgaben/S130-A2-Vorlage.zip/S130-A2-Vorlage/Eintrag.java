
public abstract class Eintrag extends Datenelement
{
   protected String name;
   protected String adresse;
   protected int telnr;
   
   
    public abstract boolean istKleiner(Datenelement de);
    
    public abstract boolean istGleich (Datenelement de);
    
    
    public String datenGeben(){
        return name + " " + adresse + " , Tel: " + telnr;  
    }
    
   
}

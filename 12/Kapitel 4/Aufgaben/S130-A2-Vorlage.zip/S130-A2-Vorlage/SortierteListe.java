
public class SortierteListe {
    private Listenelement erster;
    
    public SortierteListe(){
        erster = new Abschluss();
    }
    
    public void einfuegen(Datenelement de){
        erster = erster.sortiertEinfuegen(de);
    }
    
    public void entfernen(Datenelement suchinhalt){
        erster = erster.sortiertEntfernen(suchinhalt);
    }
 
    public Datenknoten datenknotenGeben(Datenelement suchinhalt){
        return erster.datenknotenGeben(suchinhalt);    
    }
    
    public Datenelement entnehmen(Datenelement suchinhalt){
        Datenknoten gesuchterDk = datenknotenGeben(suchinhalt);
        if (gesuchterDk != null) {
            Datenelement gesuchtesDe = gesuchterDk.inhaltGeben();
            entfernen(suchinhalt);
            return gesuchtesDe;
        }
        else return null;
   }
    
    public int anzahlElementeGeben(){
        return erster.anzahlDatenknotenGeben();
    }
   
    public void alleDatenAusgeben(){
        System.out.println(erster.listendatenAusgeben());
    }
    
    public boolean istLeer(){
        return (anzahlElementeGeben()==0);
    }
    
    //TODO
    
    
}

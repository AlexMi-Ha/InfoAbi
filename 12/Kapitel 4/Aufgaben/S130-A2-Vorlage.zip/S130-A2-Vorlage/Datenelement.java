
public abstract class Datenelement{
    
    public abstract boolean istKleiner(Datenelement de);
    
    public abstract boolean istGleich (Datenelement de);
    
    public abstract String datenGeben();
}

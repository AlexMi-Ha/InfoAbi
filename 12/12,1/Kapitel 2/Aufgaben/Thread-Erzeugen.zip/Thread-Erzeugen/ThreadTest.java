
public class ThreadTest
{
    
        public void werIstDran(){
            System.out.println("Thread: " + Thread.currentThread());
            System.out.println("Thread-ID: " + Thread.currentThread().getId());
            System.out.println("Thread-Name: " + Thread.currentThread().getName());
            System.out.println("Thread-Priorit�t: " + Thread.currentThread().getPriority());
            System.out.println("Thread-State: " + Thread.currentThread().getState());
            System.out.println("Daemon: " + Thread.currentThread().isDaemon());
            System.out.println("Alive: " + Thread.currentThread().isAlive());
            System.out.println("is Interrupted: " + Thread.currentThread().isInterrupted());
            System.out.println("Interrupt "); Thread.currentThread().interrupt();
            System.out.println("is Interrupted: " + Thread.currentThread().isInterrupted());
            System.out.println("Interrupted: " + Thread.interrupted());
            System.out.println("is Interrupted: " + Thread.currentThread().isInterrupted());
            System.out.println("Interrupted: " + Thread.interrupted());
            System.out.println("is Interrupted: " + Thread.currentThread().isInterrupted());
        }
    
}

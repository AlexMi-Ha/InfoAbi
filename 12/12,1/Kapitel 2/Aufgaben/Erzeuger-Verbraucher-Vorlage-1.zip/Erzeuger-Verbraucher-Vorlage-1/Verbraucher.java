
public class Verbraucher extends Thread
{
    //TODO: Wo holt der Verbraucher ab?    

    //TODO: Konstruktor
    

    public void run(){
        //TODO: immer nur entnehmen und das dann verbrauchen
    }
    
    public void verbrauchen(Tasse t){
        try {
            sleep((int) (Math.random()*1000)); //braucht eine zuf�llige Zeit zwischen 0 und 1000 ms;
        }
        catch (Exception e){}
        
        System.out.println(t.datenGeben() + " getrunken!");
    }
}

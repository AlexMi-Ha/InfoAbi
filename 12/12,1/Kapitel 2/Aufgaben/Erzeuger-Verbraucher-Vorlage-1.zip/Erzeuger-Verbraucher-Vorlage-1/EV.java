
public class EV
{
    //TODO: Es muss 1 Puffer, 1 Erzeuger und 1 Verbraucher verwaltet werden
    
    
    public EV()
    {
        puffer = new Puffer(10);
        erzeuger = new Erzeuger(//TODO: Was muss hier rein?);
        verbraucher = new Verbraucher(//TODO: Was muss hier rein?);
        //TODO: Und jetzt noch beide Threads starten!
    }

    
}

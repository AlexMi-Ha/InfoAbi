
public class Erzeuger extends Thread
{
    private Puffer puffer;
    private int tassenzaehler; //jeder erzeugte Tasse wird gez�hlt
    
    public Erzeuger(//TODO: Was muss hier rein? Erzeuger und Verbraucher m�ssen ja auf den gleichen Puffer zugreifen!)){
        tassenzaehler=0;
        //s.o.
    }
    
    public void run(){
        //immer nur erzeugen und das dann ablegen
        
    }
    
    public Tasse erzeugen(){
        Tasse t = new Tasse(tassenzaehler);
        tassenzaehler++;
        try {
            sleep(500);  //Das Erzeugen dauert 500 ms;
        }
        catch (Exception e){}
        
        System.out.println(t.datenGeben() + " hergestellt!");
        return t;
    }
}

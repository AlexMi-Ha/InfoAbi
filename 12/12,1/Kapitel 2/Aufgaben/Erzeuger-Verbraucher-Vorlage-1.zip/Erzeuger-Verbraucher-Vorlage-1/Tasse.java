
public class Tasse
{
    int nr;
    
    public Tasse(int nummer)
    {
        nr = nummer;
    }
    
    public String datenGeben(){
       return nr + ". Tasse Kaffee";
    }

    
}

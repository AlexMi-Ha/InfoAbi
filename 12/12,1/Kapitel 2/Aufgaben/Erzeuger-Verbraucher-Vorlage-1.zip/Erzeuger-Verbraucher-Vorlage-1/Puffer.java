
public class Puffer
{
    /* TODO:
     * Deklariere ein Attribut namens plaetze, dass ein Feld von Tassen verwalten kann.
     * Die L�nge des Feldes soll im Konstruktor als Parameter �bergeben werden.
     * Au�erdem Attribut anzahl, das die Anzahl der aktuell abgelegten Tassen speichert.
     */
    
    /*TODO:
     * Konstruktor
     */
    
    
    public synchronized void ablegen(Tasse t){
        /* TODO
         * Damit die Ausgabe besser nachvollzogen werden kann, sollten an entsprechender Stelle Ausgaben wie
         * System.out.println("will ablegen");
         * oder System.out.println(Thread.currentThread().getName() + " geht nicht!");
         * oder System.out.println(t.datenGeben() + " abgestellt!");
         * eingebaut werden.
         */
    }
    
    public synchronized Tasse entnehmen(){
        /* TODO
         * Damit die Ausgabe besser nachvollzogen werden kann, sollten an entsprechender Stelle Ausgaben wie
         * System.out.println("will entnehmen");
         * oder System.out.println(Thread.currentThread().getName() + " geht nicht!");
         * oder System.out.println(t.datenGeben() + " abgeholt!");
         * eingebaut werden.
         */
    }
            
}

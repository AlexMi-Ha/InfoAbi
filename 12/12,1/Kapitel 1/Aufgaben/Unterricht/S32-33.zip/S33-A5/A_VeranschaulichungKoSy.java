 

import java.awt.Color;
import javax.swing.SwingUtilities;

/**
 *
 * @author Manuel Mayr
 */
public class A_VeranschaulichungKoSy extends javax.swing.JPanel {

    private Assistent Assistent=new Assistent();
    public boolean Pruefung;
    public boolean Eingabe;
    public String Fehler;
    
    private int x;
    private int y;
    
    public A_VeranschaulichungKoSy() {
        Assistent.setBounds(430, 120, 250, 250);
        add(Assistent);
        initComponents();
        Reset();
    }

        public void Reset() {
        Assistent.setText("Klicke die angegebene Koordinate im Koordinatensystem an.<br>Viel Erfolg!");
        Assistent.setColor(Color.BLACK);
        DruckButton.setVisible(false);
        DruckButton.setEnabled(false);
        Punkt.setVisible(false);
        Eingabe=false;
        Fehler="";

        x=(int)(Math.random()*9);
        y=(int)(Math.random()*8);
        AufgabenLabel.setText("P ("+x+" | "+y+")");
    }
    
    public void drucken() {
        String a="Natürliche Zahlen - Veranschaulichung von Zahlen";
        String b=AufgabenLabel.getText();
        String c=Fehler;
        Drucker d = new Drucker(a,b,c);
    }
    
    public void Loesung(int xK, int yK) {
        if(!Eingabe){
            Eingabe=true;
            if(!Pruefung) {
                if(xK==x&&yK==y) {
                    Assistent.setText("Du hast die richtigen Koordinaten angeklickt!<br>Gut gemacht!");
                    Assistent.setColor(Color.GREEN);
                } else {
                    Assistent.setColor(Color.RED);
                    String text="Das ist falsch";
                    Fehler="P ("+xK+" | "+yK+")";
                    if(yK==x&&xK==y) text+=", du hast die x- und y-Koordinate vertauscht.";
                    else if(yK==y)text+=", du hast die falsche x-Koordinate gewählt.";
                    else if(xK==x) text+=", du hast die falsche y-Koordinate gewählt.";
                    else text+=".";
                    text+="<br>Der rote Punkt zeigt Dir die richtige Koordinate.<br>Versuch es nochmal!";
                    DruckButton.setVisible(true);
                    DruckButton.setEnabled(true);
                    Assistent.setText(text);
                    Punkt.setBounds((49+(x*26)), (346-(y*26)), 10, 10);
                    Punkt.setVisible(true);
                }
            } else {
                //Pruefung Code
            }
        } else {
            Assistent.setText("Du hast die Aufgabe schon bearbeitet. Drücke auf neue Aufgabe, um eine neue Aufgabe bearbeiten zu können!");
        }
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        UeberschriftLabel = new javax.swing.JLabel();
        ErklaerungLabel = new javax.swing.JLabel();
        NeuButton = new javax.swing.JButton();
        ZurueckButton = new javax.swing.JButton();
        DruckButton = new javax.swing.JLabel();
        Punkt = new javax.swing.JLabel();
        EintragOeffnenLabel = new javax.swing.JLabel();
        Koordinatensystem = new javax.swing.JLabel();
        AufgabenLabel = new javax.swing.JLabel();
        Hintergrund = new javax.swing.JLabel();

        setLayout(null);

        UeberschriftLabel.setFont(new java.awt.Font("Georgia", 1, 26)); // NOI18N
        UeberschriftLabel.setForeground(new java.awt.Color(255, 255, 255));
        UeberschriftLabel.setText("Natürliche Zahlen");
        add(UeberschriftLabel);
        UeberschriftLabel.setBounds(36, 31, 244, 26);

        ErklaerungLabel.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        ErklaerungLabel.setForeground(new java.awt.Color(255, 255, 255));
        ErklaerungLabel.setText("Veranschaulichung von Zahlen");
        add(ErklaerungLabel);
        ErklaerungLabel.setBounds(36, 63, 270, 21);

        NeuButton.setText("<html>Nächste<br>Aufgabe</html>");
        NeuButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NeuButtonActionPerformed(evt);
            }
        });
        add(NeuButton);
        NeuButton.setBounds(330, 350, 70, 40);

        ZurueckButton.setText("Zurück");
        ZurueckButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ZurueckButtonActionPerformed(evt);
            }
        });
        add(ZurueckButton);
        ZurueckButton.setBounds(30, 450, 80, 23);

        DruckButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/DruckIcon.png"))); // NOI18N
        DruckButton.setToolTipText("Drucken");
        DruckButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        DruckButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DruckButtonMouseClicked(evt);
            }
        });
        add(DruckButton);
        DruckButton.setBounds(560, 420, 30, 30);

        Punkt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/punkt.jpg"))); // NOI18N
        add(Punkt);
        Punkt.setBounds(100, 170, 10, 10);

        EintragOeffnenLabel.setBackground(new java.awt.Color(255, 255, 255));
        EintragOeffnenLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        EintragOeffnenLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EintragOeffnenLabelMouseClicked(evt);
            }
        });
        add(EintragOeffnenLabel);
        EintragOeffnenLabel.setBounds(430, 120, 250, 250);

        Koordinatensystem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Koordinatensystem.jpg"))); // NOI18N
        Koordinatensystem.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                KoordinatensystemMouseClicked(evt);
            }
        });
        add(Koordinatensystem);
        Koordinatensystem.setBounds(24, 114, 300, 260);

        AufgabenLabel.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        AufgabenLabel.setForeground(new java.awt.Color(255, 255, 255));
        AufgabenLabel.setText("P (3 / 3)");
        add(AufgabenLabel);
        AufgabenLabel.setBounds(340, 140, 70, 22);

        Hintergrund.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Hintergrund.jpg"))); // NOI18N
        add(Hintergrund);
        Hintergrund.setBounds(0, 0, 700, 500);
    }// </editor-fold>//GEN-END:initComponents

    private void NeuButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NeuButtonActionPerformed
        if(!Pruefung) Reset();
        else ;
    }//GEN-LAST:event_NeuButtonActionPerformed

    private void ZurueckButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ZurueckButtonActionPerformed
        if(!Pruefung)((Frame)(SwingUtilities.getRoot(this))).PerformBackAction(-2);
    }//GEN-LAST:event_ZurueckButtonActionPerformed

    private void DruckButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DruckButtonMouseClicked
        drucken();
    }//GEN-LAST:event_DruckButtonMouseClicked

    private void EintragOeffnenLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EintragOeffnenLabelMouseClicked
        if(!Pruefung){
            Eintrag e = new Eintrag();
            e.EintragAusgeben(2);
            e.setVisible(true);
        }
    }//GEN-LAST:event_EintragOeffnenLabelMouseClicked

    private void KoordinatensystemMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_KoordinatensystemMouseClicked
        int x=evt.getX();
        int y = evt.getY();
        System.out.println(x+", "+y);
        int xK=0;
        int yK=0;
        if(x<26&&x>32)xK=0;
        else if(x<52&&x>58)xK=1;
        else if(x<78&&x>84)xK=2;
        else if(x<103&&x>110)xK=3;
        else if(x<129&&x>135)xK=4;
        else if(x<155&&x>160)xK=5;
        else if(x<181&&x>187)xK=6;
        else if(x<207&&x>213)xK=7;
        else if(x<233&&x>239)xK=8;
        else if(x<259&&x>267)xK=9;
        else xK=-1;
        
        if(y<233&&y>239)yK=0;
        else if(y<207&&y>213)yK=1;
        else if(y<181&&y>187)yK=2;
        else if(y<155&&y>161)yK=3;
        else if(y<129&&y>135)yK=4;
        else if(y<103&&y>109)yK=5;
        else if(y<77&&y>83)yK=6;
        else if(y<51&&y>57)yK=7;
        else if(y<25&&y>31)yK=8;
        else yK=-1;
        
        Loesung(xK, yK);
    }//GEN-LAST:event_KoordinatensystemMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AufgabenLabel;
    private javax.swing.JLabel DruckButton;
    private javax.swing.JLabel EintragOeffnenLabel;
    private javax.swing.JLabel ErklaerungLabel;
    private javax.swing.JLabel Hintergrund;
    private javax.swing.JLabel Koordinatensystem;
    private javax.swing.JButton NeuButton;
    private javax.swing.JLabel Punkt;
    private javax.swing.JLabel UeberschriftLabel;
    private javax.swing.JButton ZurueckButton;
    // End of variables declaration//GEN-END:variables
}

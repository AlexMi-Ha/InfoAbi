 

import java.awt.Color;
import java.awt.event.KeyEvent;
import javax.swing.SwingUtilities;

/**
 *
 * @author Manuel Mayr
 */
public class B_RechengesetzeAG extends javax.swing.JPanel {

    private Assistent Assistent=new Assistent();
    public boolean Pruefung;
    public boolean Eingabe;
    public String Fehler;

    private int eins;
    private int zwei;
    private int drei;
    private boolean plus1;
    private boolean plus2;
    private int Teilergebnis;
    private int Ergebnis;
    
    public B_RechengesetzeAG() {
        Assistent.setBounds(430, 120, 250, 250);
        add(Assistent);
        initComponents();
        Reset();
    }

    public void Reset() {
        Assistent.setText("Rechne geschickt mit Hilfe des Assoziativgesetzes, bestätige Deine Eingabe mit Enter.<br>Viel Erfolg!");
        Assistent.setColor(Color.BLACK);
        DruckButton.setVisible(false);
        DruckButton.setEnabled(false);
        Eingabe=false;
        Fehler="";

        eins=(int)(Math.random()*100);
        if(Math.random()<0.5) {
            plus1=true;
            zwei=((int)(Math.random()*10))*10-(eins%10);
            Teilergebnis=eins+zwei;
        } else {
            plus1=false;
            zwei=((int)(Math.random()*10))*10+(eins%10);
            Teilergebnis=eins-zwei;
            while(Teilergebnis<1) {
                eins+=10;
                zwei=((int)(Math.random()*10))*10+(eins%10);
                Teilergebnis=eins-zwei;
            }
        }
        drei=(int)(Math.random()*100);
        if(Math.random()<0.5) {
            plus2=false;
            Ergebnis=Teilergebnis-drei;
            while(Ergebnis<1) {
                
            }
            ZeichenLabel.setText("-");
            if(plus1)AufgabenLabel.setText("( "+eins+" + "+zwei+" ) - "+drei+" =");
            else AufgabenLabel.setText("( "+eins+" - "+zwei+" ) - "+drei+" =");
        } else {
            plus2=true;
            Ergebnis=Teilergebnis+drei;
            ZeichenLabel.setText("+");
            if(plus1)AufgabenLabel.setText("( "+eins+" + "+zwei+" ) + "+drei+" =");
            else AufgabenLabel.setText("( "+eins+" - "+zwei+" ) + "+drei+" =");
        }
        TeilField1.setText("");
        TeilField2.setText("");
        LoesungField.setText("");
        TeilField1.requestFocus();
    }
    
    public void drucken() {
        String a="Addition und Subtraktion natürlicher Zahlen - Rechengesetze";
        String b=AufgabenLabel.getText();
        String c=TeilField1.getText()+ZeichenLabel.getText()+TeilField2.getText()+"="+LoesungField.getText()+" falsch. Richtig: "+Teilergebnis+ZeichenLabel.getText()+drei+Ergebnis;
        Drucker d = new Drucker(a,b,c);
    }
    
    public void Loesung() {
        try {
            int Loesung=Integer.parseInt(LoesungField.getText());
            int teil1=Integer.parseInt(TeilField1.getText());
            int teil2=Integer.parseInt(TeilField2.getText());
            if(!Eingabe){
                Eingabe=true;
                if(!Pruefung) {
                    if(Loesung==Ergebnis) {
                        Assistent.setColor(Color.GREEN);
                        Assistent.setText("Du hast die Aufgabe richtig gelöst!<br>Gut gemacht!");
                    } else {
                        Assistent.setColor(Color.RED);
                        DruckButton.setVisible(true);
                        DruckButton.setEnabled(true);
                        String text="Das ist falsch, ";
                        if(teil1!=Teilergebnis)text+="Du hast das Teilergebnis falsch berechnet, das richtige Teilergebnis ist "+Teilergebnis+". ";
                        if(teil2!=drei) text+="Du hast "+drei+" falsch übertragen. ";
                        text+="<br>Das richtige Endergebnis ist "+Ergebnis+"<br>Versuche es nochmal!";
                        Assistent.setText(text);
                    }
                } else {
                    //Pruefung Code
                }
            } else {
                Assistent.setText("Du hast diese Aufgabe schon bearbeitet.<br>Klicke auf Neue Aufgabe!");
            }
        } catch(Exception e) {
            Assistent.setText("Du hast keine Zahl eingegeben, bitte gib eine Zahl ein und versuche es nochmal.");
        }
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        UeberschriftLabel = new javax.swing.JLabel();
        ErklaerungLabel = new javax.swing.JLabel();
        ZurueckButton = new javax.swing.JButton();
        NeuButton = new javax.swing.JButton();
        DruckButton = new javax.swing.JLabel();
        EintragOeffnenLabel = new javax.swing.JLabel();
        AufgabenLabel = new javax.swing.JLabel();
        LoesungField = new javax.swing.JTextField();
        TeilField2 = new javax.swing.JTextField();
        TeilField1 = new javax.swing.JTextField();
        ZeichenLabel1 = new javax.swing.JLabel();
        ZeichenLabel = new javax.swing.JLabel();
        Hintergrund = new javax.swing.JLabel();

        setLayout(null);

        UeberschriftLabel.setFont(new java.awt.Font("Georgia", 1, 26)); // NOI18N
        UeberschriftLabel.setForeground(new java.awt.Color(255, 255, 255));
        UeberschriftLabel.setText("Addition und Subtraktion natürlicher Zahlen");
        add(UeberschriftLabel);
        UeberschriftLabel.setBounds(36, 31, 640, 26);

        ErklaerungLabel.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        ErklaerungLabel.setForeground(new java.awt.Color(255, 255, 255));
        ErklaerungLabel.setText("Rechengesetze und Rechenvorteile");
        add(ErklaerungLabel);
        ErklaerungLabel.setBounds(36, 63, 320, 21);

        ZurueckButton.setText("Zurück");
        ZurueckButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ZurueckButtonActionPerformed(evt);
            }
        });
        add(ZurueckButton);
        ZurueckButton.setBounds(30, 450, 80, 23);

        NeuButton.setText("<html>Nächste<br>Aufgabe</html>");
        NeuButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NeuButtonActionPerformed(evt);
            }
        });
        add(NeuButton);
        NeuButton.setBounds(330, 350, 70, 40);

        DruckButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/DruckIcon.png"))); // NOI18N
        DruckButton.setToolTipText("Drucken");
        DruckButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        DruckButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DruckButtonMouseClicked(evt);
            }
        });
        add(DruckButton);
        DruckButton.setBounds(560, 420, 30, 30);

        EintragOeffnenLabel.setBackground(new java.awt.Color(255, 255, 255));
        EintragOeffnenLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        EintragOeffnenLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EintragOeffnenLabelMouseClicked(evt);
            }
        });
        add(EintragOeffnenLabel);
        EintragOeffnenLabel.setBounds(430, 120, 250, 250);

        AufgabenLabel.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        AufgabenLabel.setForeground(new java.awt.Color(255, 255, 255));
        AufgabenLabel.setText("jLabel1");
        add(AufgabenLabel);
        AufgabenLabel.setBounds(50, 190, 140, 30);

        LoesungField.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        LoesungField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                LoesungFieldKeyPressed(evt);
            }
        });
        add(LoesungField);
        LoesungField.setBounds(230, 230, 60, 28);

        TeilField2.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        add(TeilField2);
        TeilField2.setBounds(140, 230, 60, 28);

        TeilField1.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        add(TeilField1);
        TeilField1.setBounds(50, 230, 60, 28);

        ZeichenLabel1.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        ZeichenLabel1.setForeground(new java.awt.Color(255, 255, 255));
        ZeichenLabel1.setText("=");
        add(ZeichenLabel1);
        ZeichenLabel1.setBounds(210, 230, 30, 30);

        ZeichenLabel.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        ZeichenLabel.setForeground(new java.awt.Color(255, 255, 255));
        ZeichenLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ZeichenLabel.setText("+");
        add(ZeichenLabel);
        ZeichenLabel.setBounds(110, 230, 30, 30);

        Hintergrund.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Hintergrund.jpg"))); // NOI18N
        add(Hintergrund);
        Hintergrund.setBounds(0, 0, 700, 500);
    }// </editor-fold>//GEN-END:initComponents

    private void ZurueckButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ZurueckButtonActionPerformed
        Reset();
        if(!Pruefung)((Frame)(SwingUtilities.getRoot(this))).PerformBackAction(9);
    }//GEN-LAST:event_ZurueckButtonActionPerformed

    private void NeuButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NeuButtonActionPerformed
        if(Eingabe){
            if(!Pruefung) Reset();
            else ;
        } else {
            Assistent.setText("Du hast die Aufgabe noch nicht bearbeitet.<br>Bearbeite zuerst die Aufgabe, bevor du eine neue bekommst!");
        }
    }//GEN-LAST:event_NeuButtonActionPerformed

    private void DruckButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DruckButtonMouseClicked
        drucken();
    }//GEN-LAST:event_DruckButtonMouseClicked

    private void EintragOeffnenLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EintragOeffnenLabelMouseClicked
        if(!Pruefung){
            Eintrag e = new Eintrag();
            e.EintragAusgeben(8);
            e.setVisible(true);
        }
    }//GEN-LAST:event_EintragOeffnenLabelMouseClicked

    private void LoesungFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_LoesungFieldKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_ENTER)Loesung();
    }//GEN-LAST:event_LoesungFieldKeyPressed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AufgabenLabel;
    private javax.swing.JLabel DruckButton;
    private javax.swing.JLabel EintragOeffnenLabel;
    private javax.swing.JLabel ErklaerungLabel;
    private javax.swing.JLabel Hintergrund;
    private javax.swing.JTextField LoesungField;
    private javax.swing.JButton NeuButton;
    private javax.swing.JTextField TeilField1;
    private javax.swing.JTextField TeilField2;
    private javax.swing.JLabel UeberschriftLabel;
    private javax.swing.JLabel ZeichenLabel;
    private javax.swing.JLabel ZeichenLabel1;
    private javax.swing.JButton ZurueckButton;
    // End of variables declaration//GEN-END:variables
}

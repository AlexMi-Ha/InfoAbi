 

import java.awt.Color;

/**
 *
 * @author Manuel Mayr
 */
public class Assistent extends javax.swing.JPanel {


    public Assistent() {
        initComponents();
        Reset();
    }

    public void Reset() {
        setColor(Color.BLACK);
        setText("Hallo, ich bin Dein persönlicher Assistent!<br>Ich werde Dir alle Aufgaben erklären. Ist Dir ein Thema unklar, klicke mich an, und ein Eintrag zu dem Thema wird angezeigt!<br><br>Viel Spaß und Erfolg!");
    }
    
    public void setText(String text) {
        TextLabel.setText("<html>"+text+"</html>");
    }
    
    public void setColor(Color c) {
        TextLabel.setForeground(c);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        TextLabel = new javax.swing.JLabel();
        Hintergrund = new javax.swing.JLabel();

        setLayout(null);

        TextLabel.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        TextLabel.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        add(TextLabel);
        TextLabel.setBounds(10, 13, 120, 190);

        Hintergrund.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Assistent.jpg"))); // NOI18N
        add(Hintergrund);
        Hintergrund.setBounds(0, 0, 250, 250);
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Hintergrund;
    private javax.swing.JLabel TextLabel;
    // End of variables declaration//GEN-END:variables
}

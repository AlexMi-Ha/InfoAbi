 

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.PrintJob;
import java.awt.Toolkit;
import javax.swing.ImageIcon;

/**
 * Klasse zum Drucken von falsch beantworteten Aufgaben im Übungsmodus
 * @author Manuel Mayr
 */
public class Drucker {
    /**
     * Konstruktor
     * @param titel Überschrift und Unterüberschrift
     * @param Aufgabe gestellte Aufgabe
     * @param Fehler gemachter Fehler und richtige Lösung
     */
    public Drucker(String titel, String Aufgabe, String Fehler)
    {
        Toolkit tk = Toolkit.getDefaultToolkit();
        PrintJob pj = tk.getPrintJob( new java.awt.Frame(), "", null );
        Graphics g = pj.getGraphics();
        g.setFont(new Font("Arial", 16, 0));
        g.drawString("Mathe-Hilfe 5", 150, 60);
        g.drawString(titel, 60, 88);
        g.drawString(Aufgabe, 60, 113);
        g.drawString(Fehler, 60, 133);
        ImageIcon i = new ImageIcon("/img/Icon.png");        
        Image image=i.getImage();
        g.drawImage(image, 60, 60, null);
        pj.end();
    }
}

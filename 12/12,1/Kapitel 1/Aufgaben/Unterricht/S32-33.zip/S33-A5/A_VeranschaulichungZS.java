 

import java.awt.Color;
import javax.swing.SwingUtilities;

/**
 *
 * @author Manuel Mayr
 */
public class A_VeranschaulichungZS extends javax.swing.JPanel {

    private Assistent Assistent=new Assistent();
    public boolean Pruefung;
    public boolean Eingabe;
    public String Fehler;
    
    private int Zahl;


    public A_VeranschaulichungZS() {
        Assistent.setBounds(430, 120, 250, 250);
        add(Assistent);
        initComponents();
        Reset();
    }
    
    public void Reset() {
        Assistent.setText("Klicke die angegebene Zahl im Zahlenstrahl an.<br>Viel Erfolg!");
        Assistent.setColor(Color.BLACK);
        Zahl = ((int)(Math.random()*20)*5);
        AufgabenLabel.setText(Zahl+"");
        DruckButton.setVisible(false);
        DruckButton.setEnabled(false);
        Punkt.setVisible(false);
        Eingabe=false;
        Fehler="";
    }
    
    public void drucken() {
        String a="Natürliche Zahlen - Veranschaulichung von Zahlen";
        String b=AufgabenLabel.getText();
        String c=Fehler;
        Drucker d = new Drucker(a,b,c);
    }
    
    public void Loesung(int i) {
        if(!Eingabe){
            Eingabe=true;
            if(!Pruefung){
                if(i==Zahl) {
                    Assistent.setText("Du hast die richtige Zahl gedrückt.<br>Gut gemacht!");
                    Assistent.setColor(Color.GREEN);
                } else {
                    Assistent.setColor(Color.RED);
                    Fehler=i+"";
                    if(i==-1) Assistent.setText("Du hast die falsche Zahl gedrückt.<br>Die richtige Zahl zeigt der rote Punkt an.<br>Versuch es nochmal!");
                    else Assistent.setText("Du hast " + i + " gedrückt, die gesuchte Zahl war " + Zahl + ".<br>Die richtige Zahl zeigt der rote Punkt an.<br>Versuch es nochmal!");
                    Fehler="Die falsche Zahl wurde angezeigt.";
                    DruckButton.setVisible(true);
                    DruckButton.setEnabled(true);
                    Punkt.setVisible(true);
                    Punkt.setBounds((int)((17.2*(Zahl/5))+27), 141, 10, 10);
                }
            } else {
                //Code Pruefung
            }
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        EintragOeffnenLabel = new javax.swing.JLabel();
        UeberschriftLabel = new javax.swing.JLabel();
        ErklaerungLabel = new javax.swing.JLabel();
        ZurueckButton = new javax.swing.JButton();
        NeuButton = new javax.swing.JButton();
        Punkt = new javax.swing.JLabel();
        Zahlenstrahl = new javax.swing.JLabel();
        AufgabenLabel = new javax.swing.JLabel();
        DruckButton = new javax.swing.JLabel();
        Hintergrund = new javax.swing.JLabel();

        setLayout(null);

        EintragOeffnenLabel.setBackground(new java.awt.Color(255, 255, 255));
        EintragOeffnenLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        EintragOeffnenLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EintragOeffnenLabelMouseClicked(evt);
            }
        });
        add(EintragOeffnenLabel);
        EintragOeffnenLabel.setBounds(430, 120, 250, 250);

        UeberschriftLabel.setFont(new java.awt.Font("Georgia", 1, 26)); // NOI18N
        UeberschriftLabel.setForeground(new java.awt.Color(255, 255, 255));
        UeberschriftLabel.setText("Natürliche Zahlen");
        add(UeberschriftLabel);
        UeberschriftLabel.setBounds(36, 31, 244, 26);

        ErklaerungLabel.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        ErklaerungLabel.setForeground(new java.awt.Color(255, 255, 255));
        ErklaerungLabel.setText("Veranschaulichung von Zahlen");
        add(ErklaerungLabel);
        ErklaerungLabel.setBounds(36, 63, 270, 21);

        ZurueckButton.setText("Zurück");
        ZurueckButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ZurueckButtonActionPerformed(evt);
            }
        });
        add(ZurueckButton);
        ZurueckButton.setBounds(30, 450, 80, 23);

        NeuButton.setText("<html>Nächste<br>Aufgabe</html>");
        NeuButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NeuButtonActionPerformed(evt);
            }
        });
        add(NeuButton);
        NeuButton.setBounds(330, 350, 70, 40);

        Punkt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/punkt.jpg"))); // NOI18N
        add(Punkt);
        Punkt.setBounds(70, 150, 10, 10);

        Zahlenstrahl.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Zahlenstrahl.jpg"))); // NOI18N
        Zahlenstrahl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ZahlenstrahlMouseClicked(evt);
            }
        });
        add(Zahlenstrahl);
        Zahlenstrahl.setBounds(28, 130, 370, 50);

        AufgabenLabel.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        AufgabenLabel.setForeground(new java.awt.Color(255, 255, 255));
        AufgabenLabel.setText("10");
        add(AufgabenLabel);
        AufgabenLabel.setBounds(50, 200, 34, 14);

        DruckButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/DruckIcon.png"))); // NOI18N
        DruckButton.setToolTipText("Drucken");
        DruckButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        DruckButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DruckButtonMouseClicked(evt);
            }
        });
        add(DruckButton);
        DruckButton.setBounds(560, 420, 30, 30);

        Hintergrund.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Hintergrund.jpg"))); // NOI18N
        add(Hintergrund);
        Hintergrund.setBounds(0, 0, 700, 500);
    }// </editor-fold>//GEN-END:initComponents

    private void EintragOeffnenLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EintragOeffnenLabelMouseClicked
        if(!Pruefung){
            Eintrag e = new Eintrag();
            e.EintragAusgeben(2);
            e.setVisible(true);
        }
    }//GEN-LAST:event_EintragOeffnenLabelMouseClicked

    private void ZurueckButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ZurueckButtonActionPerformed
        if(!Pruefung)((Frame)(SwingUtilities.getRoot(this))).PerformBackAction(2);
    }//GEN-LAST:event_ZurueckButtonActionPerformed

    private void NeuButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NeuButtonActionPerformed
        if(!Pruefung) Reset();
        else ;
    }//GEN-LAST:event_NeuButtonActionPerformed

    private void DruckButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DruckButtonMouseClicked
        drucken();
    }//GEN-LAST:event_DruckButtonMouseClicked

    private void ZahlenstrahlMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ZahlenstrahlMouseClicked
        int a = evt.getX();
        System.out.println(a);    
        
            if(a>4&&a<10) Loesung(0);
            else if(a>21&&a<27) Loesung(5);
            else if(a>38&&a<42) Loesung(10);
            else if(a>53&&a<62) Loesung(15);
            else if(a>73&&a<79) Loesung(20);
            else if(a>90&&a<96) Loesung(25);
            else if(a>107&&a<113) Loesung(30);
            else if(a>124&&a<131) Loesung(35);
            else if(a>141&&a<150) Loesung(40);
            else if(a>159&&a<165) Loesung(45);
            else if(a>176&&a<182) Loesung(50);
            else if(a>193&&a<199) Loesung(55);
            else if(a>210&&a<216) Loesung(60);
            else if(a>227&&a<235) Loesung(65);
            else if(a>244&&a<253) Loesung(70);
            else if(a>262&&a<269) Loesung(75);
            else if(a>279&&a<285) Loesung(80);
            else if(a>296&&a<305) Loesung(85);
            else if(a>313&&a<322) Loesung(90);
            else if(a>331&&a<339) Loesung(95);
            else if(a>348&&a<354) Loesung(100);
            else Loesung(-1);
    }//GEN-LAST:event_ZahlenstrahlMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AufgabenLabel;
    private javax.swing.JLabel DruckButton;
    private javax.swing.JLabel EintragOeffnenLabel;
    private javax.swing.JLabel ErklaerungLabel;
    private javax.swing.JLabel Hintergrund;
    private javax.swing.JButton NeuButton;
    private javax.swing.JLabel Punkt;
    private javax.swing.JLabel UeberschriftLabel;
    private javax.swing.JLabel Zahlenstrahl;
    private javax.swing.JButton ZurueckButton;
    // End of variables declaration//GEN-END:variables
}

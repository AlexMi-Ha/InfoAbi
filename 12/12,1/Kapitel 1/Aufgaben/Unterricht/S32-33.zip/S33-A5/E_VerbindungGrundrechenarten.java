 

import java.awt.Color;
import java.awt.event.KeyEvent;
import javax.swing.SwingUtilities;

/**
 *
 * @author Manuel Mayr
 */
public class E_VerbindungGrundrechenarten extends javax.swing.JPanel {

    private Assistent Assistent=new Assistent();
    public boolean Pruefung;
    public boolean Eingabe;
    public String Fehler;

    private int Eins;
    private int Zwei;
    private int Drei;
    private boolean plus;
    private boolean mal;
    private int Ergebnis;
    
    public E_VerbindungGrundrechenarten() {
        Assistent.setBounds(430, 120, 250, 250);
        add(Assistent);
        initComponents();
        Reset();
    }

    public void Reset() {
        Assistent.setText("Berechne den richtigen Termwert, bestätige mit Enter.<br>Viel Erfolg!");
        Assistent.setColor(Color.BLACK);
        DruckButton.setVisible(false);
        DruckButton.setEnabled(false);
        Eingabe=false;
        Fehler="";
        
        Eins=(int)(Math.random()*10);
        Drei=(int)(Math.random()*10);
        Zwei=Drei*(int)(Math.random()*4);
        if(Math.random()<0.5) plus=true;
        else plus = false;
        if(Math.random()<0.5) {
            mal=true;
            if(plus) {
                Ergebnis=Eins+Zwei*Drei;
                AufgabenLabel.setText(Eins+" + "+Zwei+" * "+Drei+" =");
            } else {
                Ergebnis=Eins-Zwei*Drei;
                AufgabenLabel.setText(Eins+" - "+Zwei+" * "+Drei+" =");
            }
        } else {
            mal=false;
            if(plus) {
                Ergebnis=Eins+Zwei/Drei;
                AufgabenLabel.setText(Eins+" + "+Zwei+" : "+Drei+" =");
            } else {
                Ergebnis=Eins-Zwei/Drei;
                AufgabenLabel.setText(Eins+" - "+Zwei+" : "+Drei+" =");
            }
        }
        LoesungField.setText("");
        LoesungField.requestFocus();
    }
    
    public void drucken() {
        String a="Multiplikation und Divison natürlicher Zahlen - Verbindung der Grundrechenarten";
        String b=AufgabenLabel.getText();
        String c=LoesungField.getText()+" falsch. Richtig: "+Ergebnis;
        Drucker d = new Drucker(a,b,c);
    }
    
    public void Loesung() {
        try {
            int i= Integer.parseInt(LoesungField.getText());
            if(!Eingabe){
                Eingabe=true;
                if(!Pruefung) {
                    if(i==Ergebnis) {
                        Assistent.setColor(Color.GREEN);
                        Assistent.setText("Das ist richtig!<br>Gut gemacht!");
                    } else {
                        Assistent.setColor(Color.RED);
                        DruckButton.setVisible(true);
                        DruckButton.setEnabled(true);
                        String text="Das ist falsch. ";
                        if(mal&&plus&&i==(Eins+Zwei)*Drei) text+="Du hast die Regel Punkt vor Strich nicht beachtet.";
                        else if(mal&&!plus&&i==(Eins-Zwei)*Drei) text+="Du hast die Regel Punkt vor Strich nicht beachtet.";
                        else if(!mal&&plus&&i==(Eins+Zwei)/Drei) text+="Du hast die Regel Punkt vor Strich nicht beachtet.";
                        else if(!mal&&!plus&&i==(Eins-Zwei)/Drei) text+="Du hast die Regel Punkt vor Strich nicht beachtet.";
                        text+="<br>Das richtige Ergebnis ist "+Ergebnis+".<br>Versuche es nochmal!";
                        Assistent.setText(text);
                    }
                } else {
                    //Pruefung Code
                }
            } else {
                Assistent.setText("Du hast diese Aufgabe schon bearbeitet.<br>Klicke auf Neue Aufgabe!");
            }
        } catch(Exception e) {
            Assistent.setText("Du hast keine Zahl eingegeben, bitte gib eine Zahl ein und versuche es nochmal.");
        }
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        UeberschriftLabel = new javax.swing.JLabel();
        ErklaerungLabel = new javax.swing.JLabel();
        AufgabenLabel = new javax.swing.JLabel();
        LoesungField = new javax.swing.JTextField();
        NeuButton = new javax.swing.JButton();
        ZurueckButton = new javax.swing.JButton();
        DruckButton = new javax.swing.JLabel();
        EintragOeffnenLabel = new javax.swing.JLabel();
        Hintergrund = new javax.swing.JLabel();

        setLayout(null);

        UeberschriftLabel.setFont(new java.awt.Font("Georgia", 1, 26)); // NOI18N
        UeberschriftLabel.setForeground(new java.awt.Color(255, 255, 255));
        UeberschriftLabel.setText("Multiplikation und Division natürlicher Zahlen");
        add(UeberschriftLabel);
        UeberschriftLabel.setBounds(36, 31, 640, 26);

        ErklaerungLabel.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        ErklaerungLabel.setForeground(new java.awt.Color(255, 255, 255));
        ErklaerungLabel.setText("Verbindung der Grundrechenarten");
        add(ErklaerungLabel);
        ErklaerungLabel.setBounds(36, 63, 310, 21);

        AufgabenLabel.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        AufgabenLabel.setForeground(new java.awt.Color(255, 255, 255));
        AufgabenLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        AufgabenLabel.setText("jLabel1");
        add(AufgabenLabel);
        AufgabenLabel.setBounds(80, 190, 210, 30);

        LoesungField.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        LoesungField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                LoesungFieldKeyPressed(evt);
            }
        });
        add(LoesungField);
        LoesungField.setBounds(300, 190, 80, 28);

        NeuButton.setText("<html>Nächste<br>Aufgabe</html>");
        NeuButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NeuButtonActionPerformed(evt);
            }
        });
        add(NeuButton);
        NeuButton.setBounds(330, 350, 70, 40);

        ZurueckButton.setText("Zurück");
        ZurueckButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ZurueckButtonActionPerformed(evt);
            }
        });
        add(ZurueckButton);
        ZurueckButton.setBounds(30, 450, 80, 23);

        DruckButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/DruckIcon.png"))); // NOI18N
        DruckButton.setToolTipText("Drucken");
        DruckButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        DruckButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DruckButtonMouseClicked(evt);
            }
        });
        add(DruckButton);
        DruckButton.setBounds(560, 420, 30, 30);

        EintragOeffnenLabel.setBackground(new java.awt.Color(255, 255, 255));
        EintragOeffnenLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        EintragOeffnenLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EintragOeffnenLabelMouseClicked(evt);
            }
        });
        add(EintragOeffnenLabel);
        EintragOeffnenLabel.setBounds(430, 120, 250, 250);

        Hintergrund.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Hintergrund.jpg"))); // NOI18N
        add(Hintergrund);
        Hintergrund.setBounds(0, 0, 700, 500);
    }// </editor-fold>//GEN-END:initComponents

    private void LoesungFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_LoesungFieldKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_ENTER)Loesung();
    }//GEN-LAST:event_LoesungFieldKeyPressed

    private void NeuButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NeuButtonActionPerformed
        if(Eingabe){
            if(!Pruefung) Reset();
            else ;
        } else {
            Assistent.setText("Du hast die Aufgabe noch nicht bearbeitet.<br>Bearbeite zuerst die Aufgabe, bevor du eine neue bekommst!");
        }
    }//GEN-LAST:event_NeuButtonActionPerformed

    private void ZurueckButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ZurueckButtonActionPerformed
        Reset();
        if(!Pruefung)((Frame)(SwingUtilities.getRoot(this))).PerformBackAction(24);
    }//GEN-LAST:event_ZurueckButtonActionPerformed

    private void DruckButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DruckButtonMouseClicked
        drucken();
    }//GEN-LAST:event_DruckButtonMouseClicked

    private void EintragOeffnenLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EintragOeffnenLabelMouseClicked
        if(!Pruefung){
            Eintrag e = new Eintrag();
            e.EintragAusgeben(17);
            e.setVisible(true);
        }
    }//GEN-LAST:event_EintragOeffnenLabelMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AufgabenLabel;
    private javax.swing.JLabel DruckButton;
    private javax.swing.JLabel EintragOeffnenLabel;
    private javax.swing.JLabel ErklaerungLabel;
    private javax.swing.JLabel Hintergrund;
    private javax.swing.JTextField LoesungField;
    private javax.swing.JButton NeuButton;
    private javax.swing.JLabel UeberschriftLabel;
    private javax.swing.JButton ZurueckButton;
    // End of variables declaration//GEN-END:variables
}

 

import java.awt.Color;
import javax.swing.SwingUtilities;

/**
 *
 * @author Manuel Mayr
 */
public class A_Primzahlbestimmung extends javax.swing.JPanel {

    private Assistent Assistent=new Assistent();
    public boolean Pruefung;
    public boolean Eingabe;
    public String Fehler;

    private int Zahl;
    private boolean istPrimzahl;
    
    public A_Primzahlbestimmung() {
        Assistent.setBounds(430, 120, 250, 250);
        add(Assistent);
        initComponents();
        Reset();
    }

    public void Reset() {
        Assistent.setText("Bestimme, ob die angezeigte Zahl eine Primzahl ist.<br>Viel Erfolg!");
        Assistent.setColor(Color.BLACK);
        DruckButton.setVisible(false);
        DruckButton.setEnabled(false);
        Eingabe=false;
        Fehler="";
        
        Zahl=(int)(Math.random()*100);
        istPrimzahl=true;
        if(Zahl==0)istPrimzahl=false;
        for(int i=2; i<Zahl-2;i++) {   
            if(Zahl%i==0) {
                istPrimzahl=false;
                break;
            }
        }
        AufgabenLabel.setText(Zahl+"");
    }
    
    public void drucken() {
        String a="Natürliche Zahlen - Zahlenmengen";
        String b="Bestimme, ob "+Zahl+" eine Primzahl ist";
        String c="";
        if(istPrimzahl) c=Zahl+" ist eine Primzahl";
        else c=Zahl+" ist keine Primzahl";
        Drucker d = new Drucker(a,b,c);
    }
    
    public void Loesung(boolean b) {
        if(!Eingabe){
            Eingabe=true;
            if(!Pruefung) {
                if(istPrimzahl==b) {
                    Assistent.setColor(Color.GREEN);
                    if(b)Assistent.setText("Das ist richtig, "+Zahl+" ist eine Primzahl!<br>Gut gemacht!");
                    else Assistent.setText("Das ist richtig, "+Zahl+" ist keine Primzahl!<br>Gut gemacht!");
                } else {
                    Assistent.setColor(Color.RED);
                    if(b)Assistent.setText("Das ist falsch, "+Zahl+" ist eine Primzahl.<br>Versuch es nochmal!");
                    else Assistent.setText("Das ist falsch, "+Zahl+" ist keine Primzahl.<br>Versuch es nochmal!");
                    DruckButton.setVisible(true);
                    DruckButton.setEnabled(true);
                }
            } else {
                //Pruefung Code
            }
        } else {
            Assistent.setText("Du hast diese Aufgabe schon bearbeitet.<br>Klicke auf Neue Aufgabe!");
        }
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        EintragOeffnenLabel = new javax.swing.JLabel();
        UeberschriftLabel = new javax.swing.JLabel();
        ErklaerungLabel = new javax.swing.JLabel();
        NeuButton = new javax.swing.JButton();
        ZurueckButton = new javax.swing.JButton();
        DruckButton = new javax.swing.JLabel();
        AufgabenLabel = new javax.swing.JLabel();
        NeinLabel = new javax.swing.JLabel();
        JaLabel = new javax.swing.JLabel();
        NeinButton = new javax.swing.JLabel();
        JaButton = new javax.swing.JLabel();
        Hintergrund = new javax.swing.JLabel();

        setLayout(null);

        EintragOeffnenLabel.setBackground(new java.awt.Color(255, 255, 255));
        EintragOeffnenLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        EintragOeffnenLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EintragOeffnenLabelMouseClicked(evt);
            }
        });
        add(EintragOeffnenLabel);
        EintragOeffnenLabel.setBounds(430, 120, 250, 250);

        UeberschriftLabel.setFont(new java.awt.Font("Georgia", 1, 26)); // NOI18N
        UeberschriftLabel.setForeground(new java.awt.Color(255, 255, 255));
        UeberschriftLabel.setText("Natürliche Zahlen");
        add(UeberschriftLabel);
        UeberschriftLabel.setBounds(36, 31, 244, 26);

        ErklaerungLabel.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        ErklaerungLabel.setForeground(new java.awt.Color(255, 255, 255));
        ErklaerungLabel.setText("Zahlenmengen");
        add(ErklaerungLabel);
        ErklaerungLabel.setBounds(36, 63, 121, 21);

        NeuButton.setText("<html>Nächste<br>Aufgabe</html>");
        NeuButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NeuButtonActionPerformed(evt);
            }
        });
        add(NeuButton);
        NeuButton.setBounds(330, 350, 70, 40);

        ZurueckButton.setText("Zurück");
        ZurueckButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ZurueckButtonActionPerformed(evt);
            }
        });
        add(ZurueckButton);
        ZurueckButton.setBounds(30, 450, 80, 23);

        DruckButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/DruckIcon.png"))); // NOI18N
        DruckButton.setToolTipText("Drucken");
        DruckButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        DruckButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DruckButtonMouseClicked(evt);
            }
        });
        add(DruckButton);
        DruckButton.setBounds(560, 420, 30, 30);

        AufgabenLabel.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        AufgabenLabel.setForeground(new java.awt.Color(255, 255, 255));
        AufgabenLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        AufgabenLabel.setText("100");
        add(AufgabenLabel);
        AufgabenLabel.setBounds(130, 210, 40, 22);

        NeinLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        NeinLabel.setForeground(new java.awt.Color(255, 255, 255));
        NeinLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        NeinLabel.setText("nein");
        NeinLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        NeinLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                NeinLabelMouseClicked(evt);
            }
        });
        add(NeinLabel);
        NeinLabel.setBounds(220, 240, 70, 29);

        JaLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        JaLabel.setForeground(new java.awt.Color(255, 255, 255));
        JaLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        JaLabel.setText("ja");
        JaLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JaLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                JaLabelMouseClicked(evt);
            }
        });
        add(JaLabel);
        JaLabel.setBounds(220, 170, 70, 29);

        NeinButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Button_ZaehlenOrdnen.png"))); // NOI18N
        NeinButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        NeinButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                NeinButtonMouseClicked(evt);
            }
        });
        add(NeinButton);
        NeinButton.setBounds(210, 230, 95, 55);
        NeinButton.getAccessibleContext().setAccessibleName("NeinButton");

        JaButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Button_ZaehlenOrdnen.png"))); // NOI18N
        JaButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JaButton.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                JaButtonKeyPressed(evt);
            }
        });
        add(JaButton);
        JaButton.setBounds(210, 160, 95, 55);

        Hintergrund.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Hintergrund.jpg"))); // NOI18N
        add(Hintergrund);
        Hintergrund.setBounds(0, 0, 700, 500);
    }// </editor-fold>//GEN-END:initComponents

    private void EintragOeffnenLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EintragOeffnenLabelMouseClicked
        if(!Pruefung){
            Eintrag e = new Eintrag();
            e.EintragAusgeben(5);
            e.setVisible(true);
        }
    }//GEN-LAST:event_EintragOeffnenLabelMouseClicked

    private void NeuButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NeuButtonActionPerformed
        if(Eingabe){
            if(!Pruefung) Reset();
            else ;
        } else {
            Assistent.setText("Du hast die Aufgabe noch nicht bearbeitet.<br>Bearbeite zuerst die Aufgabe, bevor du eine neue bekommst!");
        }
    }//GEN-LAST:event_NeuButtonActionPerformed

    private void ZurueckButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ZurueckButtonActionPerformed
        Reset();
        if(!Pruefung)((Frame)(SwingUtilities.getRoot(this))).PerformBackAction(5);
    }//GEN-LAST:event_ZurueckButtonActionPerformed

    private void DruckButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DruckButtonMouseClicked
        drucken();
    }//GEN-LAST:event_DruckButtonMouseClicked

    private void JaButtonKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JaButtonKeyPressed
        Loesung(true);
    }//GEN-LAST:event_JaButtonKeyPressed

    private void NeinButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_NeinButtonMouseClicked
        Loesung(false);
    }//GEN-LAST:event_NeinButtonMouseClicked

    private void JaLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JaLabelMouseClicked
        Loesung(true);
    }//GEN-LAST:event_JaLabelMouseClicked

    private void NeinLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_NeinLabelMouseClicked
        Loesung(false);
    }//GEN-LAST:event_NeinLabelMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AufgabenLabel;
    private javax.swing.JLabel DruckButton;
    private javax.swing.JLabel EintragOeffnenLabel;
    private javax.swing.JLabel ErklaerungLabel;
    private javax.swing.JLabel Hintergrund;
    private javax.swing.JLabel JaButton;
    private javax.swing.JLabel JaLabel;
    private javax.swing.JLabel NeinButton;
    private javax.swing.JLabel NeinLabel;
    private javax.swing.JButton NeuButton;
    private javax.swing.JLabel UeberschriftLabel;
    private javax.swing.JButton ZurueckButton;
    // End of variables declaration//GEN-END:variables
}

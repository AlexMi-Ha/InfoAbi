 

import java.awt.Color;
import java.awt.event.KeyEvent;
import javax.swing.SwingUtilities;

/**
 *
 * @author Manuel Mayr
 */
public class D_Winkel extends javax.swing.JPanel {

    private Assistent Assistent=new Assistent();
    public boolean Pruefung;
    public boolean Eingabe;
    public String Fehler;

    private int min;
    private int max;
    
    public D_Winkel() {
        Assistent.setBounds(430, 120, 250, 250);
        add(Assistent);
        initComponents();
        Reset();
    }

    public void Reset() {
        Assistent.setText("Gib die Gradzahl eines Winkels an, der der vorgegebenen Winkelart entspricht.<br>Viel Erfolg!");
        Assistent.setColor(Color.BLACK);
        DruckButton.setVisible(false);
        DruckButton.setEnabled(false);
        Eingabe=false;
        Fehler="";
        int i=(int)(Math.random()*5);
        switch(i) {
            case 0: AufgabenLabel.setText("spitzer Winkel");
                    min=0;
                    max=90;
                break;
            case 1: AufgabenLabel.setText("rechter Winkel");
                    min=89;
                    max=91;
                break;
            case 2: AufgabenLabel.setText("stumpfer Winkel");
                    min=90;
                    max=180;
                break;
            case 3: AufgabenLabel.setText("gestreckter Winkel");
                    min=179;
                    max=181;
                break;
            case 4: AufgabenLabel.setText("überstumpfter Winkel");
                    min=180;
                    max=360;
                break;
        }
        LoesungField.setText("");
        LoesungField.requestFocus();
    }
    
    public void drucken() {
        String a="Addition und Subtraktion ganzer Zahlen - Winkel";
        String b="Gib eine Anzahl an Grad an, bei der ein"+AufgabenLabel.getText()+"entsteht";
        String c=LoesungField.getText()+" falsch. Richtig: "+min+" < x < "+max;
        Drucker d = new Drucker(a,b,c);
    }
    
    public void Loesung() {
        try {
            int i=Integer.parseInt(LoesungField.getText());
            if(!Eingabe){
                Eingabe=true;
                if(!Pruefung) {
                    if(i>min&&i<max) {
                        Assistent.setColor(Color.GREEN);
                        Assistent.setText("Du hast einen richtigen Winkel angegeben!<br>Gut gemacht!");
                    } else {
                        Assistent.setColor(Color.RED);
                        Assistent.setText("Das ist falsch, ein "+AufgabenLabel.getText()+" liegt zwischen "+min+" und"+max+".<br>Versuche es nochmal!");
                    }
                } else {
                    //Pruefung Code
                }
            } else {
                Assistent.setText("Du hast diese Aufgabe schon bearbeitet.<br>Klicke auf Neue Aufgabe!");
            }
        } catch(Exception e) {
            Assistent.setText("Du hast keine Zahl eingegeben, bitte gib eine Zahl ein und versuche es nochmal."); 
        }
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        UeberschriftLabel = new javax.swing.JLabel();
        ErklaerungLabel = new javax.swing.JLabel();
        EintragOeffnenLabel = new javax.swing.JLabel();
        DruckButton = new javax.swing.JLabel();
        NeuButton = new javax.swing.JButton();
        ZurueckButton = new javax.swing.JButton();
        AufgabenLabel = new javax.swing.JLabel();
        LoesungField = new javax.swing.JTextField();
        Hintergrund = new javax.swing.JLabel();

        setLayout(null);

        UeberschriftLabel.setFont(new java.awt.Font("Georgia", 1, 26)); // NOI18N
        UeberschriftLabel.setForeground(new java.awt.Color(255, 255, 255));
        UeberschriftLabel.setText("Geometrische Grundbegriffe");
        add(UeberschriftLabel);
        UeberschriftLabel.setBounds(36, 31, 640, 26);

        ErklaerungLabel.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        ErklaerungLabel.setForeground(new java.awt.Color(255, 255, 255));
        ErklaerungLabel.setText("Winkel");
        add(ErklaerungLabel);
        ErklaerungLabel.setBounds(36, 63, 250, 21);

        EintragOeffnenLabel.setBackground(new java.awt.Color(255, 255, 255));
        EintragOeffnenLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        EintragOeffnenLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EintragOeffnenLabelMouseClicked(evt);
            }
        });
        add(EintragOeffnenLabel);
        EintragOeffnenLabel.setBounds(430, 120, 250, 250);

        DruckButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/DruckIcon.png"))); // NOI18N
        DruckButton.setToolTipText("Drucken");
        DruckButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        DruckButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DruckButtonMouseClicked(evt);
            }
        });
        add(DruckButton);
        DruckButton.setBounds(560, 420, 30, 30);

        NeuButton.setText("<html>Nächste<br>Aufgabe</html>");
        NeuButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NeuButtonActionPerformed(evt);
            }
        });
        add(NeuButton);
        NeuButton.setBounds(330, 350, 70, 40);

        ZurueckButton.setText("Zurück");
        ZurueckButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ZurueckButtonActionPerformed(evt);
            }
        });
        add(ZurueckButton);
        ZurueckButton.setBounds(30, 450, 80, 23);

        AufgabenLabel.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        AufgabenLabel.setForeground(new java.awt.Color(255, 255, 255));
        AufgabenLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        AufgabenLabel.setText("jLabel1");
        add(AufgabenLabel);
        AufgabenLabel.setBounds(80, 190, 210, 30);

        LoesungField.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        LoesungField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                LoesungFieldKeyPressed(evt);
            }
        });
        add(LoesungField);
        LoesungField.setBounds(300, 190, 80, 28);

        Hintergrund.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Hintergrund.jpg"))); // NOI18N
        add(Hintergrund);
        Hintergrund.setBounds(0, 0, 700, 500);
    }// </editor-fold>//GEN-END:initComponents

    private void EintragOeffnenLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EintragOeffnenLabelMouseClicked
        if(!Pruefung){
            Eintrag e = new Eintrag();
            e.EintragAusgeben(14);
            e.setVisible(true);
        }
    }//GEN-LAST:event_EintragOeffnenLabelMouseClicked

    private void DruckButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DruckButtonMouseClicked
        drucken();
    }//GEN-LAST:event_DruckButtonMouseClicked

    private void NeuButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NeuButtonActionPerformed
        if(Eingabe){
            if(!Pruefung) Reset();
            else ;
        } else {
            Assistent.setText("Du hast die Aufgabe noch nicht bearbeitet.<br>Bearbeite zuerst die Aufgabe, bevor du eine neue bekommst!");
        }
    }//GEN-LAST:event_NeuButtonActionPerformed

    private void ZurueckButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ZurueckButtonActionPerformed
        Reset();
        if(!Pruefung)((Frame)(SwingUtilities.getRoot(this))).PerformBackAction(19);
    }//GEN-LAST:event_ZurueckButtonActionPerformed

    private void LoesungFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_LoesungFieldKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_ENTER)Loesung();
    }//GEN-LAST:event_LoesungFieldKeyPressed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AufgabenLabel;
    private javax.swing.JLabel DruckButton;
    private javax.swing.JLabel EintragOeffnenLabel;
    private javax.swing.JLabel ErklaerungLabel;
    private javax.swing.JLabel Hintergrund;
    private javax.swing.JTextField LoesungField;
    private javax.swing.JButton NeuButton;
    private javax.swing.JLabel UeberschriftLabel;
    private javax.swing.JButton ZurueckButton;
    // End of variables declaration//GEN-END:variables
}

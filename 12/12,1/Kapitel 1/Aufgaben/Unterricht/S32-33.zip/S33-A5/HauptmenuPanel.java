 

import javax.swing.SwingUtilities;

/**
 *
 * @author Manuel Mayr
 */
public class HauptmenuPanel extends javax.swing.JPanel {

    private Assistent Assistent = new Assistent();
    
    public HauptmenuPanel() {
        Assistent.setBounds(430, 120, 250, 250);
        add(Assistent);
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList();
        PruefungLabel = new javax.swing.JLabel();
        ImpressumLabel = new javax.swing.JLabel();
        Hintergrund = new javax.swing.JLabel();

        setLayout(null);

        jList1.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Natürliche Zahlen", "   Zählen und Ordnen", "   Veranschaulichen von Zahlen", "   Dezimalsystem", "   Römische Zahlen", "   Zahlenmengen", "   Runden", "Addition und Subtraktion natürlicher Zahlen", "   Addieren und Subtrahieren", "   Rechengesetze und -vorteile", "   Terme", "Addition und Subtraktion ganzer Zahlen", "   Vorzeichenschreibweise", "   Anordnung und Betrag", "   Addieren/ Subtrahieren", "   Rechnen mit Summen und Differenzen", "Geometrische Grundbegriffe", "   Geometrische Körper", "   Parallelogramme - Umfang", "   Winkel", "Multiplikation und Division natürlicher Zahlen", "   Multiplizieren und Dividieren", "   Rechnen mit Null und Eins", "   Verbindung der Grundrechenarten", "   Rechengesetze und Rechenvorteile", "   Potenzieren", "   Terme", "Multiplikation und Division ganzer Zahlen", "   Multiplizieren", "   Dividieren", "   Rechengesetze und Rechenvorteile", "Fläche und Flächenmessung", "   Flächeninhalt des Rechtecks", "   Oberflächeninhalt des Quaders" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jList1.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jList1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jList1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jList1);

        add(jScrollPane1);
        jScrollPane1.setBounds(30, 160, 280, 300);

        PruefungLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        PruefungLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PruefungLabelMouseClicked(evt);
            }
        });
        add(PruefungLabel);
        PruefungLabel.setBounds(360, 420, 50, 20);

        ImpressumLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ImpressumLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ImpressumLabelMouseClicked(evt);
            }
        });
        add(ImpressumLabel);
        ImpressumLabel.setBounds(570, 440, 70, 20);

        Hintergrund.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/MainGUI.jpg"))); // NOI18N
        add(Hintergrund);
        Hintergrund.setBounds(0, 0, 700, 500);
    }// </editor-fold>//GEN-END:initComponents

    private void jList1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jList1MouseClicked
        int i=jList1.getSelectedIndex();
        System.out.println(i);
        ((Frame)(SwingUtilities.getRoot(this))).PerformAction(i, false);

    }//GEN-LAST:event_jList1MouseClicked

    private void ImpressumLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ImpressumLabelMouseClicked
        javax.swing.JOptionPane.showMessageDialog(this, "<html>Mathe-Hilfe 5<br>© Manuel Mayr<br>Seminararbeit am HGW, 2015</html>", "Impressum", -1);
    }//GEN-LAST:event_ImpressumLabelMouseClicked

    private void PruefungLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PruefungLabelMouseClicked
        //((Frame)(SwingUtilities.getRoot(this))).PerformAction(40, false);
        javax.swing.JOptionPane.showMessageDialog(this, "Der Prüfungsmodus ist momentan leider noch nicht verfügbar.", "Prüfungsmodus", 0);
    }//GEN-LAST:event_PruefungLabelMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Hintergrund;
    private javax.swing.JLabel ImpressumLabel;
    private javax.swing.JLabel PruefungLabel;
    private javax.swing.JList jList1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}

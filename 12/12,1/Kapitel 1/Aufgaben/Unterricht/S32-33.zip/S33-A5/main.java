 
/**
 * Klasse, welche bei Programmaufruf gestartet wird
 * @author Manuel Mayr
 */
public class main {

    /**
     * main-method
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new Frame().setVisible(true);
    }
    
}

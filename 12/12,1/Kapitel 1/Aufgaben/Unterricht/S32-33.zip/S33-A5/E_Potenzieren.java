 

import java.awt.Color;
import java.awt.event.KeyEvent;
import javax.swing.SwingUtilities;

/**
 *
 * @author Manuel Mayr
 */
public class E_Potenzieren extends javax.swing.JPanel {

    private Assistent Assistent=new Assistent();
    public boolean Pruefung;
    public boolean Eingabe;
    public String Fehler;

    private int Basis;
    private int Exponent;
    private int Ergebnis;
    
    public E_Potenzieren() {
        Assistent.setBounds(430, 120, 250, 250);
        add(Assistent);
        initComponents();
        Reset();
    }

    public void Reset() {
        Assistent.setText("Wandle erst in eine Potenz um, Berchne dann den Wert und bestätige mit Enter.<br>Viel Erfolg!");
        Assistent.setColor(Color.BLACK);
        DruckButton.setVisible(false);
        DruckButton.setEnabled(false);
        Eingabe=false;
        Fehler="";
        Basis=(int)(Math.random()*10);
        Exponent=(int)(Math.random()*3)+1;
        Ergebnis=(int)Math.pow(Basis, Exponent);
        String text=Basis+"";
        for(int i=1;i<Exponent;i++) text+=" * "+Basis;
        AufgabenLabel.setText(text+" =");
        BasisField.setText(Basis+"");
        ExponentField.requestFocus();
        ExponentField.setText("");
        LoesungField.setText("");
        
    }
    
    public void drucken() {
        String a="Multiplikation und Divison natürlicher Zahlen - Potenzieren";
        String b=AufgabenLabel.getText();
        String c=BasisField.getText()+"^"+ExponentField.getText()+"= "+LoesungField.getText()+" falsch. Richtig: "+Basis+"^"+Exponent+"="+Ergebnis;
        Drucker d = new Drucker(a,b,c);
    }
    
    public void Loesung() {
        try {
            int b=Integer.parseInt(BasisField.getText());
            int e=Integer.parseInt(ExponentField.getText());
            int i=Integer.parseInt(LoesungField.getText());
            if(!Eingabe){
                Eingabe=true;
                if(!Pruefung) {
                    if(i==Ergebnis) {
                        Assistent.setColor(Color.GREEN);
                        Assistent.setText("Das ist richtig!<br>Gut gemacht!");
                    } else {
                        Assistent.setColor(Color.RED);
                        DruckButton.setVisible(true);
                        DruckButton.setEnabled(true);
                        String text="Das ist falsch. ";
                        if(b!=Basis) text+="Du hast mit der falschen Basis gerechnet. ";
                        if(e!=Exponent) text+="Du hast den falschen Exponenten verwendet. ";
                        if(i==Basis*Exponent) text+="Du hast multipliziert, nicht potenziert.";
                        text+="<br>Das richtige Ergebnis ist "+Ergebnis+".<br>Versuche es nochmal!";
                        Assistent.setText(text);
                    }
                } else {
                    //Pruefung Code
                }
            } else {
                Assistent.setText("Du hast diese Aufgabe schon bearbeitet.<br>Klicke auf Neue Aufgabe!");
                }
        } catch(Exception e) {
            Assistent.setText("Du hast keine Zahl eingegeben, bitte gib eine Zahl ein und versuche es nochmal.");
        }
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        UeberschriftLabel = new javax.swing.JLabel();
        ErklaerungLabel = new javax.swing.JLabel();
        Label = new javax.swing.JLabel();
        EintragOeffnenLabel = new javax.swing.JLabel();
        NeuButton = new javax.swing.JButton();
        DruckButton = new javax.swing.JLabel();
        ZurueckButton = new javax.swing.JButton();
        ExponentField = new javax.swing.JTextField();
        BasisField = new javax.swing.JTextField();
        LoesungField = new javax.swing.JTextField();
        AufgabenLabel = new javax.swing.JLabel();
        Hintergrund = new javax.swing.JLabel();

        setLayout(null);

        UeberschriftLabel.setFont(new java.awt.Font("Georgia", 1, 26)); // NOI18N
        UeberschriftLabel.setForeground(new java.awt.Color(255, 255, 255));
        UeberschriftLabel.setText("Multiplikation und Division natürlicher Zahlen");
        add(UeberschriftLabel);
        UeberschriftLabel.setBounds(36, 31, 640, 26);

        ErklaerungLabel.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        ErklaerungLabel.setForeground(new java.awt.Color(255, 255, 255));
        ErklaerungLabel.setText("Potenzieren");
        add(ErklaerungLabel);
        ErklaerungLabel.setBounds(36, 63, 310, 21);

        Label.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        Label.setForeground(new java.awt.Color(255, 255, 255));
        Label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        Label.setText("=");
        add(Label);
        Label.setBounds(300, 190, 40, 30);

        EintragOeffnenLabel.setBackground(new java.awt.Color(255, 255, 255));
        EintragOeffnenLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        EintragOeffnenLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EintragOeffnenLabelMouseClicked(evt);
            }
        });
        add(EintragOeffnenLabel);
        EintragOeffnenLabel.setBounds(430, 120, 250, 250);

        NeuButton.setText("<html>Nächste<br>Aufgabe</html>");
        NeuButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NeuButtonActionPerformed(evt);
            }
        });
        add(NeuButton);
        NeuButton.setBounds(330, 350, 70, 40);

        DruckButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/DruckIcon.png"))); // NOI18N
        DruckButton.setToolTipText("Drucken");
        DruckButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        DruckButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DruckButtonMouseClicked(evt);
            }
        });
        add(DruckButton);
        DruckButton.setBounds(560, 420, 30, 30);

        ZurueckButton.setText("Zurück");
        ZurueckButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ZurueckButtonActionPerformed(evt);
            }
        });
        add(ZurueckButton);
        ZurueckButton.setBounds(30, 450, 80, 23);

        ExponentField.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        ExponentField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                ExponentFieldKeyPressed(evt);
            }
        });
        add(ExponentField);
        ExponentField.setBounds(300, 160, 30, 28);

        BasisField.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        BasisField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                BasisFieldKeyPressed(evt);
            }
        });
        add(BasisField);
        BasisField.setBounds(270, 190, 30, 28);

        LoesungField.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        LoesungField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                LoesungFieldKeyPressed(evt);
            }
        });
        add(LoesungField);
        LoesungField.setBounds(350, 190, 70, 28);

        AufgabenLabel.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        AufgabenLabel.setForeground(new java.awt.Color(255, 255, 255));
        AufgabenLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        AufgabenLabel.setText("jLabel1");
        add(AufgabenLabel);
        AufgabenLabel.setBounds(80, 190, 180, 30);

        Hintergrund.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Hintergrund.jpg"))); // NOI18N
        add(Hintergrund);
        Hintergrund.setBounds(0, 0, 700, 500);
    }// </editor-fold>//GEN-END:initComponents

    private void ExponentFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ExponentFieldKeyPressed
        
    }//GEN-LAST:event_ExponentFieldKeyPressed

    private void EintragOeffnenLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EintragOeffnenLabelMouseClicked
        if(!Pruefung){
            Eintrag e = new Eintrag();
            e.EintragAusgeben(19);
            e.setVisible(true);
        }
    }//GEN-LAST:event_EintragOeffnenLabelMouseClicked

    private void NeuButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NeuButtonActionPerformed
        if(Eingabe){
            if(!Pruefung) Reset();
            else ;
        } else {
            Assistent.setText("Du hast die Aufgabe noch nicht bearbeitet.<br>Bearbeite zuerst die Aufgabe, bevor du eine neue bekommst!");
        }
    }//GEN-LAST:event_NeuButtonActionPerformed

    private void DruckButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DruckButtonMouseClicked
        drucken();
    }//GEN-LAST:event_DruckButtonMouseClicked

    private void ZurueckButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ZurueckButtonActionPerformed
        Reset();
        if(!Pruefung)((Frame)(SwingUtilities.getRoot(this))).PerformBackAction(26);
    }//GEN-LAST:event_ZurueckButtonActionPerformed

    private void LoesungFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_LoesungFieldKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_ENTER)Loesung();
    }//GEN-LAST:event_LoesungFieldKeyPressed

    private void BasisFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_BasisFieldKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_BasisFieldKeyPressed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AufgabenLabel;
    private javax.swing.JTextField BasisField;
    private javax.swing.JLabel DruckButton;
    private javax.swing.JLabel EintragOeffnenLabel;
    private javax.swing.JLabel ErklaerungLabel;
    private javax.swing.JTextField ExponentField;
    private javax.swing.JLabel Hintergrund;
    private javax.swing.JLabel Label;
    private javax.swing.JTextField LoesungField;
    private javax.swing.JButton NeuButton;
    private javax.swing.JLabel UeberschriftLabel;
    private javax.swing.JButton ZurueckButton;
    // End of variables declaration//GEN-END:variables
}

 

import java.awt.Color;
import java.awt.event.KeyEvent;
import javax.swing.SwingUtilities;

/**
 *
 * @author Manuel Mayr
 */
public class A_RoemischeZahlen extends javax.swing.JPanel {

    private Assistent Assistent = new Assistent();
    public boolean Pruefung;
    public boolean Eingabe;
    public String Fehler;

    private boolean istroem;
    private int arabZahl;
    private String roemZahl;

    public A_RoemischeZahlen() {
        Assistent.setBounds(430, 120, 250, 250);
        add(Assistent);
        initComponents();
        Reset();
    }

    public void Reset() {
        //istroem: true=gefragte Zahl ist roemisch
        if (Math.random() < 0.5) istroem = true;
        else istroem=false;
        arabZahl = (int) (Math.random() * 4000);
        roemischeZahlBestimmen();
        if (istroem) {
            Assistent.setText("Wandle in eine arabische Zahl um.<br>Viel Erfolg!");
            AufgabenLabel.setText(roemZahl);
        } else {
            Assistent.setText("Wandle in eine römische Zahl um.<br>Viel Erfolg!");
            AufgabenLabel.setText(arabZahl+"");
        }
        Assistent.setColor(Color.BLACK);
        DruckButton.setVisible(false);
        DruckButton.setEnabled(false);
        Eingabe = false;
        Fehler = "";
        LoesungField.setText("");
        LoesungField.requestFocus();
    }

    public void drucken() {
        String a="Natürliche Zahlen - Römische Zahlen";
        String b=AufgabenLabel.getText();
        String c=LoesungField.getText()+" falsch. Richtig: ";
        if(istroem)c+=roemZahl;
        else c+=arabZahl;
        Drucker d = new Drucker(a,b,c);
    }

    public void Loesung() {
        try {            
            if (!Eingabe) {
                if(istroem) Integer.parseInt(LoesungField.getText());
                Eingabe = true;
                if (!Pruefung) {
                    if(istroem) {
                        int Loesung = Integer.parseInt(LoesungField.getText());
                        if(Loesung==arabZahl) {
                            Assistent.setColor(Color.GREEN);
                            Assistent.setText("Du hast die richtige Zahl eingegeben!<br>Gut gemacht!");
                        } else {
                            Assistent.setColor(Color.RED);
                            Assistent.setText("Du hast die falsche Zahl eingegeben, gesucht war "+arabZahl+".<br>Versuch es nochmal!");
                            DruckButton.setVisible(true);
                            DruckButton.setEnabled(true);
                        }
                    } else {
                        String Loesung = LoesungField.getText();
                        if(Loesung.equals(roemZahl)) {
                            Assistent.setColor(Color.GREEN);
                            Assistent.setText("Du hast die richtige Zahl eingegeben!<br>Gut gemacht!");
                        } else {
                            Assistent.setColor(Color.RED);
                            Assistent.setText("Du hast die falsche Zahl eingegeben, gesucht war "+roemZahl+".<br>Versuch es nochmal!");
                            DruckButton.setVisible(true);
                            DruckButton.setEnabled(true);
                        }
                    }
                } else {
                    //Pruefung Code
                }
            } else {
                Assistent.setText("Du hast diese Aufgabe schon bearbeitet.<br>Klicke auf Neue Aufgabe!");
            }
        } catch(Exception e) {
            Assistent.setText("Du hast keine Zahl eingegeben, bitte gib eine Zahl ein und versuche es nochmal.");
        }
    }

    public void roemischeZahlBestimmen() {
        roemZahl = "";
        int z = arabZahl;
        while (z >= 1000) {
            roemZahl += "M";
            z -= 1000;
        }
        if (z >= 500) {
            roemZahl += "D";
            z -= 500;
        }
        if (z >= 400) {
            roemZahl += "CD";
            z -= 400;
        } else {
            while (z >= 100) {
                roemZahl += "C";
                z -= 100;
            }
        }
        if (z >= 50) {
            roemZahl += "L";
            z -= 50;
        }
        if (z >= 40) {
            roemZahl += "XL";
            z -= 40;
        } else {
            while (z >= 10) {
                roemZahl += "X";
                z -= 10;
            }
        }
        if (z >= 5) {
            roemZahl += "V";
            z -= 5;
        }
        if (z == 4) {
            roemZahl += "IV";
            z -= 4;
        } else {
            while (z > 0) {
                roemZahl += "I";
                z -= 1;
            }
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        DruckButton = new javax.swing.JLabel();
        NeuButton = new javax.swing.JButton();
        ZurueckButton = new javax.swing.JButton();
        UeberschriftLabel = new javax.swing.JLabel();
        ErklaerungLabel = new javax.swing.JLabel();
        EintragOeffnenLabel = new javax.swing.JLabel();
        AufgabenLabel = new javax.swing.JLabel();
        LoesungField = new javax.swing.JTextField();
        Pfeil = new javax.swing.JLabel();
        Hintergrund = new javax.swing.JLabel();

        setLayout(null);

        DruckButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/DruckIcon.png"))); // NOI18N
        DruckButton.setToolTipText("Drucken");
        DruckButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        DruckButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DruckButtonMouseClicked(evt);
            }
        });
        add(DruckButton);
        DruckButton.setBounds(560, 420, 30, 30);

        NeuButton.setText("<html>Nächste<br>Aufgabe</html>");
        NeuButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NeuButtonActionPerformed(evt);
            }
        });
        add(NeuButton);
        NeuButton.setBounds(330, 350, 70, 40);

        ZurueckButton.setText("Zurück");
        ZurueckButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ZurueckButtonActionPerformed(evt);
            }
        });
        add(ZurueckButton);
        ZurueckButton.setBounds(30, 450, 80, 23);

        UeberschriftLabel.setFont(new java.awt.Font("Georgia", 1, 26)); // NOI18N
        UeberschriftLabel.setForeground(new java.awt.Color(255, 255, 255));
        UeberschriftLabel.setText("Natürliche Zahlen");
        add(UeberschriftLabel);
        UeberschriftLabel.setBounds(36, 31, 244, 26);

        ErklaerungLabel.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        ErklaerungLabel.setForeground(new java.awt.Color(255, 255, 255));
        ErklaerungLabel.setText("Römische Zahlen");
        add(ErklaerungLabel);
        ErklaerungLabel.setBounds(36, 63, 140, 21);

        EintragOeffnenLabel.setBackground(new java.awt.Color(255, 255, 255));
        EintragOeffnenLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        EintragOeffnenLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EintragOeffnenLabelMouseClicked(evt);
            }
        });
        add(EintragOeffnenLabel);
        EintragOeffnenLabel.setBounds(430, 120, 250, 250);

        AufgabenLabel.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        AufgabenLabel.setForeground(new java.awt.Color(255, 255, 255));
        AufgabenLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        AufgabenLabel.setText("MMMDCCCLXXXVIII");
        add(AufgabenLabel);
        AufgabenLabel.setBounds(80, 180, 163, 22);

        LoesungField.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        LoesungField.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        LoesungField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                LoesungFieldKeyPressed(evt);
            }
        });
        add(LoesungField);
        LoesungField.setBounds(80, 230, 160, 28);

        Pfeil.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Pfeil.png"))); // NOI18N
        add(Pfeil);
        Pfeil.setBounds(110, 204, 90, 20);

        Hintergrund.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Hintergrund.jpg"))); // NOI18N
        add(Hintergrund);
        Hintergrund.setBounds(0, 0, 700, 500);
    }// </editor-fold>//GEN-END:initComponents

    private void DruckButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DruckButtonMouseClicked
        drucken();
    }//GEN-LAST:event_DruckButtonMouseClicked

    private void NeuButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NeuButtonActionPerformed
        if (Eingabe) {
            if (!Pruefung) {
                Reset();
            } else ;
        } else {
            Assistent.setText("Du hast die Aufgabe noch nicht bearbeitet.<br>Bearbeite zuerst die Aufgabe, bevor du eine neue bekommst!");
        }
    }//GEN-LAST:event_NeuButtonActionPerformed

    private void ZurueckButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ZurueckButtonActionPerformed
        Reset();
        if (!Pruefung) {
            ((Frame) (SwingUtilities.getRoot(this))).PerformBackAction(4);
        }
    }//GEN-LAST:event_ZurueckButtonActionPerformed

    private void EintragOeffnenLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EintragOeffnenLabelMouseClicked
        if(!Pruefung){
            Eintrag e = new Eintrag();
            e.EintragAusgeben(4);
            e.setVisible(true);
        }
    }//GEN-LAST:event_EintragOeffnenLabelMouseClicked

    private void LoesungFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_LoesungFieldKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER) Loesung();
    }//GEN-LAST:event_LoesungFieldKeyPressed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AufgabenLabel;
    private javax.swing.JLabel DruckButton;
    private javax.swing.JLabel EintragOeffnenLabel;
    private javax.swing.JLabel ErklaerungLabel;
    private javax.swing.JLabel Hintergrund;
    private javax.swing.JTextField LoesungField;
    private javax.swing.JButton NeuButton;
    private javax.swing.JLabel Pfeil;
    private javax.swing.JLabel UeberschriftLabel;
    private javax.swing.JButton ZurueckButton;
    // End of variables declaration//GEN-END:variables
}


public class Schafkopf{
    private int zustand;

    public Schafkopf(){
        zustand = 0; //Anfangszustand z0
    }

    public boolean karteUntersuchen(String farbe, String wert){
        boolean trumpf = false;
        if (farbe.equals("Herz")) {trumpf = true;}
        else {
            if (wert.equals("Unter") || wert.equals("Ober")) {
                trumpf = true;
            }
        }
        return trumpf;
    }
   
}

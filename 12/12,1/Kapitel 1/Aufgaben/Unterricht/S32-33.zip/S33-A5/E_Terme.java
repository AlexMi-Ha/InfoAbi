 

import java.awt.Color;
import java.awt.event.KeyEvent;
import javax.swing.SwingUtilities;

/**
 *
 * @author Manuel Mayr
 */
public class E_Terme extends javax.swing.JPanel {

    private Assistent Assistent=new Assistent();
    public boolean Pruefung;
    public boolean Eingabe;
    public String Fehler;
    
    //1:(Eins*Zwei+Drei*Vier)*Fuenf+Sechs=Ergebnis
    //2:Eins*Zwei+Drei*(Vier*Fuenf+Sechs)=Ergebnis
    private int state;
    private int Eins;
    private int Zwei;
    private int Drei;
    private int Vier;
    private int Fuenf;
    private int Sechs;
    private int Ergebnis;
    private boolean mal1;
    private boolean mal2;
    private boolean plus1;
    private boolean plus2;
    
    public E_Terme() {
        Assistent.setBounds(430, 120, 250, 250);
        add(Assistent);
        initComponents();
        Reset();
    }

    public void Reset() {
        Assistent.setText("Berechne den Termwert und bestätige mit Enter.<br>Viel Erfolg!");
        Assistent.setColor(Color.BLACK);
        DruckButton.setVisible(false);
        DruckButton.setEnabled(false);
        Eingabe=false;
        Fehler="";
        String text="(";
        int teil1=0;
        int teil2=0;
        int teil12=0;
        if(Math.random()<0.5) {
            mal1=true;
            Eins=(int)(Math.random()*10);
            Zwei=(int)(Math.random()*10);
            text+=Eins+" * "+Zwei;
            teil1=Eins*Zwei;
        } else {
            mal1=false;
            Zwei=(int)(Math.random()*10);
            Eins=Zwei*(int)(Math.random()*4)+1;
            text+=Eins+" : "+Zwei;
            teil1=Eins/Zwei;
        }
        if(Math.random()<0.5) {
            plus1=true;
            text+=" + ";
        } else {
            plus1=false;
            text+=" - ";
        }
        if(Math.random()<0.5) {
            mal2=true;
            Drei=(int)(Math.random()*10);
            Vier=(int)(Math.random()*10);
            text+=Drei+" * "+Vier;
            teil2=Drei*Vier;
        } else {
            mal2=false;
            Vier=(int)(Math.random()*10);
            Drei=Vier*(int)(Math.random()*4)+1;
            text+=Drei+" : "+Vier;
            teil2=Drei/Vier;
        }
        if(plus1) teil12=teil1+teil2;
        else teil12=teil1-teil2;
        Fuenf=(int)(Math.random()*5)+1;
        text+=") * "+Fuenf;
        teil12=teil12*Fuenf;
        Sechs=(int)(Math.random()*25);
        if(Math.random()<0.5) {
            plus2=true;
            text+=" + "+Sechs+" =";
            Ergebnis=teil12+Sechs;
        } else {
            plus2=false;
            text+=" - "+Sechs+" =";
            Ergebnis=teil12-Sechs;
        }
        AufgabenLabel.setText(text);
        LoesungField.setText("");
        LoesungField.requestFocus();
    }
    
    public void drucken() {
        
    }
    
    public void Loesung() {
        try {
            int i=Integer.parseInt(LoesungField.getText());
            if(!Eingabe){
            Eingabe=true;
                if(!Pruefung) {
                    if(i==Ergebnis) {
                        Assistent.setColor(Color.GREEN);
                        Assistent.setText("Das ist richtig!<br>Gut gemacht!");
                    } else {
                        Assistent.setColor(Color.RED);
                        Assistent.setText("Das ist falsch.<br>Das richtige Ergebnis ist "+Ergebnis+".<br>Versuche es nochmal!");
                    }
                } else {
                    //Pruefung Code
                }
            } else {
            Assistent.setText("Du hast diese Aufgabe schon bearbeitet.<br>Klicke auf Neue Aufgabe!");
            }
        } catch(Exception e) {
            Assistent.setText("Du hast keine Zahl eingegeben, bitte gib eine Zahl ein und versuche es nochmal.");
        }
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        UeberschriftLabel = new javax.swing.JLabel();
        ErklaerungLabel = new javax.swing.JLabel();
        AufgabenLabel = new javax.swing.JLabel();
        LoesungField = new javax.swing.JTextField();
        EintragOeffnenLabel = new javax.swing.JLabel();
        DruckButton = new javax.swing.JLabel();
        NeuButton = new javax.swing.JButton();
        ZurueckButton = new javax.swing.JButton();
        Hintergrund = new javax.swing.JLabel();

        setLayout(null);

        UeberschriftLabel.setFont(new java.awt.Font("Georgia", 1, 26)); // NOI18N
        UeberschriftLabel.setForeground(new java.awt.Color(255, 255, 255));
        UeberschriftLabel.setText("Multiplikation und Division natürlicher Zahlen");
        add(UeberschriftLabel);
        UeberschriftLabel.setBounds(36, 31, 640, 26);

        ErklaerungLabel.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        ErklaerungLabel.setForeground(new java.awt.Color(255, 255, 255));
        ErklaerungLabel.setText("Terme");
        add(ErklaerungLabel);
        ErklaerungLabel.setBounds(36, 63, 310, 21);

        AufgabenLabel.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        AufgabenLabel.setForeground(new java.awt.Color(255, 255, 255));
        AufgabenLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        AufgabenLabel.setText("jLabel1");
        add(AufgabenLabel);
        AufgabenLabel.setBounds(80, 190, 210, 30);

        LoesungField.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        LoesungField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                LoesungFieldKeyPressed(evt);
            }
        });
        add(LoesungField);
        LoesungField.setBounds(300, 190, 80, 28);

        EintragOeffnenLabel.setBackground(new java.awt.Color(255, 255, 255));
        EintragOeffnenLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        EintragOeffnenLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EintragOeffnenLabelMouseClicked(evt);
            }
        });
        add(EintragOeffnenLabel);
        EintragOeffnenLabel.setBounds(430, 120, 250, 250);

        DruckButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/DruckIcon.png"))); // NOI18N
        DruckButton.setToolTipText("Drucken");
        DruckButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        DruckButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DruckButtonMouseClicked(evt);
            }
        });
        add(DruckButton);
        DruckButton.setBounds(560, 420, 30, 30);

        NeuButton.setText("<html>Nächste<br>Aufgabe</html>");
        NeuButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NeuButtonActionPerformed(evt);
            }
        });
        add(NeuButton);
        NeuButton.setBounds(330, 350, 70, 40);

        ZurueckButton.setText("Zurück");
        ZurueckButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ZurueckButtonActionPerformed(evt);
            }
        });
        add(ZurueckButton);
        ZurueckButton.setBounds(30, 450, 80, 23);

        Hintergrund.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Hintergrund.jpg"))); // NOI18N
        add(Hintergrund);
        Hintergrund.setBounds(0, 0, 700, 500);
    }// </editor-fold>//GEN-END:initComponents

    private void LoesungFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_LoesungFieldKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_ENTER)Loesung();
    }//GEN-LAST:event_LoesungFieldKeyPressed

    private void EintragOeffnenLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EintragOeffnenLabelMouseClicked
        if(!Pruefung){
            Eintrag e = new Eintrag();
            e.EintragAusgeben(20);
            e.setVisible(true);
        }
    }//GEN-LAST:event_EintragOeffnenLabelMouseClicked

    private void DruckButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DruckButtonMouseClicked
        drucken();
    }//GEN-LAST:event_DruckButtonMouseClicked

    private void NeuButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NeuButtonActionPerformed
        if(Eingabe){
            if(!Pruefung) Reset();
            else ;
        } else {
            Assistent.setText("Du hast die Aufgabe noch nicht bearbeitet.<br>Bearbeite zuerst die Aufgabe, bevor du eine neue bekommst!");
        }
    }//GEN-LAST:event_NeuButtonActionPerformed

    private void ZurueckButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ZurueckButtonActionPerformed
        Reset();
        if(!Pruefung)((Frame)(SwingUtilities.getRoot(this))).PerformBackAction(27);
    }//GEN-LAST:event_ZurueckButtonActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AufgabenLabel;
    private javax.swing.JLabel DruckButton;
    private javax.swing.JLabel EintragOeffnenLabel;
    private javax.swing.JLabel ErklaerungLabel;
    private javax.swing.JLabel Hintergrund;
    private javax.swing.JTextField LoesungField;
    private javax.swing.JButton NeuButton;
    private javax.swing.JLabel UeberschriftLabel;
    private javax.swing.JButton ZurueckButton;
    // End of variables declaration//GEN-END:variables
}

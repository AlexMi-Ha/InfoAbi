 

import java.awt.Color;
import java.awt.event.KeyEvent;
import javax.swing.SwingUtilities;

/**
 *
 * @author Manuel Mayr
 */
public class A_Zahlenfolge extends javax.swing.JPanel {

    private Assistent Assistent=new Assistent();
    public boolean Pruefung;
    public boolean Eingabe;
    public String Fehler;
    
    private int[] Zahlen=new int[6];
    private int Vorgabe1;
    private int Vorgabe2;
    
    public A_Zahlenfolge() {
        Assistent.setBounds(430, 120, 250, 250);
        add(Assistent);
        initComponents();
        Reset();
    }

    public void Reset() {
        Assistent.setText("Führe die angezeigte Zahlenfolge richtig weiter, bestätige mit Enter.<br>Viel Erfolg!");
        Assistent.setColor(Color.BLACK);
        DruckButton.setVisible(false);
        DruckButton.setEnabled(false);
        Eingabe=false;
        Fehler="";
        
        Zahlen[0]=(int)(Math.random()*40);
        Vorgabe1 = (int)(Math.random()*10);
        if(Math.random()<0.5)Vorgabe1*=-1;
        Vorgabe2 = (int)(Math.random()*10);
        if(Math.random()<0.5)Vorgabe2*=-1;
        for(int i=1;i<6;i++) {
            if(i%2==0)Zahlen[i]=Zahlen[i-1]+Vorgabe1;
            else Zahlen[i]=Zahlen[i-1]+Vorgabe2;
        }
        for(int i=0;i<6;i++)if(Zahlen[i]<0) Reset();
        Loesung1.setText("");
        Loesung2.setText("");
        Loesung3.setText("");
        Loesung1.requestFocus();
        Aufgabe1.setText(Zahlen[0]+"");
        Aufgabe2.setText(Zahlen[1]+"");
        Aufgabe3.setText(Zahlen[2]+"");
    }
    
    public void drucken() {
        String a="Natürliche Zahlen - Zahlenmengen";
        String b=Zahlen[0]+"   "+Zahlen[1]+"   "+Zahlen[2]+" __   __   __";
        String c=Loesung1.getText()+"   "+Loesung2.getText()+"   "+Loesung3.getText()+" falsch. Richtig: ";
        for(int i=3; i<5;i++)c+=Zahlen[i]+"   ";
        Drucker d = new Drucker(a,b,c);
    }
    
    public void Loesung() {
        try{
        int eins = Integer.parseInt(Loesung1.getText());
        int zwei = Integer.parseInt(Loesung2.getText());
        int drei = Integer.parseInt(Loesung3.getText());
            if(!Eingabe){
                Eingabe=true;
                if(!Pruefung) {
                    if(eins==Zahlen[3]&&zwei==Zahlen[4]&&drei==Zahlen[5]) {
                        Assistent.setColor(Color.GREEN);
                        Assistent.setText("Du hast die Zahlenfolge richtig fortgeführt!<br>Gut gemacht!");
                    } else {
                        Assistent.setColor(Color.RED);
                        String text="Du hast die Zahlenfolge bei Position ";
                        if(eins!=Zahlen[3])text+="1 ";
                        if(zwei!=Zahlen[3])text+="2 ";
                        if(drei!=Zahlen[3])text+="3 ";
                        text+="falsch fortgeführt.<br>Versuche es nochmal!";
                        Assistent.setText(text);
                        DruckButton.setVisible(true);
                        DruckButton.setEnabled(true);
                    }
                } else {
                    //Pruefung Code
                }
            } else {
                Assistent.setText("Du hast diese Aufgabe schon bearbeitet.<br>Klicke auf Neue Aufgabe!");
            }
        } catch(Exception e) {
            Assistent.setText("Du hast keine Zahl eingegeben, bitte gib eine Zahl ein und versuche es nochmal.");
        }
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        UeberschriftLabel = new javax.swing.JLabel();
        ErklaerungLabel = new javax.swing.JLabel();
        ZurueckButton = new javax.swing.JButton();
        NeuButton = new javax.swing.JButton();
        DruckButton = new javax.swing.JLabel();
        EintragOeffnenLabel = new javax.swing.JLabel();
        Aufgabe1 = new javax.swing.JLabel();
        Aufgabe2 = new javax.swing.JLabel();
        Aufgabe3 = new javax.swing.JLabel();
        Loesung1 = new javax.swing.JTextField();
        Loesung2 = new javax.swing.JTextField();
        Loesung3 = new javax.swing.JTextField();
        Hintergrund = new javax.swing.JLabel();

        setLayout(null);

        UeberschriftLabel.setFont(new java.awt.Font("Georgia", 1, 26)); // NOI18N
        UeberschriftLabel.setForeground(new java.awt.Color(255, 255, 255));
        UeberschriftLabel.setText("Natürliche Zahlen");
        add(UeberschriftLabel);
        UeberschriftLabel.setBounds(36, 31, 244, 26);

        ErklaerungLabel.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        ErklaerungLabel.setForeground(new java.awt.Color(255, 255, 255));
        ErklaerungLabel.setText("Zahlenmengen");
        add(ErklaerungLabel);
        ErklaerungLabel.setBounds(36, 63, 121, 21);

        ZurueckButton.setText("Zurück");
        ZurueckButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ZurueckButtonActionPerformed(evt);
            }
        });
        add(ZurueckButton);
        ZurueckButton.setBounds(30, 450, 80, 23);

        NeuButton.setText("<html>Nächste<br>Aufgabe</html>");
        NeuButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NeuButtonActionPerformed(evt);
            }
        });
        add(NeuButton);
        NeuButton.setBounds(330, 350, 70, 40);

        DruckButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/DruckIcon.png"))); // NOI18N
        DruckButton.setToolTipText("Drucken");
        DruckButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        DruckButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DruckButtonMouseClicked(evt);
            }
        });
        add(DruckButton);
        DruckButton.setBounds(560, 420, 30, 30);

        EintragOeffnenLabel.setBackground(new java.awt.Color(255, 255, 255));
        EintragOeffnenLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        EintragOeffnenLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EintragOeffnenLabelMouseClicked(evt);
            }
        });
        add(EintragOeffnenLabel);
        EintragOeffnenLabel.setBounds(430, 120, 250, 250);

        Aufgabe1.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        Aufgabe1.setForeground(new java.awt.Color(255, 255, 255));
        Aufgabe1.setText("20");
        add(Aufgabe1);
        Aufgabe1.setBounds(40, 160, 20, 22);

        Aufgabe2.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        Aufgabe2.setForeground(new java.awt.Color(255, 255, 255));
        Aufgabe2.setText("20");
        add(Aufgabe2);
        Aufgabe2.setBounds(70, 160, 20, 22);

        Aufgabe3.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        Aufgabe3.setForeground(new java.awt.Color(255, 255, 255));
        Aufgabe3.setText("20");
        add(Aufgabe3);
        Aufgabe3.setBounds(100, 160, 20, 22);

        Loesung1.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        add(Loesung1);
        Loesung1.setBounds(140, 160, 40, 28);

        Loesung2.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        add(Loesung2);
        Loesung2.setBounds(190, 160, 40, 28);

        Loesung3.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        Loesung3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                Loesung3KeyPressed(evt);
            }
        });
        add(Loesung3);
        Loesung3.setBounds(240, 160, 40, 28);

        Hintergrund.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Hintergrund.jpg"))); // NOI18N
        add(Hintergrund);
        Hintergrund.setBounds(0, 0, 700, 500);
    }// </editor-fold>//GEN-END:initComponents

    private void ZurueckButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ZurueckButtonActionPerformed
        Reset();
        if(!Pruefung)((Frame)(SwingUtilities.getRoot(this))).PerformBackAction(-5);
    }//GEN-LAST:event_ZurueckButtonActionPerformed

    private void NeuButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NeuButtonActionPerformed
        if(Eingabe){
            if(!Pruefung) Reset();
            else ;
        } else {
            Assistent.setText("Du hast die Aufgabe noch nicht bearbeitet.<br>Bearbeite zuerst die Aufgabe, bevor du eine neue bekommst!");
        }
    }//GEN-LAST:event_NeuButtonActionPerformed

    private void DruckButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DruckButtonMouseClicked
        drucken();
    }//GEN-LAST:event_DruckButtonMouseClicked

    private void EintragOeffnenLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EintragOeffnenLabelMouseClicked
        if(!Pruefung){
            Eintrag e = new Eintrag();
            e.EintragAusgeben(5);
            e.setVisible(true);
        }
    }//GEN-LAST:event_EintragOeffnenLabelMouseClicked

    private void Loesung3KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Loesung3KeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_ENTER) Loesung();
    }//GEN-LAST:event_Loesung3KeyPressed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Aufgabe1;
    private javax.swing.JLabel Aufgabe2;
    private javax.swing.JLabel Aufgabe3;
    private javax.swing.JLabel DruckButton;
    private javax.swing.JLabel EintragOeffnenLabel;
    private javax.swing.JLabel ErklaerungLabel;
    private javax.swing.JLabel Hintergrund;
    private javax.swing.JTextField Loesung1;
    private javax.swing.JTextField Loesung2;
    private javax.swing.JTextField Loesung3;
    private javax.swing.JButton NeuButton;
    private javax.swing.JLabel UeberschriftLabel;
    private javax.swing.JButton ZurueckButton;
    // End of variables declaration//GEN-END:variables
}

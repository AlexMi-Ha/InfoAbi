 

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
/**
 * erzeugt den JFrame, verwaltet alle Obejkte der Aufgabenklassen
 * @author Manuel Mayr
 */
public class Frame extends JFrame {
    /**
     * Breite des Fensters
     */
    public static final int width = 700;
    /**
     * Hoehe des Fensters
     */
    public static final int height = 500;
    private Pruefungsauswahl Pruefungsauswahl = new Pruefungsauswahl();
    private HauptmenuPanel Hauptmenu = new HauptmenuPanel();
    //Natürliche Zahlen
    private A_ZaehlenOrdnen A_ZaehlenOrdnen = new A_ZaehlenOrdnen();
    private A_VeranschaulichungZS A_VeranschaulichungZS = new A_VeranschaulichungZS();
    private A_VeranschaulichungKoSy A_VeranschaulichungKoSy = new A_VeranschaulichungKoSy();
    private A_Potenzen A_Potenzen = new A_Potenzen();
    private A_RoemischeZahlen A_RoemischeZahlen = new A_RoemischeZahlen();
    private A_Primzahlbestimmung A_Primzahlbestimmung = new A_Primzahlbestimmung();
    private A_Zahlenfolge A_Zahlenfolge = new A_Zahlenfolge();
    private A_Runden A_Runden = new A_Runden();
    //Addition und Subtraktion natürlicher Zahlen
    private B_AddierenSubtrahierenKR B_AddierenSubtrahierenKR = new B_AddierenSubtrahierenKR();
    private B_AddierenSubtrahierenSR B_AddierenSubtrahierenSR = new B_AddierenSubtrahierenSR();
    private B_RechengesetzeAG B_RechengesetzeAG = new B_RechengesetzeAG();
    private B_Terme B_Terme = new B_Terme();
    //Addition und Subtraktion ganzer Zahlen
    private C_Vorzeichenschreibweise C_Vorzeichenschreibweise = new C_Vorzeichenschreibweise();
    private C_AnordnungBetragOrdnen C_AnordnungBetragOrdnen = new C_AnordnungBetragOrdnen();
    private C_AnordnungBetragBetrag C_AnordnungBetragBetrag = new C_AnordnungBetragBetrag();
    private C_AddierenSubtrahieren C_AddierenSubtrahieren = new C_AddierenSubtrahieren();
    private C_RechnenSumDif C_RechnenSumDif = new C_RechnenSumDif();
    //Geometrische Grundbegriffe
    private D_GeometrischeKörper D_GeometrischeKörper = new D_GeometrischeKörper();
    private D_Parallelogramme D_Parallelogramme = new D_Parallelogramme();
    private D_Winkel D_Winkel = new D_Winkel();
    //Multiplikation und Division natürlicher Zahlen
    private E_MultDiv E_MultDiv = new E_MultDiv();
    private E_RechnenNullEins E_RechnenNullEins = new E_RechnenNullEins();
    private E_VerbindungGrundrechenarten E_VerbindungGrundrechenarten = new E_VerbindungGrundrechenarten();
    private E_Rechengesetz E_Rechengesetz = new E_Rechengesetz();
    private E_Potenzieren E_Potenzieren = new E_Potenzieren();
    private E_Terme E_Terme = new E_Terme();
    //Multiplikation und Division ganzer Zahlen
    private F_Multiplikation F_Multiplikation = new F_Multiplikation();
    private F_Division F_Division = new F_Division();
    private F_Rechengesetz F_Rechengesetz = new F_Rechengesetz();
    //Flaeche und Flaechenmessung
    private H_FlaecheninhaltRechteck H_FlaecheninhaltRechteck = new H_FlaecheninhaltRechteck();
    private H_OberflaecheQuader H_OberflaecheQuader = new H_OberflaecheQuader();
    /**
     * Konstruktor
     */
    public Frame() {
        setTitle("Mathe-Hilfe 5 (Testversion)");
        this.setIconImage(new ImageIcon(getClass().getResource("/img/Icon.png")).getImage());
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        add(Hauptmenu);
        //add(Pruefungsauswahl);
        pack();
        setSize(width + getInsets().left + getInsets().right, height + getInsets().top + getInsets().bottom);
        setLocationRelativeTo(null);
    }
    /**
     * Umschalten vom Hauptmenü auf die einzelnen Elemente der Aufgabenklassen
     * @param a Index des Objektes im Hauptmenü
     * @param pru boolean Pruefung der Aufgabenklassen
     */
    public void PerformAction(int a, boolean pru) {
        System.out.println(a);
         System.out.println("anfang perform action");
        if(pru==false)remove(Hauptmenu);
        //alle Kapitelüberschirften
        System.out.println("PerformAction start");
        if(a==0||a==7||a==11||a==16||a==20||a==27||a==31) add(Hauptmenu);
        //alle anderen Listenelemente
        else if(a==1) {
            A_ZaehlenOrdnen.Pruefung=pru;
            add(A_ZaehlenOrdnen);
        } else if(a==2) {
            if(Math.random()<0.5) {
                add(A_VeranschaulichungZS);
                A_VeranschaulichungZS.Pruefung=pru;
            } else {
                add(A_VeranschaulichungKoSy);
                A_VeranschaulichungKoSy.Pruefung=pru;
            }    
        } else if(a==3) {
            add(A_Potenzen);
            A_Potenzen.Pruefung=pru;
        } else if(a==4) {
            add(A_RoemischeZahlen);
            A_RoemischeZahlen.Pruefung=pru;
        } else if(a==5) {
            if(Math.random()<0.5) {
                add(A_Primzahlbestimmung);
                A_Primzahlbestimmung.Pruefung=pru;
            } else {
                add(A_Zahlenfolge);
                A_Zahlenfolge.Pruefung=pru;
            }
        } else if(a==6) {
            add(A_Runden);
            A_Runden.Pruefung=pru;
        } else if(a==8) {
            if(Math.random()<0.5) {
                add(B_AddierenSubtrahierenKR);
                B_AddierenSubtrahierenKR.Pruefung=pru;
            } else {
                add(B_AddierenSubtrahierenSR);
                B_AddierenSubtrahierenSR.Pruefung=pru;
            }
        } else if(a==9) {
            add(B_RechengesetzeAG);
            B_RechengesetzeAG.Pruefung=pru;
        } else if(a==10) {
            add(B_Terme);
            B_Terme.Pruefung=pru;
        } else if(a==12) {
            add(C_Vorzeichenschreibweise);
            C_Vorzeichenschreibweise.Pruefung=pru;
        } else if(a==13) {
            if(Math.random()<0.5) {
                add(C_AnordnungBetragOrdnen);
                C_AnordnungBetragOrdnen.Pruefung=pru;
            } else {
                add(C_AnordnungBetragBetrag);
                C_AnordnungBetragBetrag.Pruefung=pru;
            }
        } else if(a==14) {
            add(C_AddierenSubtrahieren);
            C_AddierenSubtrahieren.Pruefung=pru;
        } else if(a==15) {
            add(C_RechnenSumDif);
            C_RechnenSumDif.Pruefung=pru;
        } else if(a==17) {
            add(D_GeometrischeKörper);
            D_GeometrischeKörper.Pruefung=pru;
        } else if(a==18) {
            add(D_Parallelogramme);
            D_Parallelogramme.Pruefung=pru;
        } else if(a==19) {
            add(D_Winkel);
            D_Winkel.Pruefung=pru;
        } else if(a==21) {
            add(E_MultDiv);
            E_MultDiv.Pruefung=pru;
        } else if(a==22) {
            add(E_RechnenNullEins);
            E_RechnenNullEins.Pruefung=pru;
        } else if(a==23) {
            add(E_VerbindungGrundrechenarten);
            E_VerbindungGrundrechenarten.Pruefung=pru;
        } else if(a==24) {
            add(E_Rechengesetz);
            E_Rechengesetz.Pruefung=pru;
        } else if(a==25) {
            add(E_Potenzieren);
            E_Potenzieren.Pruefung=pru;
        } else if(a==26) {
            add(E_Terme);
            E_Terme.Pruefung=pru;
        } else if(a==28) {
            add(F_Multiplikation);
            F_Multiplikation.Pruefung=pru;
        } else if(a==29) {
            add(F_Division);
            F_Division.Pruefung=pru;
        } else if(a==30) {
            add(F_Rechengesetz);
            F_Rechengesetz.Pruefung=pru;
        } else if(a==32) {
            add(H_FlaecheninhaltRechteck);
            H_FlaecheninhaltRechteck.Pruefung=pru;
        } else if(a==33) {
            add(H_OberflaecheQuader);
            H_OberflaecheQuader.Pruefung=pru;
        } else if(a==40) {
            add(Pruefungsauswahl);
        }
        pack();
        setSize(width + getInsets().left + getInsets().right, height + getInsets().top + getInsets().bottom);
    }
    /**
     * Umschalten von Objekten der Aufgabenklassen auf das Hauptmenü
     * @param a Index des Objektes der Aufgabenklasse
     */
    public void PerformBackAction(int a) {
        if(a!=40)add(Hauptmenu);
        if(a==1) remove(A_ZaehlenOrdnen);
        else if(a==2) remove(A_VeranschaulichungZS);
        else if(a==-2) remove(A_VeranschaulichungKoSy);
        else if(a==3) remove(A_Potenzen);
        else if(a==4) remove(A_RoemischeZahlen);
        else if(a==5) remove(A_Primzahlbestimmung);
        else if(a==-5) remove(A_Zahlenfolge);
        else if(a==6) remove(A_Runden);
        else if(a==8) remove(B_AddierenSubtrahierenKR);
        else if(a==-8) remove(B_AddierenSubtrahierenSR);
        else if(a==9) remove(B_RechengesetzeAG);
        else if(a==10) remove(B_Terme);
        else if(a==12) remove(C_Vorzeichenschreibweise);
        else if(a==13) remove(C_AnordnungBetragOrdnen);
        else if(a==-13) remove(C_AnordnungBetragBetrag);
        else if(a==14) remove(C_AddierenSubtrahieren);
        else if(a==15) remove(C_RechnenSumDif);
        else if(a==17) remove(D_GeometrischeKörper);
        else if(a==18) remove(D_Parallelogramme);
        else if(a==19) remove(D_Winkel);
        else if(a==21) remove(E_MultDiv);
        else if(a==22) remove(E_RechnenNullEins);
        else if(a==24) remove(E_VerbindungGrundrechenarten);
        else if(a==25) remove(E_Rechengesetz);
        else if(a==26) remove(E_Potenzieren);
        else if(a==27) remove(E_Terme);
        else if(a==28) remove(F_Multiplikation);
        else if(a==29) remove(F_Division);
        else if(a==30) remove(F_Rechengesetz);
        else if(a==32) remove(H_FlaecheninhaltRechteck);
        else if(a==33) remove(H_OberflaecheQuader);
        else if(a==40||a==41) remove(Pruefungsauswahl);
        pack();
        setSize(width + getInsets().left + getInsets().right, height + getInsets().top + getInsets().bottom);
    }
}
 

import javax.swing.SwingUtilities;

/**
 *
 * @author Manuel Mayr
 */
public class Pruefungsauswahl extends javax.swing.JPanel {

    private Assistent Assistent=new Assistent();
    private int AufgabenAuswahl[];
    private int Aufgabentyp[];
    private boolean richtigBeantwortet[];
    private int Aufgabenanzahl;
    private int aktAufgabe;

    public Pruefungsauswahl() {
        Assistent.setBounds(430, 120, 250, 250);
        add(Assistent);
        initComponents();
        Assistent.setText("Willkommen zum Prüfungsmodus. Hier kannst Du eine Prüfung simulieren und die Anzahl der Aufgaben sowie die Themengebiete auswählen.<br>Viel Erfolg!");
    }

    @SuppressWarnings("empty-statement")
    public void initialisierung() {
        try {
            System.out.println("initialisierung begonnen");
            Aufgabenanzahl = Integer.parseInt(AnzahlField.getText());
            System.out.println("Schritt 1...");
            if(Aufgabenanzahl<0&&Aufgabenanzahl>100) return;
            System.out.println("Schritt 2...");
            AufgabenAuswahl=jList1.getSelectedIndices();
            System.out.println("Schritt 3...");
            richtigBeantwortet=new boolean[Aufgabenanzahl];
            System.out.println("Schritt 4...");
            Aufgabentyp=new int[Aufgabenanzahl];
            System.out.println("Schritt 5...");
            aktAufgabe=0;
            System.out.println("Schritt 6...");
            ((Frame)(SwingUtilities.getRoot(this))).PerformBackAction(40);
            System.out.println("Schritt 7...");
            NeueAufgabe();
            System.out.println("initialisierung abgeschlossen");
        } catch (Exception e) {
            Assistent.setText("Du hast keine Zahl zwischen 1 und 100 eingegeben. Gib eine Aufgabenanzahl zwischen 0 und 100 ein.");
        }
    }
    
    public void NeueAufgabe(){
        if(aktAufgabe!=Aufgabenanzahl) {
            aktAufgabe++;
            int i=(int)(Math.random()*AufgabenAuswahl.length);
            i=AufgabenAuswahl[i];
             System.out.println(i+"v");
            ((Frame)(SwingUtilities.getRoot(this))).PerformAction(i, true);
            System.out.println(i+".");
        } else {
            //Aufgaben Auswertung
            System.out.println("Test abgeschlossen");
        }
    }
    
    public void Loesung() {
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        UeberschriftLabel = new javax.swing.JLabel();
        AnzahlLabel = new javax.swing.JLabel();
        StartButton = new javax.swing.JButton();
        AuswahlLabel = new javax.swing.JLabel();
        ErklaerungLabel = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList();
        ZurueckButton = new javax.swing.JButton();
        AnzahlField = new javax.swing.JTextField();
        Hintergrund = new javax.swing.JLabel();

        setLayout(null);

        UeberschriftLabel.setFont(new java.awt.Font("Georgia", 1, 26)); // NOI18N
        UeberschriftLabel.setForeground(new java.awt.Color(255, 255, 255));
        UeberschriftLabel.setText("Prüfungsmodus");
        add(UeberschriftLabel);
        UeberschriftLabel.setBounds(36, 31, 640, 26);

        AnzahlLabel.setFont(new java.awt.Font("Georgia", 0, 15)); // NOI18N
        AnzahlLabel.setForeground(new java.awt.Color(255, 255, 255));
        AnzahlLabel.setText("Anzahl der Aufgaben:");
        add(AnzahlLabel);
        AnzahlLabel.setBounds(320, 400, 180, 18);

        StartButton.setText("Los!");
        StartButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StartButtonActionPerformed(evt);
            }
        });
        add(StartButton);
        StartButton.setBounds(560, 450, 80, 23);

        AuswahlLabel.setFont(new java.awt.Font("Georgia", 0, 15)); // NOI18N
        AuswahlLabel.setForeground(new java.awt.Color(13, 58, 164));
        AuswahlLabel.setText("Auswahl der Aufgaben:");
        add(AuswahlLabel);
        AuswahlLabel.setBounds(30, 110, 250, 18);

        ErklaerungLabel.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        ErklaerungLabel.setForeground(new java.awt.Color(255, 255, 255));
        ErklaerungLabel.setText("Aufgabenauswahl");
        add(ErklaerungLabel);
        ErklaerungLabel.setBounds(36, 63, 250, 21);

        jList1.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Natürliche Zahlen", "   Zählen und Ordnen", "   Veranschaulichen von Zahlen", "   Dezimalsystem", "   Römische Zahlen", "   Zahlenmengen", "   Runden", "Addition und Subtraktion natürlicher Zahlen", "   Addieren und Subtrahieren", "   Rechengesetze und -vorteile", "   Terme", "Addition und Subtraktion ganzer Zahlen", "   Vorzeichenschreibweise", "   Anordnung und Betrag", "   Addieren/ Subtrahieren", "   Rechnen mit Summen und Differenzen", "Geometrische Grundbegriffe", "   Geometrische Körper", "   Parallelogramme - Umfang", "   Winkel", "Multiplikation und Division natürlicher Zahlen", "   Multiplizieren und Dividieren", "   Rechnen mit Null und Eins", "   Verbindung der Grundrechenarten", "   Rechengesetze und Rechenvorteile", "   Potenzieren", "   Terme", "Multiplikation und Division ganzer Zahlen", "   Multiplizieren", "   Dividieren", "   Rechengesetze und Rechenvorteile", "Fläche und Flächenmessung", "   Flächeninhalt des Rechtecks", "   Oberflächeninhalt des Quaders" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jList1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jList1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jList1);

        add(jScrollPane1);
        jScrollPane1.setBounds(30, 140, 280, 300);

        ZurueckButton.setText("Zurück");
        ZurueckButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ZurueckButtonActionPerformed(evt);
            }
        });
        add(ZurueckButton);
        ZurueckButton.setBounds(30, 450, 80, 23);
        add(AnzahlField);
        AnzahlField.setBounds(480, 400, 70, 20);

        Hintergrund.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Hintergrund.jpg"))); // NOI18N
        add(Hintergrund);
        Hintergrund.setBounds(0, 0, 700, 500);
    }// </editor-fold>//GEN-END:initComponents

    private void ZurueckButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ZurueckButtonActionPerformed
        ((Frame)(SwingUtilities.getRoot(this))).PerformBackAction(41);
    }//GEN-LAST:event_ZurueckButtonActionPerformed

    private void jList1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jList1MouseClicked
        int i=jList1.getSelectedIndex();
        System.out.println(i);
        //((Frame)(SwingUtilities.getRoot(this))).PerformAction(i, true);
    }//GEN-LAST:event_jList1MouseClicked

    private void StartButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StartButtonActionPerformed
        System.out.println("Start gedrückt");
        initialisierung();
    }//GEN-LAST:event_StartButtonActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField AnzahlField;
    private javax.swing.JLabel AnzahlLabel;
    private javax.swing.JLabel AuswahlLabel;
    private javax.swing.JLabel ErklaerungLabel;
    private javax.swing.JLabel Hintergrund;
    private javax.swing.JButton StartButton;
    private javax.swing.JLabel UeberschriftLabel;
    private javax.swing.JButton ZurueckButton;
    public javax.swing.JList jList1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}

 

import java.awt.Color;
import java.awt.event.KeyEvent;
import javax.swing.SwingUtilities;

/**
 *
 * @author Manuel Mayr
 */
public class D_Parallelogramme extends javax.swing.JPanel {

    private Assistent Assistent=new Assistent();
    public boolean Pruefung;
    public boolean Eingabe;
    public String Fehler;

    private int laenge;
    private int hoehe;
    private int Ergebnis;
    
    public D_Parallelogramme() {
        Assistent.setBounds(430, 120, 250, 250);
        add(Assistent);
        initComponents();
        Reset();
    }

    public void Reset() {
        Assistent.setText("Berechne den Umfang des gegebenen Parallelogramms, bestätige Deine Eingabe mit Enter.<br>Viel Erfolg!");
        Assistent.setColor(Color.BLACK);
        DruckButton.setVisible(false);
        DruckButton.setEnabled(false);
        Eingabe=false;
        Fehler="";
        LoesungField.setText("");
        LoesungField.requestFocus();
        laenge=(int)(Math.random()*20);
        hoehe=(int)(Math.random()*10);
        Ergebnis=2*(hoehe+laenge);
        LaengeLabel.setText(laenge+"");
        HoeheLabel.setText(hoehe+"");
    }
    
    public void drucken() {
        String a="Addition und Subtraktion ganzer Zahlen - Umfang von Parallelogrammen";
        String b="Maße Parallelogramm: Höhe: "+hoehe+", Länge"+laenge;
        String c=LoesungField.getText()+" falsch. Richtig: "+Ergebnis;
        Drucker d = new Drucker(a,b,c);
    }
    
    public void Loesung() {
        try{
            int i=Integer.parseInt(LoesungField.getText());
            if(!Eingabe){
                Eingabe=true;
                if(!Pruefung) {
                    if(i==Ergebnis) {
                        Assistent.setColor(Color.GREEN);
                        Assistent.setText("Du hast den Umfang richtig berechnet!<br>Gut gemacht!");
                    } else {
                        Assistent.setColor(Color.RED);
                        String text="Das ist falsch. ";
                        if(i==Ergebnis/2)text+="Du hast nur 2 der 4 Seiten berücksichtigt.";
                        text+="<br>Das richtige Ergebnis ist "+Ergebnis+".<br>Versuche es nochmal!";
                        DruckButton.setVisible(true);
                        DruckButton.setEnabled(true);
                        Assistent.setText(text);
                    }
                } else {
                    //Pruefung Code
                }
            } else {
                Assistent.setText("Du hast diese Aufgabe schon bearbeitet.<br>Klicke auf Neue Aufgabe!");
            }
        } catch(Exception e) {
            Assistent.setText("Du hast keine Zahl eingegeben, bitte gib eine Zahl ein und versuche es nochmal."); 
        }
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        UeberschriftLabel = new javax.swing.JLabel();
        ErklaerungLabel = new javax.swing.JLabel();
        LoesungField = new javax.swing.JTextField();
        NeuButton = new javax.swing.JButton();
        ZurueckButton = new javax.swing.JButton();
        DruckButton = new javax.swing.JLabel();
        EintragOeffnenLabel = new javax.swing.JLabel();
        LaengeLabel = new javax.swing.JLabel();
        HoeheLabel = new javax.swing.JLabel();
        Parallelogramm = new javax.swing.JLabel();
        Hintergrund = new javax.swing.JLabel();

        setLayout(null);

        UeberschriftLabel.setFont(new java.awt.Font("Georgia", 1, 26)); // NOI18N
        UeberschriftLabel.setForeground(new java.awt.Color(255, 255, 255));
        UeberschriftLabel.setText("Geometrische Grundbegriffe");
        add(UeberschriftLabel);
        UeberschriftLabel.setBounds(36, 31, 640, 26);

        ErklaerungLabel.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        ErklaerungLabel.setForeground(new java.awt.Color(255, 255, 255));
        ErklaerungLabel.setText("Parallelogramme - Umfang");
        add(ErklaerungLabel);
        ErklaerungLabel.setBounds(36, 63, 250, 21);

        LoesungField.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        LoesungField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                LoesungFieldKeyPressed(evt);
            }
        });
        add(LoesungField);
        LoesungField.setBounds(300, 280, 80, 28);

        NeuButton.setText("<html>Nächste<br>Aufgabe</html>");
        NeuButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NeuButtonActionPerformed(evt);
            }
        });
        add(NeuButton);
        NeuButton.setBounds(330, 350, 70, 40);

        ZurueckButton.setText("Zurück");
        ZurueckButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ZurueckButtonActionPerformed(evt);
            }
        });
        add(ZurueckButton);
        ZurueckButton.setBounds(30, 450, 80, 23);

        DruckButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/DruckIcon.png"))); // NOI18N
        DruckButton.setToolTipText("Drucken");
        DruckButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        DruckButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DruckButtonMouseClicked(evt);
            }
        });
        add(DruckButton);
        DruckButton.setBounds(560, 420, 30, 30);

        EintragOeffnenLabel.setBackground(new java.awt.Color(255, 255, 255));
        EintragOeffnenLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        EintragOeffnenLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EintragOeffnenLabelMouseClicked(evt);
            }
        });
        add(EintragOeffnenLabel);
        EintragOeffnenLabel.setBounds(430, 120, 250, 250);

        LaengeLabel.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        LaengeLabel.setText("19");
        add(LaengeLabel);
        LaengeLabel.setBounds(140, 235, 20, 15);

        HoeheLabel.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        HoeheLabel.setText("9");
        add(HoeheLabel);
        HoeheLabel.setBounds(260, 200, 7, 15);

        Parallelogramm.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Parallelogramm.jpg"))); // NOI18N
        add(Parallelogramm);
        Parallelogramm.setBounds(60, 130, 230, 140);

        Hintergrund.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Hintergrund.jpg"))); // NOI18N
        add(Hintergrund);
        Hintergrund.setBounds(0, 0, 700, 500);
    }// </editor-fold>//GEN-END:initComponents

    private void LoesungFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_LoesungFieldKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_ENTER)Loesung();
    }//GEN-LAST:event_LoesungFieldKeyPressed

    private void NeuButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NeuButtonActionPerformed
        if(Eingabe){
            if(!Pruefung) Reset();
            else ;
        } else {
            Assistent.setText("Du hast die Aufgabe noch nicht bearbeitet.<br>Bearbeite zuerst die Aufgabe, bevor du eine neue bekommst!");
        }
    }//GEN-LAST:event_NeuButtonActionPerformed

    private void ZurueckButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ZurueckButtonActionPerformed
        Reset();
        if(!Pruefung)((Frame)(SwingUtilities.getRoot(this))).PerformBackAction(18);
    }//GEN-LAST:event_ZurueckButtonActionPerformed

    private void DruckButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DruckButtonMouseClicked
        drucken();
    }//GEN-LAST:event_DruckButtonMouseClicked

    private void EintragOeffnenLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EintragOeffnenLabelMouseClicked
        if(!Pruefung){
            Eintrag e = new Eintrag();
            e.EintragAusgeben(13);
            e.setVisible(true);
        }
    }//GEN-LAST:event_EintragOeffnenLabelMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel DruckButton;
    private javax.swing.JLabel EintragOeffnenLabel;
    private javax.swing.JLabel ErklaerungLabel;
    private javax.swing.JLabel Hintergrund;
    private javax.swing.JLabel HoeheLabel;
    private javax.swing.JLabel LaengeLabel;
    private javax.swing.JTextField LoesungField;
    private javax.swing.JButton NeuButton;
    private javax.swing.JLabel Parallelogramm;
    private javax.swing.JLabel UeberschriftLabel;
    private javax.swing.JButton ZurueckButton;
    // End of variables declaration//GEN-END:variables
}

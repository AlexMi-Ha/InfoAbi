 

import java.awt.Color;
import javax.swing.SwingUtilities;

/**
 *
 * @author Manuel Mayr
 */
public class A_ZaehlenOrdnen extends javax.swing.JPanel {

    private Assistent Assistent = new Assistent();
    public boolean Pruefung;
    public boolean Eingabe;
    public String Fehler;
    
    private int eins;
    private int zwei;
    
    
    public A_ZaehlenOrdnen() {
        Assistent.setBounds(430, 120, 250, 250);
        add(Assistent);
        initComponents();
        Reset();
    }

    public void Reset() {
        Assistent.setText("Setze das Richtige Zeichen ein.<br><br>z.B.:<br>2 = 2<br>Viel Erfolg!");
        Assistent.setColor(Color.BLACK);
        eins = (int)(Math.random()*1000);
        zwei = (int)(Math.random()*1000);
        Eins.setText(""+eins);
        Zwei.setText(""+zwei);
        DruckButton.setVisible(false);
        DruckButton.setEnabled(false);
        Eingabe=false;
        Fehler="";
    }
    
    public void drucken() {
        String a="Natürliche Zahlen - Zählen und Ordnen";
        String b=eins+" _ "+zwei;
        String c=Fehler+" falsch. Richtig: ";
        if(eins>zwei) c+=">";
        else if(eins==zwei) c+="=";
        else if(eins<zwei) c+="<";
        Drucker d = new Drucker(a,b,c);
    }
    
    public void Loesung(int i) {
        if(!Eingabe) {
            Eingabe=true;
            if(!Pruefung) {
                if(i==-1) {
                    if(eins<zwei) {
                        Assistent.setColor(Color.GREEN);
                        Assistent.setText("Das ist richtig!<br>Gut Gemacht");
                    } else {
                        Fehler="<";
                        DruckButton.setVisible(true);
                        DruckButton.setEnabled(true);
                        Assistent.setColor(Color.RED);
                        Assistent.setText("Das ist falsch, "+eins+" ist kleiner als"+zwei+".<br>Versuch es nochmal!");
                    }
                } else if(i==0) {
                    if(eins==zwei) {
                        Assistent.setColor(Color.GREEN);
                        Assistent.setText("Das ist richtig!<br>Gut Gemacht");
                    } else {
                        Fehler="=";
                        DruckButton.setVisible(true);
                        DruckButton.setEnabled(true);
                        Assistent.setColor(Color.RED);
                        Assistent.setText("Das ist falsch, "+eins+" ist gleich"+zwei+".<br>Versuch es nochmal!");
                    }
                } else if(i==1) {
                    if(eins>zwei) {
                        Assistent.setColor(Color.GREEN);
                        Assistent.setText("Das ist richtig!<br>Gut Gemacht");
                    } else {
                        Fehler=">";
                        DruckButton.setVisible(true);
                        DruckButton.setEnabled(true);
                        Assistent.setColor(Color.RED);
                        Assistent.setText("Das ist falsch, "+eins+" ist größer als"+zwei+".<br>Versuch es nochmal!");
                    }
                }
            }
            else {
                //Rückgabe Pruefungmodus
            }
        }
        else {
            Assistent.setText("Du hast diese Aufgabe schon bearbeitet.<br>Klicke auf Neue Aufgabe!");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        UeberschriftLabel = new javax.swing.JLabel();
        ErklaerungLabel = new javax.swing.JLabel();
        EintragOeffnenLabel = new javax.swing.JLabel();
        Eins = new javax.swing.JLabel();
        Zwei = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        Gleich = new javax.swing.JLabel();
        Groeßer = new javax.swing.JLabel();
        Kleiner = new javax.swing.JLabel();
        ZurueckButton = new javax.swing.JButton();
        NeuButton = new javax.swing.JButton();
        DruckButton = new javax.swing.JLabel();
        Hintergrund = new javax.swing.JLabel();

        setLayout(null);

        UeberschriftLabel.setFont(new java.awt.Font("Georgia", 1, 26)); // NOI18N
        UeberschriftLabel.setForeground(new java.awt.Color(255, 255, 255));
        UeberschriftLabel.setText("Natürliche Zahlen");
        add(UeberschriftLabel);
        UeberschriftLabel.setBounds(36, 31, 244, 26);

        ErklaerungLabel.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        ErklaerungLabel.setForeground(new java.awt.Color(255, 255, 255));
        ErklaerungLabel.setText("Zählen und Ordnen");
        add(ErklaerungLabel);
        ErklaerungLabel.setBounds(36, 63, 157, 21);

        EintragOeffnenLabel.setBackground(new java.awt.Color(255, 255, 255));
        EintragOeffnenLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        EintragOeffnenLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EintragOeffnenLabelMouseClicked(evt);
            }
        });
        add(EintragOeffnenLabel);
        EintragOeffnenLabel.setBounds(430, 120, 250, 250);

        Eins.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        Eins.setForeground(new java.awt.Color(255, 255, 255));
        Eins.setText("999");
        add(Eins);
        Eins.setBounds(110, 230, 30, 22);

        Zwei.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        Zwei.setForeground(new java.awt.Color(255, 255, 255));
        Zwei.setText("999");
        add(Zwei);
        Zwei.setBounds(280, 230, 30, 22);

        jLabel1.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("=");
        add(jLabel1);
        jLabel1.setBounds(200, 230, 14, 29);

        jLabel2.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("<");
        add(jLabel2);
        jLabel2.setBounds(200, 170, 14, 29);

        jLabel3.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText(">");
        add(jLabel3);
        jLabel3.setBounds(200, 290, 14, 29);

        Gleich.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Button_ZaehlenOrdnen.png"))); // NOI18N
        Gleich.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Gleich.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                GleichMouseClicked(evt);
            }
        });
        add(Gleich);
        Gleich.setBounds(160, 220, 95, 55);

        Groeßer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Button_ZaehlenOrdnen.png"))); // NOI18N
        Groeßer.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Groeßer.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                GroeßerMouseClicked(evt);
            }
        });
        add(Groeßer);
        Groeßer.setBounds(160, 280, 95, 55);

        Kleiner.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Button_ZaehlenOrdnen.png"))); // NOI18N
        Kleiner.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Kleiner.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                KleinerMouseClicked(evt);
            }
        });
        add(Kleiner);
        Kleiner.setBounds(160, 160, 95, 55);

        ZurueckButton.setText("Zurück");
        ZurueckButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ZurueckButtonActionPerformed(evt);
            }
        });
        add(ZurueckButton);
        ZurueckButton.setBounds(30, 450, 80, 23);

        NeuButton.setText("<html>Nächste<br>Aufgabe</html>");
        NeuButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NeuButtonActionPerformed(evt);
            }
        });
        add(NeuButton);
        NeuButton.setBounds(330, 350, 70, 40);

        DruckButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/DruckIcon.png"))); // NOI18N
        DruckButton.setToolTipText("Drucken");
        DruckButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        DruckButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DruckButtonMouseClicked(evt);
            }
        });
        add(DruckButton);
        DruckButton.setBounds(560, 420, 30, 30);

        Hintergrund.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Hintergrund.jpg"))); // NOI18N
        add(Hintergrund);
        Hintergrund.setBounds(0, 0, 700, 500);
    }// </editor-fold>//GEN-END:initComponents

    private void KleinerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_KleinerMouseClicked
        Loesung(-1);
    }//GEN-LAST:event_KleinerMouseClicked

    private void GleichMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_GleichMouseClicked
        Loesung(0);
    }//GEN-LAST:event_GleichMouseClicked

    private void GroeßerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_GroeßerMouseClicked
        Loesung(1);
    }//GEN-LAST:event_GroeßerMouseClicked

    private void NeuButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NeuButtonActionPerformed
        if(Eingabe){
            if(!Pruefung) Reset();
            else ;
        } else {
            Assistent.setText("Du hast die Aufgabe noch nicht bearbeitet.<br>Bearbeite zuerst die Aufgabe, bevor du eine neue bekommst!");
        }
    }//GEN-LAST:event_NeuButtonActionPerformed

    private void EintragOeffnenLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EintragOeffnenLabelMouseClicked
        if(!Pruefung){
            Eintrag e = new Eintrag();
            e.EintragAusgeben(1);
            e.setVisible(true);
        }
    }//GEN-LAST:event_EintragOeffnenLabelMouseClicked

    private void ZurueckButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ZurueckButtonActionPerformed
        Reset();
        if(!Pruefung)((Frame)(SwingUtilities.getRoot(this))).PerformBackAction(1);
    }//GEN-LAST:event_ZurueckButtonActionPerformed

    private void DruckButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DruckButtonMouseClicked
        drucken();
    }//GEN-LAST:event_DruckButtonMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel DruckButton;
    private javax.swing.JLabel Eins;
    private javax.swing.JLabel EintragOeffnenLabel;
    private javax.swing.JLabel ErklaerungLabel;
    private javax.swing.JLabel Gleich;
    private javax.swing.JLabel Groeßer;
    private javax.swing.JLabel Hintergrund;
    private javax.swing.JLabel Kleiner;
    private javax.swing.JButton NeuButton;
    private javax.swing.JLabel UeberschriftLabel;
    private javax.swing.JButton ZurueckButton;
    private javax.swing.JLabel Zwei;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    // End of variables declaration//GEN-END:variables
}

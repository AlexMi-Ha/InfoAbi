
public class aaa{
    private int zustand;

    public aaa(){
        zustand = 0; //Anfangszustand z0
    }

    public boolean wortUntersuchen(String wort){
        boolean akzeptiert = false;
        for (int i=0;i<wort.length(); i++) {
            zustandWechseln(wort.charAt(i));
        }
        if (zustand == 3) {
            akzeptiert = true;
        }
        zustand = 0;
        return akzeptiert;
    }
   
    public void zustandWechseln(char eingabe){
        switch(zustand){
            case 0: {
                switch(eingabe) {
                    case 'a': {zustand = 1;} break;
                    default: {zustand = 0;} break;
                }
            } break;
            case 1: {
                switch(eingabe) {
                    case 'a': {zustand = 2;} break;
                    default: {zustand = 1;} break;
                }
            } break;
            case 2: {
                switch(eingabe) {
                    case 'a': {zustand = 3;} break;
                    default: {zustand = 2;} break;
                }
            } break;
            case 3: {
                switch(eingabe) {
                    case 'a': {zustand = 4;} break;
                    default: {zustand = 3;} break;
                } 
            }break;
            case 4: {
                switch(eingabe) {
                    default: {zustand = 4;} break;
                } 
            }break;
            
        }
    }
}

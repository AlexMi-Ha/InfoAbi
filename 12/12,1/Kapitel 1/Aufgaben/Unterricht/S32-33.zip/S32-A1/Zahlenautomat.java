public class Zahlenautomat {

    private int zustand;

    public Zahlenautomat(){
        zustand = 0; //Anfangszustand z0
    }

    public boolean wortUntersuchen(String wort){
        boolean akzeptiert = false;
        for (int i=0;i<wort.length(); i++) {
            zustandWechseln(wort.charAt(i));
        }
        if (zustand == 3) {
            akzeptiert = true;
        }
        zustand = 0;
        return akzeptiert;
    }
   
    public void zustandWechseln(char eingabe){
        switch(zustand){
            case 0: {
                switch(eingabe) {
                    case '0': {zustand = 0;} break;
                    case '1': 
                    case '4':
                    case '7': {zustand = 1;} break;
                    case '2':
                    case '5':
                    case '8': {zustand = 2;} break;
                    case '3':
                    case '6':
                    case '9': {zustand = 3;} break;
                }
            } break;
            case 1: {
                switch(eingabe) {
                    case '0':
                    case '3':
                    case '6':
                    case '9': {zustand = 1;} break;
                    case '1': 
                    case '4':
                    case '7': {zustand = 2;} break;
                    case '2':
                    case '5':
                    case '8': {zustand = 3;} break;
                }
            } break;
            case 2: {
                switch(eingabe) {
                    case '0':
                    case '3':
                    case '6':
                    case '9': {zustand = 2;} break;
                    case '1': 
                    case '4':
                    case '7': {zustand = 3;} break;
                    case '2':
                    case '5':
                    case '8': {zustand = 1;} break;                   
                }
            } break;
            case 3: {
                switch(eingabe) {
                    case '0':
                    case '3':
                    case '6':
                    case '9': {zustand = 3;} break;
                    case '1': 
                    case '4':
                    case '7': {zustand = 1;} break;
                    case '2':
                    case '5':
                    case '8': {zustand = 2;} break;
                    
                }
            } break;
            
        }
    }
}


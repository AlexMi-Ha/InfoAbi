
public class jpg{
    private int zustand;

    public jpg(){
        zustand = 0; //Anfangszustand z0
    }

    public boolean wortUntersuchen(String wort){
        boolean akzeptiert = false;
        for (int i=0;i<wort.length(); i++) {
            zustandWechseln(wort.charAt(i));
        }
        if (zustand == 3) {
            akzeptiert = true;
        }
        zustand = 0;
        return akzeptiert;
    }
   
    public void zustandWechseln(char eingabe){
        switch(zustand){
            case 0: {
                switch(eingabe) {
                    case 'j': {zustand = 1;} break;
                    default: {zustand = 0;} break;
                }
            } break;
            case 1: {
                switch(eingabe) {
                    case 'j': {zustand = 1;} break;
                    case 'p': {zustand = 2;} break;
                    default: {zustand = 0;} break;
                }
            } break;
            case 2: {
                switch(eingabe) {
                    case 'g': {zustand = 3;} break;
                    case 'j': {zustand = 1;} break;
                    default: {zustand = 0;} break;
                }
            } break;
            case 3: {
                switch(eingabe) {
                    case 'j': {zustand = 1;} break;
                    default: {zustand = 0;} break;
                } 
            }break;
            
        }
    }
}

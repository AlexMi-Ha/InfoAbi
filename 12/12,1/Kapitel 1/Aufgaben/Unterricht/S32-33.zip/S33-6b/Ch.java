public class Ch{
    private int zustand;

    public Ch(){
        zustand = 0; //Anfangszustand z0
    }

    public boolean wortUntersuchen(String wort){
        boolean akzeptiert = false;
        for (int i=0;i<wort.length(); i++) {
            zustandWechseln(wort.charAt(i));
        }
        if (zustand == 3) {
            akzeptiert = true;
        }
        zustand = 0;
        return akzeptiert;
    }
   
    public void zustandWechseln(char eingabe){
        switch(zustand){
            case 0: {
                switch(eingabe) {
                    case 'C': {zustand = 1;} break;
                    default: {zustand = 2;} break;
                }
            } break;
            case 1: {
                switch(eingabe) {
                    case 'h': {zustand = 3;} break;
                    default: {zustand = 2;} break;
                }
            } break;
            case 2: {
                switch(eingabe) {
                    default: {zustand = 2;} break;
                }
            } break;
            case 3: {
                switch(eingabe) {
                     default: {zustand = 3;} break;
                } 
            }break;
            
        }
    }
}

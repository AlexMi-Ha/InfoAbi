

public class SOS{
    private int zustand;

    public SOS(){
        zustand = 0; //Anfangszustand z0
    }

    public boolean wortUntersuchen(String wort){
        boolean akzeptiert = false;
        for (int i=0;i<wort.length(); i++) {
            zustandWechseln(wort.charAt(i));
        }
        if (zustand == 3) {
            akzeptiert = true;
        }
        zustand = 0;
        return akzeptiert;
    }
   
    public void zustandWechseln(char eingabe){
        switch(zustand){
            case 0: {
                switch(eingabe) {
                    case 'S': {zustand = 1;} break;
                    default: {zustand = 0;} break;
                }
            } break;
            case 1: {
                switch(eingabe) {
                    case 'O': {zustand = 2;} break;
                    default: {zustand = 0;} break;
                }
            } break;
            case 2: {
                switch(eingabe) {
                    case 'S': {zustand = 3;} break;
                    default: {zustand = 0;} break;
                }
            } break;
            case 3: {
                switch(eingabe) {
                     default: {zustand = 3;} break;
                } 
            }break;
            
        }
    }
}


public class aba{
    private int zustand;

    public aba(){
        zustand = 0; //Anfangszustand z0
    }

    public boolean wortUntersuchen(String wort){
        boolean akzeptiert = false;
        for (int i=0;i<wort.length(); i++) {
            zustandWechseln(wort.charAt(i));
        }
        if (zustand == 4) {
            akzeptiert = true;
        }
        zustand = 0;
        return akzeptiert;
    }
   
    public void zustandWechseln(char eingabe){
        switch(zustand){
            case 0: {
                switch(eingabe) {
                    case 'a': {zustand = 1;} break;
                    default: {zustand = 5;} break;
                }
            } break;
            case 1: {
                switch(eingabe) {
                    case 'b': {zustand = 2;} break;
                    default: {zustand = 5;} break;
                }
            } break;
            case 2: {
                switch(eingabe) {
                    case 'a': {zustand = 4;} break;
                    case 'b': {zustand = 2;} break;
                    default: {zustand = 3;} break;
                }
            } break;
            case 3: {
                switch(eingabe) {
                    case 'b': {zustand = 2;} break;
                    default: {zustand = 3;} break;
                } 
            }break;
            case 4: {
                switch(eingabe) {
                    case 'b': {zustand = 2;} break;
                    default: {zustand = 3;} break;
                } 
            }break;
            
        }
    }
}
